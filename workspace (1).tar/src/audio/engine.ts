/* Звуковой движок Soundscape: синтез барабанов и баса через Web Audio API.
   Никаких сэмплов — всё генерируется осцилляторами и шумом прямо в браузере. */

export type DrumKey = "kick" | "snare" | "hat" | "clap" | "bass";
export const DRUMS: DrumKey[] = ["kick", "snare", "hat", "clap", "bass"];
export const DRUM_LABELS: Record<DrumKey, string> = {
  kick: "Бочка",
  snare: "Снейр",
  hat: "Хэт",
  clap: "Клэп",
  bass: "Бас",
};
export const DRUM_COLORS: Record<DrumKey, string> = {
  kick: "#ffa62b",
  snare: "#ff5470",
  hat: "#52dcc4",
  clap: "#cdd6ea",
  bass: "#9be15d",
};

export const STEPS = 16;
export type Pattern = boolean[][]; // 5 дорожек × 16 шагов

export const emptyPattern = (): Pattern =>
  DRUMS.map(() => Array<boolean>(STEPS).fill(false));

export type StyleKey = "phonk" | "lofi" | "drill" | "house";

export const STYLES: { key: StyleKey; label: string; desc: string; bpm: [number, number] }[] = [
  { key: "phonk", label: "Фонк", desc: "Жирная бочка, тёмный бас, кач на 132", bpm: [128, 138] },
  { key: "lofi", label: "Лоу-фай", desc: "Тёплые 82 удара в минуту, пыль и винил", bpm: [78, 86] },
  { key: "drill", label: "Дрилл", desc: "Скользкие хэты и рваная бочка на 144", bpm: [140, 148] },
  { key: "house", label: "Хаус", desc: "Прямая бочка и бас на слабую долю", bpm: [122, 126] },
];

const rnd = (p: number) => Math.random() < p;
const randInt = (a: number, b: number) => a + Math.floor(Math.random() * (b - a + 1));

function mark(pattern: Pattern, row: number, steps: number[], prob = 1) {
  steps.forEach((s) => {
    if (rnd(prob)) pattern[row][s] = true;
  });
}

/** Генерация паттерна в заданном стиле — «мозг» AI-студии. */
export function generatePattern(style: StyleKey): { pattern: Pattern; bpm: number } {
  const p = emptyPattern();
  const meta = STYLES.find((s) => s.key === style)!;
  const bpm = randInt(meta.bpm[0], meta.bpm[1]);

  if (style === "phonk") {
    mark(p, 0, [0, 3, 6, 8, 11, 14]);
    if (rnd(0.5)) p[0][7] = true;
    if (rnd(0.4)) p[0][10] = true;
    mark(p, 1, [4, 12]);
    for (let i = 0; i < STEPS; i++) if (rnd(0.86)) p[2][i] = true;
    mark(p, 3, [4, 12], 0.7);
    mark(p, 4, [0, 3, 6, 8, 11, 14], 0.8);
    mark(p, 4, [2, 10], 0.5);
  } else if (style === "lofi") {
    if (rnd(0.5)) mark(p, 0, [0, 7, 8]);
    else mark(p, 0, [0, 10]);
    if (rnd(0.4)) p[0][13] = true;
    mark(p, 1, [4, 12]);
    for (let i = 0; i < STEPS; i += 2) if (rnd(0.75)) p[2][i] = true;
    mark(p, 3, [12], 0.45);
    mark(p, 4, [0, 8]);
    mark(p, 4, [11], 0.4);
  } else if (style === "drill") {
    mark(p, 0, [0, 6, 9, 12]);
    if (rnd(0.6)) p[0][14] = true;
    if (rnd(0.35)) p[0][3] = true;
    mark(p, 1, [4, 12]);
    if (rnd(0.4)) p[1][15] = true;
    for (let i = 0; i < STEPS; i++) if (rnd(0.8)) p[2][i] = true;
    mark(p, 3, [4, 12], 0.8);
    mark(p, 4, [0, 6, 9, 12], 0.75);
    mark(p, 4, [14], 0.5);
  } else {
    mark(p, 0, [0, 4, 8, 12]);
    mark(p, 1, [4, 12]);
    mark(p, 2, [2, 6, 10, 14]);
    if (rnd(0.5)) p[2][0] = true;
    mark(p, 3, [4, 12], 0.6);
    mark(p, 4, [2, 6, 10, 14], 0.9);
    mark(p, 4, [0], 0.5);
  }
  return { pattern: p, bpm };
}

const BASS_NOTES = [55, 55, 65.41, 49]; // A1 A1 C2 G1

export class BeatEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private timer: number | null = null;
  private stepIdx = 0;
  private nextTime = 0;

  bpm = 120;
  pattern: Pattern = emptyPattern();
  playing = false;
  onStep: ((s: number) => void) | null = null;

  private ensure(): AudioContext {
    if (!this.ctx) {
      this.ctx = new AudioContext();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.85;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    return this.ctx;
  }

  private noise(ctx: AudioContext): AudioBuffer {
    if (!this.noiseBuf) {
      const b = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
      const d = b.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      this.noiseBuf = b;
    }
    return this.noiseBuf;
  }

  /** Одиночный удар — для превью пэдов и озвучки игр. */
  hit(drum: DrumKey, when = 0, step = 0) {
    const ctx = this.ensure();
    const t = ctx.currentTime + when;
    const out = this.master!;

    if (drum === "kick") {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.frequency.setValueAtTime(155, t);
      o.frequency.exponentialRampToValueAtTime(42, t + 0.11);
      g.gain.setValueAtTime(1, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.34);
      o.connect(g).connect(out);
      o.start(t);
      o.stop(t + 0.36);
    } else if (drum === "snare") {
      const n = ctx.createBufferSource();
      n.buffer = this.noise(ctx);
      const bp = ctx.createBiquadFilter();
      bp.type = "bandpass";
      bp.frequency.value = 1900;
      bp.Q.value = 0.8;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.8, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
      n.connect(bp).connect(g).connect(out);
      n.start(t);
      n.stop(t + 0.2);
      const o = ctx.createOscillator();
      o.type = "triangle";
      o.frequency.setValueAtTime(196, t);
      const og = ctx.createGain();
      og.gain.setValueAtTime(0.35, t);
      og.gain.exponentialRampToValueAtTime(0.001, t + 0.09);
      o.connect(og).connect(out);
      o.start(t);
      o.stop(t + 0.1);
    } else if (drum === "hat") {
      const n = ctx.createBufferSource();
      n.buffer = this.noise(ctx);
      const hp = ctx.createBiquadFilter();
      hp.type = "highpass";
      hp.frequency.value = 7600;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.32, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.055);
      n.connect(hp).connect(g).connect(out);
      n.start(t);
      n.stop(t + 0.07);
    } else if (drum === "clap") {
      [0, 0.013, 0.028].forEach((off, i) => {
        const n = ctx.createBufferSource();
        n.buffer = this.noise(ctx);
        const bp = ctx.createBiquadFilter();
        bp.type = "bandpass";
        bp.frequency.value = 1150;
        bp.Q.value = 1.6;
        const g = ctx.createGain();
        const dur = i === 2 ? 0.16 : 0.09;
        g.gain.setValueAtTime(0.55, t + off);
        g.gain.exponentialRampToValueAtTime(0.001, t + off + dur);
        n.connect(bp).connect(g).connect(out);
        n.start(t + off);
        n.stop(t + off + dur + 0.02);
      });
    } else {
      const o = ctx.createOscillator();
      o.type = "sawtooth";
      o.frequency.setValueAtTime(BASS_NOTES[step % 4], t);
      const lp = ctx.createBiquadFilter();
      lp.type = "lowpass";
      lp.frequency.value = 420;
      lp.Q.value = 1.1;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.5, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.24);
      o.connect(lp).connect(g).connect(out);
      o.start(t);
      o.stop(t + 0.26);
    }
  }

  setPattern(p: Pattern) {
    this.pattern = p.map((r) => [...r]);
  }
  setBpm(b: number) {
    this.bpm = Math.min(180, Math.max(60, b));
  }

  start() {
    if (this.playing) return;
    const ctx = this.ensure();
    this.playing = true;
    this.stepIdx = 0;
    this.nextTime = ctx.currentTime + 0.08;
    this.timer = window.setInterval(() => this.tick(), 25);
  }

  stop() {
    this.playing = false;
    if (this.timer != null) {
      clearInterval(this.timer);
      this.timer = null;
    }
    this.onStep?.(-1);
  }

  private tick() {
    const ctx = this.ctx!;
    const spb = 60 / this.bpm / 4; // длительность 1/16
    while (this.nextTime < ctx.currentTime + 0.12) {
      const s = this.stepIdx;
      const swing = s % 2 === 1 ? spb * 0.16 : 0;
      const when = Math.max(0, this.nextTime + swing - ctx.currentTime);
      DRUMS.forEach((d, r) => {
        if (this.pattern[r]?.[s]) this.hit(d, when, s);
      });
      window.setTimeout(() => this.onStep?.(s), when * 1000);
      this.nextTime += spb;
      this.stepIdx = (this.stepIdx + 1) % STEPS;
    }
  }
}
