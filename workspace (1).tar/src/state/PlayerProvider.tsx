import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { chartIds, trackById } from "../data/music";
import { USERS } from "../data/people";
import { emitEvent } from "./StudioContext";
import { loadHls } from "../services";

interface PlayerValue {
  currentId: string | null;
  queue: string[];
  isPlaying: boolean;
  progress: number;
  duration: number;
  volume: number;
  muted: boolean;
  shuffle: boolean;
  repeat: boolean;
  likes: string[];
  liked: string[];
  friends: string[];
  playTrack: (id: string, queue?: string[], opts?: { autoplay?: boolean }) => void;
  togglePlay: () => void;
  next: () => void;
  prev: () => void;
  seekFrac: (f: number) => void;
  setVolume: (v: number) => void;
  toggleMute: () => void;
  toggleShuffle: () => void;
  toggleRepeat: () => void;
  toggleLike: (id: string) => void;
  isLiked: (id: string) => boolean;
  toggleFriend: (id: string) => void;
  isFriend: (id: string) => boolean;
}

const Ctx = createContext<PlayerValue | null>(null);
export const usePlayer = () => {
  const v = useContext(Ctx);
  if (!v) throw new Error("usePlayer вне провайдера");
  return v;
};

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function PlayerProvider({ children }: { children: ReactNode }) {
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [queue, setQueue] = useState<string[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolumeState] = useState<number>(() => load("ss_volume", 0.8));
  const [muted, setMuted] = useState(false);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState(false);
  const [likes, setLikes] = useState<string[]>(() => load("ss_likes", ["t2", "t3"]));
  const [friends, setFriends] = useState<string[]>(() => load("ss_friends", USERS.filter((u) => u.defaultFriend).map((u) => u.id)));

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const currentRef = useRef<string | null>(null);
  const queueRef = useRef<string[]>([]);
  const shuffleRef = useRef(false);
  const repeatRef = useRef(false);
  const seekToRef = useRef<number | null>(null);

  useEffect(() => localStorage.setItem("ss_likes", JSON.stringify(likes)), [likes]);
  useEffect(() => localStorage.setItem("ss_friends", JSON.stringify(friends)), [friends]);
  useEffect(() => localStorage.setItem("ss_volume", JSON.stringify(volume)), [volume]);
  useEffect(() => {
    shuffleRef.current = shuffle;
  }, [shuffle]);
  useEffect(() => {
    repeatRef.current = repeat;
  }, [repeat]);

  /* создаём аудио-элемент один раз */
  useEffect(() => {
    const a = new Audio();
    a.preload = "auto";
    a.volume = 0.8;
    audioRef.current = a;

    const onTime = () => setProgress(a.currentTime);
    const onMeta = () => {
      setDuration(a.duration || 0);
      if (seekToRef.current != null) {
        a.currentTime = seekToRef.current;
        seekToRef.current = null;
      }
    };
    const onEnd = () => advance(1);
    const onPlay = () => setIsPlaying(true);
    const onPause = () => setIsPlaying(false);

    a.addEventListener("timeupdate", onTime);
    a.addEventListener("loadedmetadata", onMeta);
    a.addEventListener("ended", onEnd);
    a.addEventListener("play", onPlay);
    a.addEventListener("pause", onPause);
    return () => {
      a.pause();
      a.removeEventListener("timeupdate", onTime);
      a.removeEventListener("loadedmetadata", onMeta);
      a.removeEventListener("ended", onEnd);
      a.removeEventListener("play", onPlay);
      a.removeEventListener("pause", onPause);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const hlsRef = useRef<any>(null);

  const playSource = useCallback((id: string, src: string) => {
    const a = audioRef.current;
    if (!a) return;
    currentRef.current = id;
    setCurrentId(id);
    setProgress(0);
    setDuration(0);
    if (hlsRef.current) {
      try { hlsRef.current.destroy(); } catch { /* noop */ }
      hlsRef.current = null;
    }
    const t = trackById(id);
    const hlsUrl = t?.hlsUrl;
    const start = () => void a.play().catch(() => setIsPlaying(false));

    if (hlsUrl) {
      /* SoundCloud HLS: Safari играет сам, остальным — hls.js */
      if (a.canPlayType("application/vnd.apple.mpegurl")) {
        a.src = hlsUrl;
        a.load();
        start();
        return;
      }
      loadHls()
        .then((Hls: any) => {
          if (Hls?.isSupported?.()) {
            const h = new Hls();
            hlsRef.current = h;
            h.loadSource(hlsUrl);
            h.attachMedia(a);
            h.on(Hls.Events.MANIFEST_PARSED, start);
            h.on(Hls.Events.ERROR, (_: unknown, data: { fatal?: boolean }) => {
              if (data?.fatal) {
                try { h.destroy(); } catch { /* noop */ }
                hlsRef.current = null;
                if (src) {
                  a.src = src;
                  a.load();
                  start();
                }
              }
            });
          } else if (src) {
            a.src = src;
            a.load();
            start();
          }
        })
        .catch(() => {
          if (src) {
            a.src = src;
            a.load();
            start();
          }
        });
      return;
    }
    a.src = src;
    a.load();
    start();
  }, []);

  const advance = useCallback(
    (dir: 1 | -1) => {
      const id = currentRef.current;
      const q = queueRef.current;
      if (!id || q.length === 0) return;
      if (repeatRef.current && dir === 1) {
        const a = audioRef.current;
        if (a) {
          a.currentTime = 0;
          void a.play();
        }
        return;
      }
      let idx = q.indexOf(id);
      if (idx === -1) idx = 0;
      else if (shuffleRef.current && q.length > 1) {
        let n = idx;
        while (n === idx) n = Math.floor(Math.random() * q.length);
        idx = n;
      } else {
        idx = (idx + dir + q.length) % q.length;
      }
      const nextId = q[idx];
      const t = trackById(nextId);
      if (t) playSource(nextId, t.src);
    },
    [playSource]
  );

  const playTrack = useCallback(
    (id: string, q?: string[], opts?: { autoplay?: boolean }) => {
      const t = trackById(id);
      if (!t) return;
      if (q) {
        queueRef.current = q;
        setQueue(q);
      } else if (queueRef.current.length === 0) {
        queueRef.current = [id];
        setQueue([id]);
      }
      emitEvent("track-start");
      if (q && q.length === chartIds.length && q.every((x, i) => x === chartIds[i])) emitEvent("chart-play");
      if (opts?.autoplay === false) {
        currentRef.current = id;
        setCurrentId(id);
        return;
      }
      playSource(id, t.src);
    },
    [playSource]
  );

  const togglePlay = useCallback(() => {
    const a = audioRef.current;
    const id = currentRef.current;
    if (!a || !id) return;
    if (a.paused) {
      if (!a.src) {
        const t = trackById(id);
        if (!t) return;
        a.src = t.src;
      }
      void a.play().catch(() => {});
    } else {
      a.pause();
    }
  }, []);

  const next = useCallback(() => advance(1), [advance]);
  const prev = useCallback(() => {
    const a = audioRef.current;
    if (a && a.currentTime > 4) {
      a.currentTime = 0;
      setProgress(0);
      return;
    }
    advance(-1);
  }, [advance]);

  const seekFrac = useCallback((f: number) => {
    const a = audioRef.current;
    if (!a || !Number.isFinite(a.duration) || a.duration <= 0) return;
    const t = f * a.duration;
    if (a.readyState >= 1) a.currentTime = t;
    else seekToRef.current = t;
    setProgress(t);
  }, []);

  const setVolume = useCallback((v: number) => {
    const vv = Math.min(Math.max(v, 0), 1);
    setVolumeState(vv);
    setMuted(vv === 0);
    if (audioRef.current) {
      audioRef.current.volume = vv;
      audioRef.current.muted = false;
    }
  }, []);

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      if (audioRef.current) audioRef.current.muted = !m;
      return !m;
    });
  }, []);

  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = volume;
  }, [volume]);

  const toggleLike = useCallback((id: string) => {
    setLikes((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));
  }, []);
  const isLiked = useCallback((id: string) => likes.includes(id), [likes]);
  const toggleFriend = useCallback((id: string) => {
    setFriends((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));
  }, []);
  const isFriend = useCallback((id: string) => friends.includes(id), [friends]);

  const value = useMemo<PlayerValue>(
    () => ({
      currentId,
      queue,
      isPlaying,
      progress,
      duration,
      volume,
      muted,
      shuffle,
      repeat,
      likes,
      liked: likes,
      friends,
      playTrack,
      togglePlay,
      next,
      prev,
      seekFrac,
      setVolume,
      toggleMute,
      toggleShuffle: () => setShuffle((s) => !s),
      toggleRepeat: () => setRepeat((r) => !r),
      toggleLike,
      isLiked,
      toggleFriend,
      isFriend,
    }),
    [currentId, queue, isPlaying, progress, duration, volume, muted, shuffle, repeat, likes, friends, playTrack, togglePlay, next, prev, seekFrac, setVolume, toggleMute, toggleLike, isLiked, toggleFriend, isFriend]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
