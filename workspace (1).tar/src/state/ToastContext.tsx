import { createContext, useCallback, useContext, useRef, useState, type ReactNode } from "react";
import { IcCheck, IcHeartFill, IcPlay, IcUsers } from "../components/icons";

type ToastIcon = "heart" | "user" | "play" | "ok" | "info";
interface ToastItem {
  id: number;
  text: string;
  icon: ToastIcon;
}

const Ctx = createContext<(text: string, icon?: ToastIcon) => void>(() => {});
export const useToast = () => useContext(Ctx);

function ToastGlyph({ icon }: { icon: ToastIcon }) {
  if (icon === "heart") return <IcHeartFill className="text-beat-500" style={{ fontSize: 16 }} />;
  if (icon === "user") return <IcUsers className="text-wave-400" style={{ fontSize: 16 }} />;
  if (icon === "play") return <IcPlay className="text-flare-400" style={{ fontSize: 16 }} />;
  if (icon === "ok") return <IcCheck className="text-wave-400" style={{ fontSize: 16 }} />;
  return (
    <span className="inline-block h-2 w-2 rounded-full bg-flare-400" aria-hidden />
  );
}

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const idRef = useRef(1);

  const push = useCallback((text: string, icon: ToastIcon = "info") => {
    const id = idRef.current++;
    setItems((p) => [...p.slice(-2), { id, text, icon }]);
    window.setTimeout(() => setItems((p) => p.filter((t) => t.id !== id)), 2600);
  }, []);

  return (
    <Ctx.Provider value={push}>
      {children}
      <div className="pointer-events-none fixed bottom-[104px] right-4 z-[90] flex flex-col items-end gap-2">
        {items.map((t) => (
          <div
            key={t.id}
            className="toast-in flex items-center gap-2.5 rounded-lg border border-ink-600/70 bg-ink-800/95 py-2.5 pl-3.5 pr-5 text-sm font-medium text-ink-100 shadow-2xl shadow-black/50 backdrop-blur"
          >
            <ToastGlyph icon={t.icon} />
            <span>{t.text}</span>
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}
