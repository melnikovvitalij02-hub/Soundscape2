import { createContext, useCallback, useContext, useState, type ReactNode } from "react";

export interface Session {
  name: string;
  username: string;
  colors: [string, string];
}

const KEY = "ss_session_v1";

function load(): Session | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const s = JSON.parse(raw) as Session;
    if (!s?.name || !s?.colors) return null;
    return s;
  } catch {
    return null;
  }
}

const slug = (name: string) =>
  name
    .trim()
    .toLowerCase()
    .replace(/[^a-zа-яё0-9]+/gi, ".")
    .replace(/^\.+|\.+$/g, "") || "user";

const Ctx = createContext<{ me: Session | null; login: (name: string, colors: [string, string]) => void; logout: () => void }>({
  me: null,
  login: () => {},
  logout: () => {},
});

export const useAuth = () => useContext(Ctx);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Session | null>(load);

  const login = useCallback((name: string, colors: [string, string]) => {
    const s: Session = { name: name.trim(), username: slug(name), colors };
    localStorage.setItem(KEY, JSON.stringify(s));
    setMe(s);
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem(KEY);
    setMe(null);
  }, []);

  return <Ctx.Provider value={{ me, login, logout }}>{children}</Ctx.Provider>;
}
