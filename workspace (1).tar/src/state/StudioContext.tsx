import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { BeatEngine, generatePattern, type Pattern } from "../audio/engine";
import { trackById } from "../data/music";
import { userById } from "../data/people";

/* ---------- события квестов ---------- */
export type QuestEvent = "track-start" | "chart-play" | "beat-save" | "game-win" | "global-play";
const subs = new Set<(e: QuestEvent) => void>();
export const emitEvent = (e: QuestEvent) => subs.forEach((f) => f(e));

/* ---------- сущности ---------- */
export interface Project {
  id: string;
  name: string;
  bpm: number;
  pattern: Pattern;
  origin: "manual" | "ai";
  style?: string;
  createdAt: number;
}

export interface ChatMsg {
  id: string;
  from: "me" | "them";
  text: string;
  ts: number;
}

export interface QuestDef {
  id: string;
  event: QuestEvent;
  title: string;
  desc: string;
  target: number;
  xp: number;
}

export const QUESTS: QuestDef[] = [
  { id: "listen3", event: "track-start", title: "Разогрей уши", desc: "Прослушай 3 любых трека", target: 3, xp: 50 },
  { id: "chart1", event: "chart-play", title: "Рука на пульсе", desc: "Включи чарт недели", target: 1, xp: 30 },
  { id: "beat1", event: "beat-save", title: "Битмейкер", desc: "Сохрани бит в Beat Pro", target: 1, xp: 80 },
  { id: "game3", event: "game-win", title: "Меломан", desc: "Угадай 3 трека в игре", target: 3, xp: 60 },
  { id: "world1", event: "global-play", title: "Весь мир", desc: "Включи трек из мирового поиска", target: 1, xp: 40 },
];

export const XP_PER_LEVEL = 250;

interface Persisted {
  pro: boolean;
  proUntil: string | null;
  projects: Project[];
  xp: number;
  claimed: string[];
  progress: Record<string, number>;
  chat: Record<string, ChatMsg[]>;
  unread: Record<string, number>;
}

const dayKey = () => new Date().toDateString();

const seedChat: Record<string, ChatMsg[]> = {
  u2: [
    {
      id: "seed1",
      from: "them",
      text: "Йоу! Зацени — я вчера собрал бит в Beat Pro, бас прямо качает. Попробуй пресет «Фонк» 🔥",
      ts: Date.now() - 1000 * 60 * 42,
    },
  ],
  u1: [
    {
      id: "seed2",
      from: "them",
      text: "Привет! Видела тебя в чартах — у тебя отличный вкус. Скинешь свой топ недели?",
      ts: Date.now() - 1000 * 60 * 60 * 5,
    },
  ],
};

const defaults: Persisted = {
  pro: false,
  proUntil: null,
  projects: [
    {
      id: "demo-phonk",
      name: "Демо-фонк",
      bpm: 133,
      pattern: generatePattern("phonk").pattern,
      origin: "ai",
      style: "Фонк",
      createdAt: Date.now() - 1000 * 60 * 60 * 26,
    },
  ],
  xp: 120,
  claimed: [],
  progress: {},
  chat: seedChat,
  unread: { u2: 1 },
};

function loadState(): Persisted {
  try {
    const raw = localStorage.getItem("ss_studio_v2");
    if (raw) {
      const p = JSON.parse(raw) as Partial<Persisted>;
      return { ...defaults, ...p, projects: p.projects ?? defaults.projects, chat: p.chat ?? defaults.chat };
    }
  } catch {
    /* повреждённое хранилище — начинаем заново */
  }
  return defaults;
}

/* ---------- контекст ---------- */
interface StudioValue {
  engine: BeatEngine;
  playingProjectId: string | null;
  engineStep: number;
  playProject: (p: Project) => void;
  stopProject: () => void;
  projects: Project[];
  saveProject: (data: { name: string; bpm: number; pattern: Pattern; origin: "manual" | "ai"; style?: string }) => { ok: true } | { ok: false; reason: "limit" };
  deleteProject: (id: string) => void;
  pro: boolean;
  proUntil: string | null;
  activatePro: () => void;
  cancelPro: () => void;
  xp: number;
  level: number;
  levelProgress: number;
  addXp: (n: number) => void;
  questProgress: (q: QuestDef) => number;
  questClaimed: (q: QuestDef) => boolean;
  claimQuest: (q: QuestDef) => boolean;
  chat: Record<string, ChatMsg[]>;
  unread: Record<string, number>;
  typing: string | null;
  sendMessage: (friendId: string, text: string) => void;
  markRead: (friendId: string) => void;
  setDialogActive: (friendId: string | null) => void;
}

const Ctx = createContext<StudioValue | null>(null);
export const useStudio = () => {
  const v = useContext(Ctx);
  if (!v) throw new Error("useStudio вне провайдера");
  return v;
};

const REPLIES = [
  "Привет! Ты как раз вовремя — собираю плейлист на вечер, скинуть?",
  "О, слушай, а ты уже крутил Beat Pro? Там бас-строка — отдельный кайф",
  "Го в колаб? У меня лежит набросок на 140 bpm, не хватает идеи для дропа",
  "Я сегодня в «Угадай трек» пять из пяти сделал. Попробуй перебить!",
  "Закинь свой топ недели, мне для эфира нужно. Только честно — без guilty pleasure 😄",
];

export function StudioProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<Persisted>(loadState);
  const [playingProjectId, setPlayingProjectId] = useState<string | null>(null);
  const [engineStep, setEngineStep] = useState(-1);
  const [typing, setTyping] = useState<string | null>(null);
  const engineRef = useRef<BeatEngine | null>(null);
  if (!engineRef.current) engineRef.current = new BeatEngine();
  const engine = engineRef.current;
  const activeDialog = useRef<string | null>(null);

  /* персист */
  useEffect(() => {
    localStorage.setItem("ss_studio_v2", JSON.stringify(state));
  }, [state]);

  /* счётчики квестов */
  useEffect(() => {
    const off = (e: QuestEvent) =>
      setState((s) => ({
        ...s,
        progress: { ...s.progress, [`${dayKey()}:${e}`]: (s.progress[`${dayKey()}:${e}`] ?? 0) + 1 },
      }));
    subs.add(off);
    return () => {
      subs.delete(off);
    };
  }, []);

  const playProject = useCallback(
    (p: Project) => {
      engine.stop();
      engine.setPattern(p.pattern);
      engine.setBpm(p.bpm);
      engine.onStep = (s) => setEngineStep(s);
      engine.start();
      setPlayingProjectId(p.id);
    },
    [engine]
  );

  const stopProject = useCallback(() => {
    engine.stop();
    setPlayingProjectId(null);
    setEngineStep(-1);
  }, [engine]);

  const saveProject: StudioValue["saveProject"] = useCallback(
    (data) => {
      if (!state.pro && state.projects.length >= 3) return { ok: false, reason: "limit" };
      const proj: Project = {
        id: "prj_" + Date.now().toString(36),
        createdAt: Date.now(),
        ...data,
      };
      setState((s) => ({ ...s, projects: [proj, ...s.projects] }));
      return { ok: true };
    },
    [state.pro, state.projects.length]
  );

  const deleteProject = useCallback(
    (id: string) => {
      setState((s) => ({ ...s, projects: s.projects.filter((p) => p.id !== id) }));
      if (playingProjectId === id) stopProject();
    },
    [playingProjectId, stopProject]
  );

  const activatePro = useCallback(() => {
    const until = new Date(Date.now() + 30 * 86400000).toLocaleDateString("ru-RU", { day: "numeric", month: "long" });
    setState((s) => ({ ...s, pro: true, proUntil: until }));
  }, []);

  const cancelPro = useCallback(() => setState((s) => ({ ...s, pro: false, proUntil: null })), []);

  const addXp = useCallback((n: number) => setState((s) => ({ ...s, xp: s.xp + n })), []);

  const questProgress = useCallback(
    (q: QuestDef) => Math.min(state.progress[`${dayKey()}:${q.event}`] ?? 0, q.target),
    [state.progress]
  );
  const questClaimed = useCallback(
    (q: QuestDef) => state.claimed.includes(`${dayKey()}:${q.id}`),
    [state.claimed]
  );
  const claimQuest = useCallback(
    (q: QuestDef) => {
      const key = `${dayKey()}:${q.id}`;
      if (state.claimed.includes(key)) return false;
      if ((state.progress[`${dayKey()}:${q.event}`] ?? 0) < q.target) return false;
      setState((s) => ({ ...s, claimed: [...s.claimed, key], xp: s.xp + q.xp }));
      return true;
    },
    [state]
  );

  const sendMessage = useCallback((friendId: string, text: string) => {
    const msg: ChatMsg = { id: "m" + Date.now().toString(36), from: "me", text, ts: Date.now() };
    setState((s) => ({ ...s, chat: { ...s.chat, [friendId]: [...(s.chat[friendId] ?? []), msg] } }));

    const friend = userById(friendId);
    const t = trackById(friend?.listening ?? undefined);
    const pool = t
      ? [...REPLIES, `Кстати, у ${t.artist} — «${t.title}» сейчас у меня на репите. Оцени!`]
      : REPLIES;
    const reply = pool[Math.floor(Math.random() * pool.length)];

    window.setTimeout(() => setTyping(friendId), 800 + Math.random() * 500);
    window.setTimeout(() => {
      setTyping(null);
      setState((s) => ({
        ...s,
        chat: {
          ...s.chat,
          [friendId]: [
            ...(s.chat[friendId] ?? []),
            { id: "m" + (Date.now() + 1).toString(36), from: "them", text: reply, ts: Date.now() },
          ],
        },
        unread: activeDialog.current === friendId ? s.unread : { ...s.unread, [friendId]: (s.unread[friendId] ?? 0) + 1 },
      }));
    }, 2300 + Math.random() * 1200);
  }, []);

  const markRead = useCallback((friendId: string) => {
    setState((s) => (s.unread[friendId] ? { ...s, unread: { ...s.unread, [friendId]: 0 } } : s));
  }, []);

  const setDialogActive = useCallback((id: string | null) => {
    activeDialog.current = id;
  }, []);

  const level = Math.floor(state.xp / XP_PER_LEVEL) + 1;
  const levelProgress = (state.xp % XP_PER_LEVEL) / XP_PER_LEVEL;

  const value = useMemo<StudioValue>(
    () => ({
      engine,
      playingProjectId,
      engineStep,
      playProject,
      stopProject,
      projects: state.projects,
      saveProject,
      deleteProject,
      pro: state.pro,
      proUntil: state.proUntil,
      activatePro,
      cancelPro,
      xp: state.xp,
      level,
      levelProgress,
      addXp,
      questProgress,
      questClaimed,
      claimQuest,
      chat: state.chat,
      unread: state.unread,
      typing,
      sendMessage,
      markRead,
      setDialogActive,
    }),
    [engine, playingProjectId, engineStep, playProject, stopProject, state, saveProject, deleteProject, activatePro, cancelPro, level, levelProgress, addXp, questProgress, questClaimed, claimQuest, typing, sendMessage, markRead, setDialogActive]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
