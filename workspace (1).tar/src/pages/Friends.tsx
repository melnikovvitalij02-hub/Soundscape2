import { useMemo, useState } from "react";
import { chartIds, trackById } from "../data/music";
import { USERS, fmtNum, userById, type User } from "../data/people";
import type { Nav } from "../router";
import { usePlayer } from "../state/PlayerProvider";
import { Avatar, Eq, Reveal, SectionTitle } from "../components/bits";
import { IcCheck, IcClose, IcPlay, IcPlus, IcSearch, IcUsers } from "../components/icons";

function FriendCard({ u, nav, delay }: { u: User; nav: Nav; delay: number }) {
  const { isFriend, toggleFriend, playTrack } = usePlayer();
  const friend = isFriend(u.id);
  const t = trackById(u.listening);

  return (
    <Reveal delay={delay}>
      <article className="group relative flex h-full flex-col rounded-xl border border-ink-700/70 bg-ink-900/70 p-5 transition-all duration-300 hover:-translate-y-1 hover:border-ink-500 hover:bg-ink-850 hover:shadow-2xl hover:shadow-black/40">
        {/* статусная полоса */}
        <span
          className="absolute inset-x-0 top-0 h-[3px] rounded-t-xl opacity-0 transition-opacity duration-300 group-hover:opacity-100"
          style={{ background: `linear-gradient(90deg, ${u.colors[0]}, ${u.colors[1]})` }}
        />
        <div className="flex items-start gap-4">
          <button type="button" onClick={() => nav({ name: "profile", id: u.id })} aria-label={`Профиль: ${u.name}`} className="transition-transform duration-300 hover:scale-105">
            <Avatar name={u.name} colors={u.colors} size={56} online={u.online} />
          </button>
          <div className="min-w-0 flex-1">
            <button type="button" onClick={() => nav({ name: "profile", id: u.id })} className="block max-w-full text-left">
              <span className="font-display block truncate text-[15px] font-bold text-ink-100 transition-colors group-hover:text-flare-300">
                {u.name}
              </span>
            </button>
            <p className="font-mono text-[11px] text-ink-500">@{u.username} · в Soundscape с {u.joined.split(" ")[1] ?? u.joined}</p>
          </div>
        </div>

        <p className="mt-3 line-clamp-2 min-h-[2.4em] text-[13px] leading-snug font-medium text-ink-300">{u.bio}</p>

        {/* слушает сейчас */}
        <div className="mt-3 flex min-h-[30px] items-center">
          {t ? (
            <button
              type="button"
              onClick={() => playTrack(t.id, chartIds)}
              className="flex min-w-0 items-center gap-2 rounded-lg bg-ink-800 py-1.5 pr-3 pl-2 text-left transition-colors duration-200 hover:bg-ink-750"
              title={`Слушать «${t.title}»`}
            >
              <Eq playing className="shrink-0 text-wave-400" style={{ height: 11 }} />
              <img src={t.cover} alt="" className="h-6 w-6 shrink-0 rounded object-cover" />
              <span className="truncate text-xs font-bold text-ink-200">
                {t.title} <span className="font-medium text-ink-400">· {t.artist}</span>
              </span>
            </button>
          ) : (
            <span className="font-mono text-[11px] text-ink-500">{u.online ? "в сети · ничего не играет" : `был(а) ${u.lastSeen}`}</span>
          )}
        </div>

        {/* статистика */}
        <div className="font-mono mt-3 grid grid-cols-3 gap-2 border-t border-ink-800 pt-3 text-center">
          <span>
            <span className="block text-sm font-bold text-ink-100">{fmtNum(u.followers)}</span>
            <span className="text-[10px] tracking-wider text-ink-500 uppercase">подписч.</span>
          </span>
          <span>
            <span className="block text-sm font-bold text-ink-100">{fmtNum(u.following)}</span>
            <span className="text-[10px] tracking-wider text-ink-500 uppercase">друзей</span>
          </span>
          <span>
            <span className="block text-sm font-bold text-ink-100">{fmtNum(u.minutesWeek)}</span>
            <span className="text-[10px] tracking-wider text-ink-500 uppercase">мин/нед</span>
          </span>
        </div>

        {/* действия */}
        <div className="mt-4 flex gap-2">
          <button
            type="button"
            onClick={() => nav({ name: "profile", id: u.id })}
            className="flex-1 rounded-lg border border-ink-600/80 py-2.5 text-[13px] font-bold text-ink-200 transition-all duration-200 hover:border-ink-400 hover:bg-ink-800 hover:text-ink-100"
          >
            Профиль
          </button>
          <button
            type="button"
            onClick={() => toggleFriend(u.id)}
            className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2.5 text-[13px] font-bold transition-all duration-200 active:scale-95 ${
              friend
                ? "bg-wave-500/15 text-wave-300 inset-ring-1 inset-ring-wave-500/40 hover:bg-wave-500/25"
                : "bg-flare-500 text-ink-950 shadow-lg shadow-flare-500/20 hover:bg-flare-400"
            }`}
          >
            {friend ? (
              <>
                <IcCheck style={{ fontSize: 14 }} /> Друзья
              </>
            ) : (
              <>
                <IcPlus style={{ fontSize: 14 }} /> Добавить
              </>
            )}
          </button>
        </div>
      </article>
    </Reveal>
  );
}

export function FriendsPage({ nav }: { nav: Nav }) {
  const { friends } = usePlayer();
  const [q, setQ] = useState("");
  const norm = q.trim().toLowerCase();

  const filtered = useMemo(() => {
    if (!norm) return USERS;
    return USERS.filter(
      (u) =>
        u.name.toLowerCase().includes(norm) ||
        u.username.toLowerCase().includes(norm) ||
        u.bio.toLowerCase().includes(norm) ||
        u.tags.some((t) => t.toLowerCase().includes(norm))
    );
  }, [norm]);

  const myFriends = filtered.filter((u) => friends.includes(u.id));
  const suggestions = filtered.filter((u) => !friends.includes(u.id));
  const onlineCount = USERS.filter((u) => friends.includes(u.id) && u.online).length;

  return (
    <div>
      <header className="mb-7 flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="font-mono flex items-center gap-2 text-[11px] font-semibold tracking-[0.22em] text-flare-400 uppercase">
            <IcUsers style={{ fontSize: 14 }} /> Соцсеть · люди и вайбы
          </p>
          <h1 className="font-display mt-2 text-3xl font-black tracking-tight text-ink-100 md:text-4xl">Друзья</h1>
          <p className="mt-2 text-[15px] font-medium text-ink-300">
            {friends.length} в друзьях · <span className="text-wave-400">{onlineCount} сейчас в эфире</span>
          </p>
        </div>

        {/* поиск людей */}
        <div className="group flex w-full items-center gap-2.5 rounded-xl border border-ink-600/80 bg-ink-850 px-4 py-3 transition-all duration-300 focus-within:border-flare-500/70 focus-within:shadow-[0_0_0_4px_rgba(255,166,43,0.12)] md:w-[360px]">
          <IcSearch style={{ fontSize: 17 }} className="shrink-0 text-ink-400 transition-colors group-focus-within:text-flare-400" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Имя, ник или интерес…"
            className="w-full bg-transparent text-sm font-semibold text-ink-100 outline-none placeholder:font-medium placeholder:text-ink-500"
          />
          {q && (
            <button type="button" aria-label="Очистить" onClick={() => setQ("")} className="shrink-0 text-ink-400 transition-colors hover:text-ink-100">
              <IcClose style={{ fontSize: 15 }} />
            </button>
          )}
        </div>
      </header>

      {filtered.length === 0 ? (
        <Reveal>
          <div className="mt-14 flex flex-col items-center text-center">
            <span className="flex h-20 w-20 items-center justify-center rounded-full border border-dashed border-ink-600 text-ink-500">
              <IcUsers style={{ fontSize: 32 }} />
            </span>
            <h2 className="font-display mt-5 text-xl font-bold text-ink-100">Никого не нашли по запросу «{q}»</h2>
            <p className="mt-2 max-w-sm text-sm font-medium text-ink-400">
              Попробуйте «диджей», «фолк» или просто имя — например, «Соня».
            </p>
            <button
              type="button"
              onClick={() => setQ("")}
              className="font-display mt-5 rounded-full border border-ink-600 px-5 py-2.5 text-[12px] font-bold text-ink-200 transition-all hover:border-ink-400 hover:bg-ink-800"
            >
              Показать всех
            </button>
          </div>
        </Reveal>
      ) : (
        <>
          {myFriends.length > 0 && (
            <section>
              <SectionTitle kicker={`ваши люди · ${myFriends.length}`} title="В друзьях" />
              <div className="grid gap-4 md:grid-cols-2 2xl:grid-cols-3">
                {myFriends.map((u, i) => (
                  <FriendCard key={u.id} u={u} nav={nav} delay={i * 60} />
                ))}
              </div>
            </section>
          )}

          {suggestions.length > 0 && (
            <section className="mt-12">
              <SectionTitle
                kicker={`возможно, вы на одной волне · ${suggestions.length}`}
                title="Кого добавить"
              />
              <div className="grid gap-4 md:grid-cols-2 2xl:grid-cols-3">
                {suggestions.map((u, i) => (
                  <FriendCard key={u.id} u={u} nav={nav} delay={i * 60} />
                ))}
              </div>
            </section>
          )}

          {myFriends.length === 0 && (
            <p className="mt-2 text-sm font-medium text-ink-400">
              В друзьях пока пусто — добавьте кого-нибудь из рекомендаций ниже, вместе слушать веселее.
            </p>
          )}
        </>
      )}
    </div>
  );
}

export { userById };
