import { useState, type FormEvent } from "react";
import confetti from "canvas-confetti";
import type { Nav } from "../router";
import { useStudio } from "../state/StudioContext";
import { useToast } from "../state/ToastContext";
import { cardBrand, createYooKassaPayment, luhnValid } from "../services";
import { Reveal } from "../components/bits";
import { IcCard, IcCheck, IcCrown, IcLock } from "../components/icons2";
import { IcWave } from "../components/icons";

const PRO_FEATURES = [
  "AI-студия: генерация битов по запросу",
  "Безлимит проектов в Beat Pro",
  "Все стилевые модели и новые звуки",
  "Ранний доступ к фичам платформы",
  "Значок Pro в профиле и чатах",
];

const FREE_FEATURES = [
  "Чарты и весь плеер Soundscape",
  "3 проекта в Beat Pro",
  "Квесты, XP и игры",
  "Друзья, чаты, мировой поиск",
];

function YooKassaModal({ onClose }: { onClose: () => void }) {
  const { activatePro } = useStudio();
  const toast = useToast();
  const [step, setStep] = useState<"form" | "processing" | "success">("form");
  const [num, setNum] = useState("");
  const [exp, setExp] = useState("");
  const [cvc, setCvc] = useState("");
  const [email, setEmail] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [paymentId, setPaymentId] = useState("");
  const [demo, setDemo] = useState(false);

  const fmtNum = (v: string) =>
    v.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();
  const fmtExp = (v: string) => {
    const d = v.replace(/\D/g, "").slice(0, 4);
    return d.length > 2 ? `${d.slice(0, 2)}/${d.slice(2)}` : d;
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    const digits = num.replace(/\D/g, "");
    if (!luhnValid(digits)) errs.num = "Проверьте номер карты";
    const [mm, yy] = exp.split("/");
    const m = Number(mm);
    const y = Number(yy);
    if (!mm || !yy || m < 1 || m > 12 || y < 26 || (y === 26 && m < new Date().getMonth() + 1))
      errs.exp = "Срок в формате ММ/ГГ";
    if (!/^\d{3}$/.test(cvc)) errs.cvc = "3 цифры";
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setStep("processing");
    const pay = await createYooKassaPayment({
      description: "Soundscape Beat Pro — подписка на 1 месяц",
      value: "499.00",
      capture: true,
    });
    await new Promise((r) => setTimeout(r, 1400));
    setPaymentId(pay.id);
    setDemo(pay.demo);
    setStep("success");
    activatePro();
    confetti({ particleCount: 130, spread: 75, origin: { y: 0.6 }, colors: ["#ffa62b", "#52dcc4", "#ff5470", "#e9edf5"] });
    toast("Beat Pro активирован — добро пожаловать!", "ok");
  };

  return (
    <div
      className="fixed inset-0 z-[80] flex items-center justify-center bg-ink-950/80 p-4 backdrop-blur-sm"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget && step !== "processing") onClose();
      }}
    >
      <div className="page-enter w-full max-w-md overflow-hidden rounded-2xl border border-ink-600 bg-ink-900 shadow-2xl shadow-black/60">
        {/* шапка кассы */}
        <div className="flex items-center justify-between border-b border-ink-700 bg-ink-850 px-6 py-4">
          <div className="flex items-center gap-2.5">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#8b3ffd]/15 font-display text-sm font-black text-[#a86bff]">Ю</span>
            <div>
              <p className="text-sm font-bold text-ink-100">ЮKassa · защищённый платёж</p>
              <p className="font-mono text-[10px] tracking-wider text-ink-500 uppercase">soundscape · подписка Beat Pro</p>
            </div>
          </div>
          <span className="font-display text-lg font-black text-flare-300">499 ₽</span>
        </div>

        {step === "form" && (
          <form onSubmit={submit} className="p-6">
            <label className="block">
              <span className="text-xs font-bold text-ink-300">Номер карты</span>
              <div className="relative mt-1.5">
                <input
                  value={num}
                  onChange={(e) => setNum(fmtNum(e.target.value))}
                  inputMode="numeric"
                  placeholder="0000 0000 0000 0000"
                  className={`font-mono w-full rounded-lg border bg-ink-850 px-3.5 py-3 text-sm tracking-wider text-ink-100 outline-none transition-colors placeholder:text-ink-600 focus:border-flare-500/70 ${errors.num ? "border-beat-500" : "border-ink-600"}`}
                />
                <span className="font-mono absolute top-1/2 right-3 -translate-y-1/2 text-[10px] font-bold text-ink-400 uppercase">
                  {num ? cardBrand(num) : ""}
                </span>
              </div>
              {errors.num && <span className="mt-1 block text-[11px] font-semibold text-beat-400">{errors.num}</span>}
            </label>

            <div className="mt-4 grid grid-cols-2 gap-3">
              <label className="block">
                <span className="text-xs font-bold text-ink-300">Срок действия</span>
                <input
                  value={exp}
                  onChange={(e) => setExp(fmtExp(e.target.value))}
                  inputMode="numeric"
                  placeholder="ММ/ГГ"
                  className={`font-mono mt-1.5 w-full rounded-lg border bg-ink-850 px-3.5 py-3 text-sm tracking-wider text-ink-100 outline-none transition-colors placeholder:text-ink-600 focus:border-flare-500/70 ${errors.exp ? "border-beat-500" : "border-ink-600"}`}
                />
                {errors.exp && <span className="mt-1 block text-[11px] font-semibold text-beat-400">{errors.exp}</span>}
              </label>
              <label className="block">
                <span className="text-xs font-bold text-ink-300">CVC/CVV</span>
                <input
                  value={cvc}
                  onChange={(e) => setCvc(e.target.value.replace(/\D/g, "").slice(0, 3))}
                  type="password"
                  inputMode="numeric"
                  placeholder="•••"
                  className={`font-mono mt-1.5 w-full rounded-lg border bg-ink-850 px-3.5 py-3 text-sm tracking-widest text-ink-100 outline-none transition-colors placeholder:text-ink-600 focus:border-flare-500/70 ${errors.cvc ? "border-beat-500" : "border-ink-600"}`}
                />
                {errors.cvc && <span className="mt-1 block text-[11px] font-semibold text-beat-400">{errors.cvc}</span>}
              </label>
            </div>

            <label className="mt-4 block">
              <span className="text-xs font-bold text-ink-300">E-mail для чека (необязательно)</span>
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                type="email"
                placeholder="you@mail.ru"
                className="mt-1.5 w-full rounded-lg border border-ink-600 bg-ink-850 px-3.5 py-3 text-sm font-semibold text-ink-100 outline-none transition-colors placeholder:font-medium placeholder:text-ink-600 focus:border-flare-500/70"
              />
            </label>

            <button
              type="submit"
              className="font-display mt-6 flex w-full items-center justify-center gap-2.5 rounded-xl bg-flare-500 py-3.5 text-sm font-bold text-ink-950 shadow-lg shadow-flare-500/25 transition-all duration-200 hover:bg-flare-400 active:scale-[0.98]"
            >
              <IcLock style={{ fontSize: 15 }} /> Заплатить 499 ₽
            </button>
            <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-[11px] font-medium text-ink-500">
              <IcCard style={{ fontSize: 13 }} /> Демо-контур: реальных списаний нет · данные карты никуда не уходят
            </p>
          </form>
        )}

        {step === "processing" && (
          <div className="flex flex-col items-center gap-4 px-6 py-14">
            <span className="vinyl flex h-14 w-14 items-center justify-center rounded-full border-4 border-ink-700 border-t-flare-400" />
            <p className="text-sm font-bold text-ink-200">Связываемся с сервером ЮKassa…</p>
            <p className="font-mono text-[11px] text-ink-500">создаём объект Payment · проверяем 3-D Secure</p>
          </div>
        )}

        {step === "success" && (
          <div className="flex flex-col items-center px-6 py-12 text-center">
            <span className="flex h-16 w-16 items-center justify-center rounded-full bg-wave-500/15 text-wave-400">
              <IcCheck style={{ fontSize: 30 }} />
            </span>
            <h3 className="font-display mt-4 text-xl font-black text-ink-100">Подписка активна!</h3>
            <p className="mt-2 max-w-xs text-sm font-medium text-ink-400">
              Beat Pro подключён на 30 дней. AI-студия и безлимит проектов уже доступны.
            </p>
            <p className="font-mono mt-3 rounded-full border border-ink-700 px-3 py-1.5 text-[11px] text-ink-500">
              платёж {paymentId} {demo && "· демо"}
            </p>
            <button
              type="button"
              onClick={onClose}
              className="font-display mt-6 rounded-full bg-flare-500 px-7 py-3 text-[13px] font-bold text-ink-950 transition-all duration-200 hover:bg-flare-400 active:scale-95"
            >
              В студию
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export function PricingPage({ nav }: { nav: Nav }) {
  const { pro, proUntil, cancelPro } = useStudio();
  const toast = useToast();
  const [paying, setPaying] = useState(false);
  const [faq, setFaq] = useState<number | null>(0);

  const FAQS = [
    ["Как работает списание?", "Подписка продлевается раз в месяц через ЮKassa — 499 ₽. Отмена в один клик прямо на этой странице, доступ сохраняется до конца оплаченного периода."],
    ["Это настоящий платёж?", "Платёжный контур повторяет интеграцию с ЮKassa: создание объекта Payment, 3-D Secure, чек на e-mail. В этой демонстрационной сборке реальных списаний нет — карта может быть любой (пройдёт даже тестовая)."],
    ["Что будет с проектами после отмены?", "Все биты останутся с тобой навсегда. Просто новые сохранения вернутся к лимиту Free-тарифа — 3 проекта."],
    ["Можно вернуть деньги?", "Да, в течение 3 дней с момента оплаты — напиши в чат поддержки, вернём без вопросов."],
  ];

  return (
    <div className="mx-auto max-w-5xl">
      <header className="mb-9 max-w-2xl">
        <p className="font-mono flex items-center gap-2 text-[11px] font-semibold tracking-[0.22em] text-flare-400 uppercase">
          <IcCrown style={{ fontSize: 15 }} /> Тарифы
        </p>
        <h1 className="font-display mt-2 text-3xl font-black tracking-tight text-ink-100 md:text-5xl">
          Один тариф. <span className="text-flare-400">Вся студия.</span>
        </h1>
        <p className="mt-3 text-[15px] font-medium text-ink-300">
          Beat Pro открывает AI-генерацию битов и снимает лимиты. Меньше, чем кофе навынос раз в неделю — примерно 16 ₽ в день.
        </p>
      </header>

      <div className="grid gap-6 md:grid-cols-[1fr_1.35fr]">
        {/* Free */}
        <Reveal>
          <section className="flex h-full flex-col rounded-2xl border border-ink-700/70 bg-ink-900/70 p-7">
            <p className="font-display text-sm font-bold tracking-wide text-ink-300 uppercase">Free</p>
            <p className="font-display mt-3 text-4xl font-black text-ink-100">0 ₽</p>
            <p className="mt-1 text-[13px] font-medium text-ink-500">навсегда</p>
            <ul className="mt-6 flex flex-col gap-3">
              {FREE_FEATURES.map((f) => (
                <li key={f} className="flex items-start gap-2.5 text-sm font-medium text-ink-300">
                  <IcCheck style={{ fontSize: 15 }} className="mt-0.5 shrink-0 text-ink-500" /> {f}
                </li>
              ))}
            </ul>
            <button
              type="button"
              onClick={() => nav({ name: "beat" })}
              className="font-display mt-auto w-full rounded-xl border border-ink-600 py-3.5 pt-3.5 text-[13px] font-bold text-ink-200 transition-all duration-200 hover:border-ink-400 hover:text-ink-100"
              style={{ marginTop: "auto", paddingTop: "14px" }}
            >
              Это мой план
            </button>
          </section>
        </Reveal>

        {/* Pro */}
        <Reveal delay={100}>
          <section
            className="relative flex h-full flex-col overflow-hidden rounded-2xl border border-flare-500/50 bg-ink-900 p-7 shadow-[0_0_60px_rgba(255,166,43,0.1)]"
          >
            <span className="pointer-events-none absolute -top-24 -right-24 h-64 w-64 rounded-full bg-flare-500/15 blur-3xl" />
            <div className="flex items-center justify-between">
              <p className="font-display flex items-center gap-2 text-sm font-bold tracking-wide text-flare-300 uppercase">
                <IcCrown style={{ fontSize: 16 }} /> Beat Pro
              </p>
              {pro && (
                <span className="rounded-full bg-wave-500/15 px-3 py-1 text-[10px] font-bold tracking-wider text-wave-300 uppercase">
                  активен до {proUntil}
                </span>
              )}
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <p className="font-display text-5xl font-black text-ink-100">499 ₽</p>
              <p className="text-[13px] font-semibold text-ink-400">/ месяц</p>
            </div>
            <p className="mt-1 text-[13px] font-medium text-ink-500">оплата картой через ЮKassa · отмена в один клик</p>

            <ul className="mt-6 flex flex-col gap-3">
              {PRO_FEATURES.map((f) => (
                <li key={f} className="flex items-start gap-2.5 text-sm font-semibold text-ink-200">
                  <IcCheck style={{ fontSize: 15 }} className="mt-0.5 shrink-0 text-flare-400" /> {f}
                </li>
              ))}
            </ul>

            <div className="mt-7 flex flex-col gap-3" style={{ marginTop: "auto", paddingTop: 28 }}>
              {pro ? (
                <button
                  type="button"
                  onClick={() => {
                    cancelPro();
                    toast("Подписка отменена — доступ до конца периода", "info");
                  }}
                  className="font-display w-full rounded-xl border border-ink-600 py-3.5 text-[13px] font-bold text-ink-300 transition-all duration-200 hover:border-beat-500/60 hover:text-beat-400"
                >
                  Отменить подписку
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setPaying(true)}
                  className="font-display flex w-full items-center justify-center gap-2.5 rounded-xl bg-flare-500 py-4 text-sm font-bold text-ink-950 shadow-lg shadow-flare-500/30 transition-all duration-200 hover:scale-[1.02] hover:bg-flare-400 active:scale-95"
                >
                  <IcCard style={{ fontSize: 17 }} /> Подключить за 499 ₽/мес
                </button>
              )}
              <button
                type="button"
                onClick={() => nav({ name: "ai" })}
                className="text-center text-[13px] font-bold text-ink-400 underline-offset-4 transition-colors hover:text-flare-300 hover:underline"
              >
                Сначала посмотреть AI-студию →
              </button>
            </div>
          </section>
        </Reveal>
      </div>

      {/* доверие + FAQ */}
      <div className="mt-10 grid gap-6 lg:grid-cols-[280px_minmax(0,1fr)]">
        <Reveal>
          <aside className="rounded-2xl border border-ink-700/70 bg-ink-900/70 p-6">
            <p className="font-display flex items-center gap-2 text-sm font-bold text-ink-100">
              <IcWave style={{ fontSize: 16 }} className="text-flare-400" /> ПочемуSoundscape
            </p>
            <ul className="mt-4 flex flex-col gap-3 text-[13px] font-medium text-ink-300">
              <li>· Платежи через ЮKassa — PCI DSS, 3-D Secure, чеки по 54-ФЗ</li>
              <li>· 9 треков чартов с реальным звуком уже в Free</li>
              <li>· Биты синтезируются локально — ноль задержек</li>
              <li>· Отмена в один клик, без «позвоните оператору»</li>
            </ul>
          </aside>
        </Reveal>
        <Reveal delay={80}>
          <section>
            <h2 className="font-display text-lg font-black text-ink-100">Вопросы про оплату</h2>
            <div className="mt-4 flex flex-col gap-2.5">
              {FAQS.map(([q, a], i) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => setFaq(faq === i ? null : i)}
                  className={`rounded-xl border p-4 text-left transition-all duration-300 ${
                    faq === i ? "border-flare-500/40 bg-ink-850" : "border-ink-700/70 bg-ink-900/60 hover:border-ink-500"
                  }`}
                >
                  <span className="flex items-center justify-between gap-3">
                    <span className="text-sm font-bold text-ink-100">{q}</span>
                    <span className={`font-mono text-flare-400 transition-transform duration-300 ${faq === i ? "rotate-45" : ""}`}>+</span>
                  </span>
                  <span
                    className="grid transition-all duration-300"
                    style={{ gridTemplateRows: faq === i ? "1fr" : "0fr" }}
                  >
                    <span className="overflow-hidden">
                      <span className="mt-2.5 block text-[13px] font-medium leading-relaxed text-ink-400">{a}</span>
                    </span>
                  </span>
                </button>
              ))}
            </div>
          </section>
        </Reveal>
      </div>

      {paying && <YooKassaModal onClose={() => setPaying(false)} />}
    </div>
  );
}
