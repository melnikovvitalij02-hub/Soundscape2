import { useMemo, useState } from "react";
import { DRUMS, DRUM_COLORS, STEPS, STYLES, generatePattern, type Pattern, type StyleKey } from "../audio/engine";
import type { Nav } from "../router";
import { emitEvent, useStudio } from "../state/StudioContext";
import { useToast } from "../state/ToastContext";
import { IcAi, IcBolt, IcCheck, IcCrown, IcLock } from "../components/icons2";
import { IcPause, IcPlay } from "../components/icons";

const PHASES = [
  "Анализирую запрос и настроение…",
  "Подбираю барабаны и грув…",
  "Пишу бас-линию…",
  "Расставляю акценты и свожу…",
];

function PatternViz({ pattern, dim }: { pattern: Pattern; dim?: boolean }) {
  return (
    <div className={`flex flex-col gap-1 ${dim ? "opacity-30 blur-[2px]" : ""}`}>
      {pattern.map((row, r) => (
        <div key={r} className="flex gap-[3px]">
          {row.map((on, c) => (
            <span
              key={c}
              className="h-2.5 flex-1 rounded-[3px]"
              style={{ background: on ? DRUM_COLORS[DRUMS[r]] : "#181e2c" }}
            />
          ))}
        </div>
      ))}
    </div>
  );
}

export function AiStudioPage({ nav }: { nav: Nav }) {
  const { pro, engine, projects, saveProject, playingProjectId, stopProject, playProject } = useStudio();
  const toast = useToast();
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState<StyleKey>("phonk");
  const [phase, setPhase] = useState<number>(-1); // -1 idle, 0..3 работа, 4 готово
  const [result, setResult] = useState<{ pattern: Pattern; bpm: number; style: StyleKey } | null>(null);
  const [playing, setPlaying] = useState(false);
  const [saved, setSaved] = useState(false);

  const previewPattern = useMemo(() => generatePattern("lofi").pattern, []);
  const aiBeats = projects.filter((p) => p.origin === "ai");

  const generate = async () => {
    setSaved(false);
    setPlaying(false);
    engine.stop();
    for (let i = 0; i < PHASES.length; i++) {
      setPhase(i);
      await new Promise((r) => setTimeout(r, 750 + Math.random() * 350));
    }
    const g = generatePattern(style);
    setResult({ ...g, style });
    setPhase(4);
    toast("Бит сгенерирован — жми «Играть»", "ok");
  };

  const togglePlay = () => {
    if (!result) return;
    if (playing) {
      engine.stop();
      setPlaying(false);
    } else {
      engine.setPattern(result.pattern);
      engine.setBpm(result.bpm);
      engine.onStep = null;
      engine.start();
      setPlaying(true);
    }
  };

  const save = () => {
    if (!result) return;
    const meta = STYLES.find((s) => s.key === result.style)!;
    const res = saveProject({
      name: prompt.trim() ? prompt.trim().slice(0, 32) : `AI · ${meta.label} ${aiBeats.length + 1}`,
      bpm: result.bpm,
      pattern: result.pattern,
      origin: "ai",
      style: meta.label,
    });
    if (res.ok) {
      emitEvent("beat-save");
      setSaved(true);
      toast("AI-бит сохранён в проекты", "ok");
    } else {
      toast("Лимит Free — 3 проекта. Сними его в Beat Pro", "info");
      nav({ name: "pricing" });
    }
  };

  const working = phase >= 0 && phase < 4;

  return (
    <div className="mx-auto max-w-5xl">
      <header className="mb-7">
        <p className="font-mono flex items-center gap-2 text-[11px] font-semibold tracking-[0.22em] text-wave-400 uppercase">
          <IcAi style={{ fontSize: 15 }} /> AI Студия
        </p>
        <h1 className="font-display mt-2 text-3xl font-black tracking-tight text-ink-100 md:text-4xl">
          Бит из одного запроса
        </h1>
        <p className="mt-2 max-w-xl text-[15px] font-medium text-ink-300">
          Опиши настроение, выбери стиль — нейромодель Soundscape соберёт барабаны, грув и бас-линию за пару секунд.
        </p>
      </header>

      {!pro ? (
        /* -------- пейволл -------- */
        <div className="grid gap-6 lg:grid-cols-[1.2fr_1fr]">
          <section className="relative overflow-hidden rounded-2xl border border-ink-700/70 bg-ink-900/70 p-7">
            <PatternViz pattern={previewPattern} dim />
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-ink-950/55 px-6 text-center backdrop-blur-[3px]">
              <span className="flex h-14 w-14 items-center justify-center rounded-full border border-flare-500/50 bg-flare-500/15 text-flare-400">
                <IcLock style={{ fontSize: 24 }} />
              </span>
              <h2 className="font-display text-xl font-black text-ink-100">AI-студия — часть Beat Pro</h2>
              <p className="max-w-sm text-sm font-medium text-ink-300">
                Генерация битов по запросу, безлимитные проекты и все будущие модели — за 499 ₽ в месяц.
              </p>
              <button
                type="button"
                onClick={() => nav({ name: "pricing" })}
                className="font-display mt-2 flex items-center gap-2 rounded-full bg-flare-500 px-6 py-3 text-[13px] font-bold text-ink-950 shadow-lg shadow-flare-500/25 transition-all duration-200 hover:scale-105 hover:bg-flare-400 active:scale-95"
              >
                <IcCrown style={{ fontSize: 16 }} /> Подключить за 499 ₽
              </button>
            </div>
          </section>
          <aside className="flex flex-col gap-4">
            {[
              ["Запрос → бит", "Пишешь «мрачный фонк для ночной езды» — получаешь готовый грув."],
              ["4 стилевые модели", "Фонк, лоу-фай, дрилл и хаус — каждая со своим характером."],
              ["Бит в проектах", "Любой сгенерированный бит можно докрутить в Beat Pro."],
            ].map(([t, d]) => (
              <div key={t} className="rounded-2xl border border-ink-700/70 bg-ink-900/70 p-5">
                <p className="font-display flex items-center gap-2 text-sm font-bold text-ink-100">
                  <IcBolt style={{ fontSize: 15 }} className="text-wave-400" /> {t}
                </p>
                <p className="mt-1.5 text-[13px] font-medium text-ink-400">{d}</p>
              </div>
            ))}
          </aside>
        </div>
      ) : (
        /* -------- студия -------- */
        <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
          <section className="rounded-2xl border border-ink-700/70 bg-ink-900/70 p-6 md:p-7">
            <label className="block">
              <span className="text-[13px] font-bold text-ink-200">Опиши бит (необязательно)</span>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                rows={2}
                maxLength={120}
                placeholder="Например: тёмный фонк для ночной поездки по МКАДу"
                className="mt-2 w-full resize-none rounded-xl border border-ink-600 bg-ink-850 px-4 py-3 text-sm font-semibold text-ink-100 outline-none transition-all duration-200 placeholder:font-medium placeholder:text-ink-500 focus:border-wave-500/70 focus:shadow-[0_0_0_4px_rgba(82,220,196,0.1)]"
              />
            </label>

            <div className="mt-4">
              <span className="text-[13px] font-bold text-ink-200">Стиль</span>
              <div className="mt-2.5 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
                {STYLES.map((s) => (
                  <button
                    key={s.key}
                    type="button"
                    onClick={() => setStyle(s.key)}
                    className={`rounded-xl border p-3.5 text-left transition-all duration-200 ${
                      style === s.key
                        ? "border-wave-500/70 bg-wave-500/10 shadow-[0_0_0_3px_rgba(82,220,196,0.12)]"
                        : "border-ink-600/80 bg-ink-850 hover:border-ink-400"
                    }`}
                  >
                    <p className={`text-[13px] font-bold ${style === s.key ? "text-wave-300" : "text-ink-100"}`}>{s.label}</p>
                    <p className="font-mono mt-0.5 text-[10px] text-ink-500">{s.bpm[0]}–{s.bpm[1]} BPM</p>
                  </button>
                ))}
              </div>
            </div>

            <button
              type="button"
              onClick={generate}
              disabled={working}
              className="font-display mt-6 flex w-full items-center justify-center gap-2.5 rounded-xl bg-wave-500 py-4 text-sm font-bold text-ink-950 shadow-lg shadow-wave-500/20 transition-all duration-200 hover:bg-wave-400 active:scale-[0.99] disabled:cursor-wait disabled:opacity-70 sm:w-auto sm:px-8"
            >
              <IcAi style={{ fontSize: 18 }} />
              {working ? "Генерация…" : "Сгенерировать бит"}
            </button>

            {working && (
              <div className="mt-6 rounded-xl border border-wave-500/30 bg-wave-500/5 p-4">
                <div className="flex items-center gap-3">
                  <span className="eq text-wave-400" style={{ height: 16 }}>
                    <i /><i /><i /><i />
                  </span>
                  <p className="text-sm font-bold text-wave-300">{PHASES[phase]}</p>
                </div>
                <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-ink-700">
                  <div
                    className="h-full rounded-full bg-wave-400 transition-all duration-700 ease-out"
                    style={{ width: `${((phase + 1) / PHASES.length) * 100}%` }}
                  />
                </div>
              </div>
            )}

            {phase === 4 && result && (
              <div className="page-enter mt-6 rounded-xl border border-ink-600 bg-ink-850 p-5">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="font-display text-sm font-bold text-ink-100">
                      {STYLES.find((s) => s.key === result.style)!.label} · {result.bpm} BPM
                    </p>
                    <p className="font-mono mt-0.5 text-[11px] text-ink-500">
                      {result.pattern.flat().filter(Boolean).length} ударов · 16 шагов · модель v2.6
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={togglePlay}
                      className={`font-display flex items-center gap-2 rounded-full px-4 py-2 text-xs font-bold transition-all duration-200 active:scale-95 ${
                        playing ? "bg-ink-100 text-ink-950" : "bg-flare-500 text-ink-950 hover:bg-flare-400"
                      }`}
                    >
                      {playing ? <IcPause style={{ fontSize: 13 }} /> : <IcPlay style={{ fontSize: 13 }} />}
                      {playing ? "Пауза" : "Играть"}
                    </button>
                    <button
                      type="button"
                      onClick={save}
                      disabled={saved}
                      className="font-display flex items-center gap-2 rounded-full border border-wave-500/60 px-4 py-2 text-xs font-bold text-wave-300 transition-all duration-200 hover:bg-wave-500/10 active:scale-95 disabled:opacity-50"
                    >
                      <IcCheck style={{ fontSize: 13 }} /> {saved ? "В проектах" : "В проекты"}
                    </button>
                  </div>
                </div>
                <div className="mt-4">
                  <PatternViz pattern={result.pattern} />
                </div>
              </div>
            )}
          </section>

          {/* история */}
          <aside className="rounded-2xl border border-ink-700/70 bg-ink-900/70 p-5">
            <h3 className="font-display text-sm font-bold text-ink-100">Мои AI-биты</h3>
            {aiBeats.length === 0 ? (
              <p className="mt-3 text-[13px] font-medium text-ink-500">
                Пока пусто. Сгенерируй первый бит — он появится здесь и в «Проектах».
              </p>
            ) : (
              <ul className="mt-3 flex flex-col gap-2">
                {aiBeats.slice(0, 6).map((p) => (
                  <li key={p.id} className="flex items-center gap-3 rounded-lg border border-ink-700/70 bg-ink-850 p-3">
                    <button
                      type="button"
                      aria-label={playingProjectId === p.id ? "Остановить" : "Играть"}
                      onClick={() => {
                        if (playingProjectId === p.id) stopProject();
                        else playProject(p);
                      }}
                      className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full transition-all active:scale-90 ${
                        playingProjectId === p.id ? "bg-flare-500 text-ink-950 shadow-[0_0_14px_rgba(255,166,43,0.4)]" : "bg-ink-700 text-ink-100 hover:bg-flare-500 hover:text-ink-950"
                      }`}
                    >
                      {playingProjectId === p.id ? <IcPause style={{ fontSize: 13 }} /> : <IcPlay style={{ fontSize: 13, marginLeft: 1 }} />}
                    </button>
                    <span className="min-w-0">
                      <span className="block truncate text-[13px] font-bold text-ink-100">{p.name}</span>
                      <span className="font-mono text-[10px] text-ink-500">{p.bpm} BPM · {p.style}</span>
                    </span>
                  </li>
                ))}
              </ul>
            )}
            <p className="font-mono mt-4 text-[10px] tracking-widest text-ink-600 uppercase">
              генерации не расходуют лимит проектов
            </p>
          </aside>
        </div>
      )}

      {/* мини-легенда STEPS */}
      <p className="font-mono mt-8 text-center text-[10px] tracking-[0.2em] text-ink-600 uppercase">
        сетка {STEPS} шагов · 5 дорожек · звук синтезируется в браузере
      </p>
    </div>
  );
}
