import { useEffect, useRef, useState } from "react";
import confetti from "canvas-confetti";
import { TRACKS, type Track } from "../data/music";
import type { Nav } from "../router";
import { QUESTS, XP_PER_LEVEL, emitEvent, useStudio } from "../state/StudioContext";
import { useToast } from "../state/ToastContext";
import { Avatar, Reveal } from "../components/bits";
import { IcBolt, IcCheck, IcCrown, IcGame } from "../components/icons2";
import { IcPlay } from "../components/icons";

function shuffle4(): { correct: Track; options: Track[] } {
  const pool = [...TRACKS];
  const correct = pool[Math.floor(Math.random() * pool.length)];
  const others = pool.filter((t) => t.id !== correct.id);
  const picks = [correct];
  while (picks.length < 4 && others.length) {
    picks.push(others.splice(Math.floor(Math.random() * others.length), 1)[0]);
  }
  return { correct, options: picks.sort(() => Math.random() - 0.5) };
}

function GuessGame() {
  const { engine, addXp } = useStudio();
  const toast = useToast();
  const [round, setRound] = useState<{ correct: Track; options: Track[] } | null>(null);
  const [answered, setAnswered] = useState<string | null>(null);
  const [streak, setStreak] = useState(0);
  const [score, setScore] = useState(0);
  const [best, setBest] = useState<number>(() => Number(localStorage.getItem("ss_best_streak") ?? 0));
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const stopTimer = useRef<number | null>(null);

  useEffect(
    () => () => {
      audioRef.current?.pause();
      if (stopTimer.current) window.clearTimeout(stopTimer.current);
    },
    []
  );

  const playSnippet = (t: Track) => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
      audioRef.current.volume = 0.9;
    }
    const a = audioRef.current;
    a.pause();
    a.src = t.src;
    const maxStart = Math.max(0, (t.duration || 40) - 14);
    a.currentTime = 6 + Math.random() * maxStart;
    void a.play().catch(() => {});
    if (stopTimer.current) window.clearTimeout(stopTimer.current);
    stopTimer.current = window.setTimeout(() => {
      a.pause();
      a.currentTime = 6 + Math.random() * maxStart;
    }, 6000);
  };

  const start = () => {
    const r = shuffle4();
    setRound(r);
    setAnswered(null);
    playSnippet(r.correct);
  };

  const answer = (id: string) => {
    if (!round || answered) return;
    setAnswered(id);
    audioRef.current?.pause();
    if (id === round.correct.id) {
      const ns = streak + 1;
      setStreak(ns);
      setScore((s) => s + 1);
      if (ns > best) {
        setBest(ns);
        localStorage.setItem("ss_best_streak", String(ns));
      }
      addXp(25);
      emitEvent("game-win");
      engine.hit("clap");
      if (ns % 3 === 0) {
        confetti({ particleCount: 90, spread: 70, origin: { y: 0.5 }, colors: ["#ffa62b", "#52dcc4", "#ff5470"] });
        toast(`Серия ${ns}! +25 XP`, "ok");
      }
    } else {
      setStreak(0);
      engine.hit("kick");
    }
  };

  return (
    <section className="rounded-2xl border border-ink-700/70 bg-ink-900/70 p-6 md:p-7">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-display flex items-center gap-2.5 text-xl font-black text-ink-100">
            <IcGame style={{ fontSize: 22 }} className="text-beat-400" /> Угадай трек
          </h2>
          <p className="mt-1 text-[13px] font-medium text-ink-400">
            6 секунд из реального трека чарта — выбери название. За каждое попадание +25 XP.
          </p>
        </div>
        <div className="font-mono flex gap-2 text-[11px] font-semibold tracking-wider uppercase">
          <span className="rounded-full border border-ink-600 px-3.5 py-1.5 text-ink-300">счёт: {score}</span>
          <span className="rounded-full border border-flare-500/50 px-3.5 py-1.5 text-flare-300">серия: {streak}</span>
          <span className="hidden rounded-full border border-ink-600 px-3.5 py-1.5 text-ink-400 sm:inline">рекорд: {best}</span>
        </div>
      </div>

      {!round ? (
        <div className="mt-6 flex flex-col items-center rounded-xl border border-dashed border-ink-600 px-6 py-12 text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-full bg-beat-500/12 text-beat-400">
            <IcPlay style={{ fontSize: 24, marginLeft: 3 }} />
          </span>
          <p className="font-display mt-4 text-lg font-bold text-ink-100">Готов проверить слух?</p>
          <p className="mt-1 max-w-xs text-sm font-medium text-ink-400">Все фрагменты — из настоящих треков чарта Soundscape.</p>
          <button
            type="button"
            onClick={start}
            className="font-display mt-5 rounded-full bg-beat-500 px-7 py-3 text-[13px] font-bold text-white shadow-lg shadow-beat-500/25 transition-all duration-200 hover:scale-105 hover:bg-beat-400 active:scale-95"
          >
            Начать игру
          </button>
        </div>
      ) : (
        <div className="mt-6">
          <div className="flex flex-wrap items-center gap-3 rounded-xl border border-ink-600 bg-ink-850 p-4">
            <button
              type="button"
              onClick={() => playSnippet(round.correct)}
              aria-label="Слушать фрагмент ещё раз"
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-ink-100 text-ink-950 transition-all duration-200 hover:scale-105 active:scale-95"
            >
              <IcPlay style={{ fontSize: 18, marginLeft: 2 }} />
            </button>
            <div>
              <p className="text-sm font-bold text-ink-100">Что это за трек?</p>
              <p className="font-mono text-[11px] text-ink-500">фрагмент 6 секунд · играет один раз, но можно повторить</p>
            </div>
            {answered && (
              <span className="eq ml-auto text-beat-400" style={{ height: 14 }}>
                <i /><i /><i /><i />
              </span>
            )}
          </div>

          <div className="mt-4 grid gap-2.5 sm:grid-cols-2">
            {round.options.map((t) => {
              const isCorrect = answered && t.id === round.correct.id;
              const isWrongPick = answered === t.id && t.id !== round.correct.id;
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => answer(t.id)}
                  disabled={!!answered}
                  className={`flex items-center gap-3 rounded-xl border p-3.5 text-left transition-all duration-200 ${
                    isCorrect
                      ? "border-wave-500/70 bg-wave-500/10"
                      : isWrongPick
                        ? "border-beat-500/70 bg-beat-500/10"
                        : answered
                          ? "border-ink-700 bg-ink-850 opacity-50"
                          : "border-ink-600 bg-ink-850 hover:-translate-y-0.5 hover:border-ink-400 hover:bg-ink-800 active:scale-[0.98]"
                  }`}
                >
                  <img src={t.cover} alt="" className="h-11 w-11 rounded-lg object-cover" />
                  <span className="min-w-0">
                    <span className={`block truncate text-sm font-bold ${isCorrect ? "text-wave-300" : isWrongPick ? "text-beat-400" : "text-ink-100"}`}>
                      {t.title}
                    </span>
                    <span className="block truncate text-[11px] font-medium text-ink-500">{t.artist}</span>
                  </span>
                  {isCorrect && <IcCheck style={{ fontSize: 16 }} className="ml-auto shrink-0 text-wave-300" />}
                </button>
              );
            })}
          </div>

          {answered && (
            <div className="page-enter mt-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-ink-600 bg-ink-850 px-4 py-3">
              <p className="text-sm font-bold text-ink-200">
                {answered === round.correct.id ? (
                  <span className="text-wave-300">Верно! Это «{round.correct.title}» · +25 XP</span>
                ) : (
                  <span className="text-beat-400">Мимо. Это было «{round.correct.title}» — {round.correct.artist}</span>
                )}
              </p>
              <button
                type="button"
                onClick={start}
                className="font-display flex items-center gap-2 rounded-full bg-flare-500 px-5 py-2.5 text-xs font-bold text-ink-950 transition-all duration-200 hover:bg-flare-400 active:scale-95"
              >
                Следующий раунд <IcPlay style={{ fontSize: 12 }} />
              </button>
            </div>
          )}
        </div>
      )}
    </section>
  );
}

export function GamesPage({ nav }: { nav: Nav }) {
  const { xp, level, levelProgress, questProgress, questClaimed, claimQuest } = useStudio();
  const toast = useToast();

  const doneCount = QUESTS.filter((q) => questProgress(q) >= q.target).length;

  return (
    <div className="mx-auto max-w-5xl">
      {/* шапка с уровнем */}
      <header className="mb-8 overflow-hidden rounded-2xl border border-ink-700/70 bg-ink-900/70">
        <div className="flex flex-wrap items-center gap-6 p-6 md:p-7">
          <div
            className="relative flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl"
            style={{ background: "conic-gradient(#ffa62b, #ff5470, #52dcc4, #ffa62b)" }}
          >
            <span className="absolute inset-[3px] flex items-center justify-center rounded-[13px] bg-ink-900">
              <span className="font-display text-2xl font-black text-flare-300">{level}</span>
            </span>
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
              <h1 className="font-display text-2xl font-black text-ink-100">Игры и квесты</h1>
              <span className="font-mono text-[11px] font-semibold tracking-wider text-ink-400 uppercase">
                {xp} XP всего
              </span>
            </div>
            <div className="mt-2.5 h-2.5 overflow-hidden rounded-full bg-ink-700">
              <div
                className="h-full rounded-full bg-gradient-to-r from-flare-500 to-wave-400 transition-all duration-700"
                style={{ width: `${Math.max(levelProgress * 100, 3)}%` }}
              />
            </div>
            <p className="mt-1.5 text-xs font-medium text-ink-400">
              До уровня {level + 1}: {XP_PER_LEVEL - (xp % XP_PER_LEVEL)} XP · слушай, создавай биты, играй
            </p>
          </div>
        </div>
      </header>

      {/* квесты дня */}
      <Reveal>
        <section className="mb-8">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-display flex items-center gap-2.5 text-lg font-black text-ink-100">
              <IcBolt style={{ fontSize: 19 }} className="text-flare-400" /> Квесты дня
            </h2>
            <span className="font-mono text-[11px] font-semibold tracking-wider text-ink-400 uppercase">
              выполнено {doneCount}/{QUESTS.length} · сброс в полночь
            </span>
          </div>
          <div className="stagger grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {QUESTS.map((q) => {
              const p = questProgress(q);
              const claimed = questClaimed(q);
              const done = p >= q.target;
              return (
                <article
                  key={q.id}
                  className={`rounded-xl border p-4.5 transition-all duration-300 ${
                    claimed
                      ? "border-ink-700/60 bg-ink-900/40 opacity-60"
                      : done
                        ? "border-wave-500/50 bg-wave-500/5"
                        : "border-ink-700/70 bg-ink-900/70"
                  }`}
                  style={{ padding: 18 }}
                >
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-sm font-bold text-ink-100">{q.title}</h3>
                    <span className="font-mono shrink-0 rounded-full bg-flare-500/12 px-2.5 py-1 text-[10px] font-bold text-flare-300">
                      +{q.xp} XP
                    </span>
                  </div>
                  <p className="mt-1 text-xs font-medium text-ink-400">{q.desc}</p>
                  <div className="mt-3.5 h-1.5 overflow-hidden rounded-full bg-ink-700">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${done ? "bg-wave-400" : "bg-flare-500"}`}
                      style={{ width: `${(p / q.target) * 100}%` }}
                    />
                  </div>
                  <div className="mt-3 flex items-center justify-between">
                    <span className="font-mono text-[11px] text-ink-500">
                      {p}/{q.target}
                    </span>
                    {claimed ? (
                      <span className="text-[11px] font-bold text-ink-500">Получено ✓</span>
                    ) : (
                      <button
                        type="button"
                        disabled={!done}
                        onClick={() => {
                          if (claimQuest(q)) {
                            confetti({ particleCount: 60, spread: 60, origin: { y: 0.7 }, colors: ["#52dcc4", "#ffa62b"] });
                            toast(`Квест «${q.title}» сдан: +${q.xp} XP`, "ok");
                          }
                        }}
                        className={`font-display rounded-full px-4 py-1.5 text-[11px] font-bold transition-all duration-200 ${
                          done
                            ? "bg-wave-500 text-ink-950 hover:bg-wave-400 active:scale-95"
                            : "cursor-not-allowed bg-ink-700 text-ink-500"
                        }`}
                      >
                        Забрать
                      </button>
                    )}
                  </div>
                </article>
              );
            })}
            {/* шестая плитка — подписка */}
            <article
              className="flex cursor-pointer flex-col justify-between rounded-xl border border-flare-500/40 bg-gradient-to-br from-flare-500/10 to-transparent p-4.5 transition-all duration-300 hover:-translate-y-0.5"
              style={{ padding: 18 }}
              onClick={() => nav({ name: "pricing" })}
            >
              <div>
                <h3 className="font-display flex items-center gap-2 text-sm font-bold text-flare-300">
                  <IcCrown style={{ fontSize: 15 }} /> Квест мецената
                </h3>
                <p className="mt-1 text-xs font-medium text-ink-400">Подключи Beat Pro — поддержи независимую музыкальную платформу.</p>
              </div>
              <span className="font-display mt-4 inline-block w-fit rounded-full border border-flare-500/60 px-4 py-1.5 text-[11px] font-bold text-flare-300 transition-colors hover:bg-flare-500/10">
                499 ₽/мес →
              </span>
            </article>
          </div>
        </section>
      </Reveal>

      {/* игра */}
      <Reveal delay={120}>
        <GuessGame />
      </Reveal>

      {/* друзья-рекордсмены */}
      <Reveal delay={180}>
        <section className="mt-8 rounded-2xl border border-ink-700/70 bg-ink-900/70 p-6">
          <h2 className="font-display text-lg font-black text-ink-100">Топ недели по XP</h2>
          <div className="mt-4 grid gap-2.5 sm:grid-cols-3">
            {[
              ["Кира Мельник", 2480, ["#ff5470", "#9be15d"] as [string, string]],
              ["Марк Гордин", 2110, ["#52dcc4", "#4f8dff"] as [string, string]],
              ["Соня Ким", 1890, ["#ff7d92", "#ffa62b"] as [string, string]],
            ].map(([n, x, c], i) => (
              <div key={n as string} className="flex items-center gap-3 rounded-xl border border-ink-700/60 bg-ink-850 p-3.5">
                <span className={`font-display w-6 text-center text-lg font-black ${i === 0 ? "text-flare-300" : "text-ink-500"}`}>{i + 1}</span>
                <Avatar name={n as string} colors={c as [string, string]} size={34} />
                <span className="min-w-0">
                  <span className="block truncate text-[13px] font-bold text-ink-100">{n as string}</span>
                  <span className="font-mono text-[10px] text-ink-500">{(x as number).toLocaleString("ru-RU")} XP</span>
                </span>
              </div>
            ))}
          </div>
          <p className="font-mono mt-4 text-center text-[10px] tracking-widest text-ink-600 uppercase">
            ты в этом списке на {Math.max(4, 8 - Math.floor(xp / 300))} месте — ещё пара квестов
          </p>
        </section>
      </Reveal>
    </div>
  );
}
