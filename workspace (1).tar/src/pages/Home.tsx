import { useMemo } from "react";
import { CHART, PLAYLISTS, chartIds, playlistById, trackById } from "../data/music";
import { ACTIVITIES, USERS, userById } from "../data/people";
import type { Nav } from "../router";
import { useAuth } from "../state/AuthContext";
import { usePlayer } from "../state/PlayerProvider";
import { QUESTS, useStudio } from "../state/StudioContext";
import { Avatar, Cover, Eq, Reveal, SectionTitle } from "../components/bits";
import { PlaylistCard, TrackRow } from "../components/tracks";
import { IcAi, IcBolt, IcCrown, IcDrum, IcGame, IcLock } from "../components/icons2";
import { IcPause, IcPlay, IcUp, IcWave } from "../components/icons";

const BARS = [26, 40, 30, 52, 36, 60, 44, 68, 48, 58, 38, 50, 32, 42, 28, 36, 22];

/* -------- планетная система жанров -------- */
interface Planet {
  g: string;
  n: string;
  d: string;
  q: string;
  ring?: boolean;
  bg: string;
  glow: string;
}
const PLANETS: Planet[] = [
  { g: "Электро-поп", n: "Вольтара", d: "Zivert · неон", q: "Zivert", ring: true, bg: "radial-gradient(circle at 32% 28%, #b9aaff, #7c5cf0 45%, #3b2a8f 78%)", glow: "rgba(139,92,246,0.55)" },
  { g: "Фолк-поп", n: "Славяна", d: "Куртукова · тепло", q: "folk", bg: "radial-gradient(circle at 32% 28%, #ffd9a0, #e08b4a 48%, #7c3f22 80%)", glow: "rgba(232,169,79,0.45)" },
  { g: "Поп", n: "Аурелия", d: "Дмитриенко · SABI", q: "pop", bg: "radial-gradient(circle at 32% 28%, #ffe9b8, #f0b45c 46%, #8a5a24 80%)", glow: "rgba(245,201,138,0.45)" },
  { g: "R&B", n: "Ноктюрна", d: "Xcho & MOT · ночь", q: "r&b", bg: "radial-gradient(circle at 32% 28%, #8f7bd9, #5a3fa8 48%, #241a56 80%)", glow: "rgba(120,90,220,0.55)" },
  { g: "Инди-поп", n: "Люмен", d: "ENZRO · свет", q: "indie", bg: "radial-gradient(circle at 32% 28%, #cfe0ff, #7f9fe8 48%, #33488f 80%)", glow: "rgba(150,175,255,0.45)" },
  { g: "Электроника", n: "Криос", d: "HOLLYFLAME · лёд", q: "electronic", bg: "radial-gradient(circle at 32% 28%, #aef3e4, #3fc9ae 48%, #14604f 80%)", glow: "rgba(79,216,192,0.45)" },
  { g: "Глитч-хоп", n: "Фракта", d: "BEARWOLF · глитч", q: "glitch", ring: true, bg: "radial-gradient(circle at 32% 28%, #f3b8d8, #d95c9d 48%, #6e2350 80%)", glow: "rgba(255,107,157,0.45)" },
  { g: "Хип-хоп", n: "Рубер", d: "Саян · бас", q: "hip-hop", bg: "radial-gradient(circle at 32% 28%, #ff9d8a, #d95340 48%, #6e221a 80%)", glow: "rgba(255,110,90,0.45)" },
];

/* -------- лента друзей -------- */
function ActivityFeed({ nav }: { nav: Nav }) {
  const player = usePlayer();

  return (
    <section className="rounded-2xl border border-ink-700/70 bg-ink-900/70 p-5">
      <div className="flex items-center justify-between">
        <h3 className="font-display text-sm font-bold text-ink-100">Лента друзей</h3>
        <button
          type="button"
          onClick={() => nav({ name: "friends" })}
          className="font-mono text-[10px] font-bold tracking-wider text-flare-400 uppercase transition-colors hover:text-flare-300"
        >
          Все друзья →
        </button>
      </div>
      <ul className="mt-4 flex flex-col gap-4">
        {ACTIVITIES.map((a) => {
          const u = userById(a.userId) ?? USERS[0];
          const t = a.trackId ? trackById(a.trackId) : undefined;
          const pl = a.playlistId ? playlistById(a.playlistId) : undefined;
          const isFriend = player.isFriend(u.id);
          const text =
            a.kind === "listen" && t
              ? <>слушает <button type="button" onClick={() => player.playTrack(t.id, [t.id])} className="font-bold text-flare-300 underline-offset-2 hover:underline">«{t.title}»</button></>
              : a.kind === "like" && t
                ? <>лайкает <button type="button" onClick={() => player.playTrack(t.id, [t.id])} className="font-bold text-flare-300 underline-offset-2 hover:underline">«{t.title}»</button></>
                : a.kind === "playlist" && pl
                  ? <>собрал(а) плейлист <button type="button" onClick={() => player.playTrack(pl.trackIds[0], pl.trackIds)} className="font-bold text-flare-300 underline-offset-2 hover:underline">«{pl.title}»</button></>
                  : <>теперь в Soundscape — поприветствуйте!</>;
          return (
            <li key={a.id} className="group flex items-start gap-3">
              <button type="button" onClick={() => nav({ name: "profile", id: u.id })} className="shrink-0 transition-transform hover:scale-105">
                <Avatar name={u.name} colors={u.colors} size={34} online={u.online} />
              </button>
              <div className="min-w-0 flex-1">
                <p className="text-[13px] leading-snug font-medium text-ink-300">
                  <button type="button" onClick={() => nav({ name: "profile", id: u.id })} className="font-bold text-ink-100 transition-colors hover:text-flare-300">
                    {u.name}
                  </button>{" "}
                  {text}
                </p>
                <p className="font-mono mt-0.5 text-[10px] text-ink-500">
                  {a.when}
                  {isFriend && <span className="ml-1.5 text-wave-400">· друг</span>}
                </p>
              </div>
              {t && (
                <button type="button" onClick={() => player.playTrack(t.id, [t.id])} aria-label="Слушать" className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-ink-800 text-ink-300 opacity-0 transition-all duration-200 hover:bg-flare-500 hover:text-ink-950 group-hover:opacity-100">
                  <IcPlay style={{ fontSize: 11, marginLeft: 1 }} />
                </button>
              )}
            </li>
          );
        })}
      </ul>
    </section>
  );
}

export function HomePage({ nav }: { nav: Nav }) {
  const { me } = useAuth();
  const player = usePlayer();
  const { questProgress, projects, pro, level, xp } = useStudio();

  const doneCount = QUESTS.filter((q) => questProgress(q) >= q.target).length;

  const greeting = useMemo(() => {
    const h = new Date().getHours();
    return h < 5 ? "Доброй ночи" : h < 12 ? "Доброе утро" : h < 18 ? "Добрый день" : "Добрый вечер";
  }, []);

  const hero = trackById(player.currentId) ?? trackById("t1")!;
  const heroPos = CHART.findIndex((c) => c.trackId === hero.id);

  const miniGrid = useMemo(
    () =>
      Array.from({ length: 24 }).map((_, i) => ({
        on: [0, 3, 4, 7, 8, 11, 12, 15, 16, 19, 20, 23].includes(i) ? (i % 8 < 4 ? "#ffa62b" : "#52dcc4") : "#181e2c",
      })),
    []
  );

  return (
    <div>
      {/* -------- приветствие + эфир -------- */}
      <Reveal>
        <header className="relative mb-9 overflow-hidden rounded-2xl border border-ink-700/70 bg-ink-900/70">
          <span
            className={`pointer-events-none absolute -top-24 -right-24 h-72 w-72 rounded-full blur-3xl transition-opacity duration-700 ${player.isPlaying ? "breathe" : "opacity-30"}`}
            style={{ background: hero.accent }}
          />
          <div className="relative flex flex-wrap items-center gap-7 p-7 md:p-9">
            <div className="min-w-0 flex-1">
              <p className="font-mono text-[11px] font-semibold tracking-[0.22em] text-flare-400 uppercase">
               Soundscape · чарт недели 7/2026
              </p>
              <h1 className="font-display mt-2.5 text-3xl leading-tight font-black tracking-tight text-ink-100 md:text-[42px]">
                {greeting}, {me?.name.split(" ")[0]}.
                <span className="block text-ink-300">Эфир уже тёплый.</span>
              </h1>
              <p className="mt-3 max-w-md text-[15px] font-medium text-ink-400">
                {player.isPlaying
                  ? `Сейчас играет «${hero.title}» — ${hero.artist}${heroPos >= 0 ? `, №${heroPos + 1} чарта` : ""}.`
                  : "В чарте девять треков, друзья уже слушают. Жми — и поехали."}
              </p>
              <div className="mt-6 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => (player.isPlaying ? player.togglePlay() : player.playTrack(chartIds[0], chartIds))}
                  className="font-display flex items-center gap-2.5 rounded-full bg-flare-500 px-7 py-3.5 text-[13px] font-bold text-ink-950 shadow-lg shadow-flare-500/30 transition-all duration-200 hover:scale-[1.04] hover:bg-flare-400 active:scale-95"
                >
                  {player.isPlaying ? <IcPause style={{ fontSize: 15 }} /> : <IcPlay style={{ fontSize: 15 }} />}
                  {player.isPlaying ? "Пауза" : "Слушать чарт"}
                </button>
                <button
                  type="button"
                  onClick={() => nav({ name: "games" })}
                  className="font-display flex items-center gap-2 rounded-full border border-ink-600 px-6 py-3.5 text-[13px] font-bold text-ink-200 transition-all duration-200 hover:border-flare-500/60 hover:text-flare-300"
                >
                  <IcBolt style={{ fontSize: 14 }} /> Квесты дня: {doneCount}/{QUESTS.length}
                </button>
              </div>
            </div>

            <div className="relative mx-auto hidden shrink-0 sm:block">
              <span className={`absolute -inset-7 rounded-full blur-3xl ${player.isPlaying ? "breathe" : "opacity-25"}`} style={{ background: hero.accent }} />
              <Cover src={hero.cover} alt={hero.title} className={`drift relative h-44 w-44 rounded-xl! md:h-52 md:w-52 ${player.isPlaying ? "ring-2 ring-flare-400/60" : ""}`} />
              <span className="font-mono absolute -bottom-3 left-1/2 -translate-x-1/2 rounded-full border border-ink-600 bg-ink-900 px-3 py-1 text-[10px] font-bold tracking-wider text-ink-300 uppercase">
                {player.isPlaying ? <Eq playing className="mr-1.5 inline-flex text-flare-400" style={{ height: 9 }} /> : null}
                в эфире
              </span>
            </div>
          </div>
        </header>
      </Reveal>

      {/* -------- студия: мозаика -------- */}
      <Reveal delay={80}>
        <section className="mb-10 grid gap-4 md:grid-cols-6">
          {/* AI-студия */}
          <button
            type="button"
            onClick={() => nav({ name: "ai" })}
            className="group relative overflow-hidden rounded-2xl border border-ink-700/70 bg-ink-900/70 p-6 text-left transition-all duration-300 hover:-translate-y-1 hover:border-wave-500/50 md:col-span-4"
          >
            <span className="pointer-events-none absolute -top-16 -right-10 h-48 w-48 rounded-full bg-wave-500/12 blur-3xl" />
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-wave-500/15 text-wave-400">
                <IcAi style={{ fontSize: 19 }} />
              </span>
              <h2 className="font-display text-lg font-black text-ink-100">AI Студия</h2>
              {!pro && (
                <span className="flex items-center gap-1 rounded-full bg-flare-500/15 px-2.5 py-1 text-[9px] font-bold tracking-wider text-flare-300 uppercase">
                  <IcLock style={{ fontSize: 10 }} /> Pro
                </span>
              )}
            </div>
            <p className="mt-2 max-w-sm text-sm font-medium text-ink-400">
              Опиши настроение — получи готовый бит: барабаны, грув и бас за несколько секунд.
            </p>
            <div className="mt-5 flex h-14 items-end gap-1" aria-hidden>
              {BARS.map((h, i) => (
                <i
                  key={i}
                  className="w-[5px] rounded-full"
                  style={{
                    height: `${h}px`,
                    background: i % 4 === 0 ? "#52dcc4" : i % 4 === 2 ? "#2cc2aa" : "#202839",
                    animation: `kf-eq ${1 + (i % 5) * 0.12}s ease-in-out infinite`,
                    animationDelay: `${-i * 0.15}s`,
                    opacity: 0.85,
                  }}
                />
              ))}
            </div>
          </button>

          {/* Beat Pro */}
          <button
            type="button"
            onClick={() => nav({ name: "beat" })}
            className="group rounded-2xl border border-ink-700/70 bg-ink-900/70 p-6 text-left transition-all duration-300 hover:-translate-y-1 hover:border-flare-500/50 md:col-span-2"
          >
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-flare-500/15 text-flare-400">
                <IcDrum style={{ fontSize: 19 }} />
              </span>
              <h2 className="font-display text-lg font-black text-ink-100">Beat Pro</h2>
            </div>
            <p className="mt-2 text-sm font-medium text-ink-400">Секвенсор: 16 шагов × 5 дорожек, звук прямо в браузере.</p>
            <div className="mt-5 grid grid-cols-8 gap-1" aria-hidden>
              {miniGrid.map((c, i) => (
                <span
                  key={i}
                  className="aspect-square rounded-[3px] transition-transform duration-200 group-hover:scale-105"
                  style={{ background: c.on, transitionDelay: `${i * 8}ms` }}
                />
              ))}
            </div>
          </button>

          {/* Квесты */}
          <button
            type="button"
            onClick={() => nav({ name: "games" })}
            className="group rounded-2xl border border-ink-700/70 bg-ink-900/70 p-6 text-left transition-all duration-300 hover:-translate-y-1 hover:border-beat-500/50 md:col-span-2"
          >
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-beat-500/15 text-beat-400">
                <IcGame style={{ fontSize: 19 }} />
              </span>
              <h2 className="font-display text-lg font-black text-ink-100">Квесты</h2>
            </div>
            <p className="mt-2 text-sm font-medium text-ink-400">
              Выполнено {doneCount} из {QUESTS.length} · уровень {level} · {xp} XP
            </p>
            <div className="mt-4 h-2 overflow-hidden rounded-full bg-ink-700">
              <div
                className="h-full rounded-full bg-gradient-to-r from-beat-500 to-flare-400 transition-all duration-700"
                style={{ width: `${(doneCount / QUESTS.length) * 100}%` }}
              />
            </div>
            <p className="font-mono mt-2.5 text-[10px] tracking-wider text-ink-500 uppercase">+ игра «Угадай трек»</p>
          </button>

          {/* Pro / студия */}
          {pro ? (
            <button
              type="button"
              onClick={() => nav({ name: "projects" })}
              className="group flex flex-col justify-between rounded-2xl border border-wave-500/40 bg-gradient-to-br from-wave-500/10 to-transparent p-6 text-left transition-all duration-300 hover:-translate-y-1 md:col-span-4"
            >
              <div className="flex items-center gap-2.5">
                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-wave-500/20 text-wave-300">
                  <IcCrown style={{ fontSize: 18 }} />
                </span>
                <h2 className="font-display text-lg font-black text-wave-300">Моя студия активна</h2>
              </div>
              <div className="mt-5 flex flex-wrap gap-x-8 gap-y-2">
                {[
                  [projects.length, "битов в проектах"],
                  [level, "уровень"],
                  [xp, "XP"],
                ].map(([v, l]) => (
                  <span key={l as string}>
                    <span className="font-display block text-2xl font-black text-ink-100">{v}</span>
                    <span className="text-[11px] font-bold tracking-wide text-ink-500 uppercase">{l}</span>
                  </span>
                ))}
              </div>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => nav({ name: "pricing" })}
              className="group relative overflow-hidden rounded-2xl border border-flare-500/45 bg-gradient-to-br from-flare-500/14 to-transparent p-6 text-left transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_0_40px_rgba(255,166,43,0.12)] md:col-span-4"
            >
              <div className="flex items-center gap-2.5">
                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-flare-500/20 text-flare-400">
                  <IcCrown style={{ fontSize: 18 }} />
                </span>
                <h2 className="font-display text-lg font-black text-flare-300">Beat Pro — 499 ₽/мес</h2>
              </div>
              <p className="mt-2 max-w-sm text-sm font-medium text-ink-300">
                AI-студия, безлимит битов и значок Pro. Оплата картой через ЮKassa, отмена в один клик.
              </p>
              <span className="font-display mt-5 inline-flex items-center gap-2 rounded-full bg-flare-500 px-5 py-2.5 text-xs font-bold text-ink-950 transition-transform duration-200 group-hover:scale-105">
                <IcUp style={{ fontSize: 13 }} /> Подключить
              </span>
            </button>
          )}
        </section>
      </Reveal>

      {/* -------- лента + чарт -------- */}
      <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_360px]">
        <div className="min-w-0">
          <Reveal>
            <section>
              <SectionTitle
                kicker="топ-5 недели"
                title="Чарт звучит так"
                right={
                  <button type="button" onClick={() => nav({ name: "charts" })} className="font-mono text-[11px] font-bold tracking-wider text-flare-400 uppercase transition-colors hover:text-flare-300">
                    Весь чарт →
                  </button>
                }
              />
              <div className="stagger rounded-xl border border-ink-700/70 bg-ink-900/60 p-2">
                {CHART.slice(0, 5).map((c, i) => {
                  const t = trackById(c.trackId)!;
                  return <TrackRow key={c.trackId} track={t} pos={i + 1} context={chartIds} />;
                })}
              </div>
            </section>
          </Reveal>

          <Reveal delay={100}>
            <section className="planets-sec">
              <div className="mb-1 flex flex-wrap items-end justify-between gap-3 px-1">
                <div>
                  <p className="font-mono flex items-center gap-2 text-[11px] font-semibold tracking-[0.2em] text-flare-300 uppercase">
                    Планетная система жанров
                  </p>
                  <h2 className="font-display mt-1.5 text-xl font-black tracking-tight text-ink-100 md:text-2xl">
                    Выбери планету — она зазвучит
                  </h2>
                </div>
                <p className="max-w-[300px] text-right text-xs font-medium text-ink-400">
                  Каждая планета — жанр. Клик по сфере — треки жанра, «весь мир» — поиск по каталогу планеты.
                </p>
              </div>
              <div className="orbit-line" aria-hidden />
              <div className="planet-row stagger">
                {PLANETS.map((p, i) => (
                  <div key={p.n} className="pnode">
                    <button
                      type="button"
                      className="psphere"
                      aria-label={`Жанр ${p.g}`}
                      title={`${p.n} · ${p.g}`}
                      onClick={() => nav({ name: "search", query: p.g, mode: "local" })}
                      style={{
                        background: p.bg,
                        ["--pglow" as never]: p.glow,
                        animationDelay: `${(-i * 0.9).toFixed(1)}s`,
                      }}
                    >
                      {p.ring ? <span className="pring" /> : null}
                    </button>
                    <b className="font-mono text-[10px] font-semibold tracking-[0.14em] text-ink-300 uppercase">{p.n}</b>
                    <small className="-mt-1 text-[11px] font-semibold text-ink-500">{p.d}</small>
                    <button type="button" className="pworld" onClick={() => nav({ name: "search", query: p.q, mode: "global" })}>
                      весь мир →
                    </button>
                  </div>
                ))}
              </div>
            </section>
          </Reveal>

          <Reveal delay={120}>
            <section className="mt-10">
              <SectionTitle kicker="подборки редакции" title="Плейлисты под настроение" />
              <div className="stagger -mx-2 flex gap-5 overflow-x-auto px-2 pb-2">
                {PLAYLISTS.map((pl) => (
                  <PlaylistCard key={pl.id} pl={pl} />
                ))}
              </div>
            </section>
          </Reveal>
        </div>

        <Reveal delay={80}>
          <aside>
            <ActivityFeed nav={nav} />
            <section className="mt-6 rounded-2xl border border-ink-700/70 bg-ink-900/70 p-5">
              <h3 className="font-display flex items-center gap-2 text-sm font-bold text-ink-100">
                <IcWave style={{ fontSize: 15 }} className="text-wave-400" /> Быстрый старт
              </h3>
              <ul className="mt-3 flex flex-col gap-2">
                {[
                  ["Найди любой трек в мире", () => nav({ name: "search" })],
                  ["Собери бит в Beat Pro", () => nav({ name: "beat" })],
                  ["Напиши другу в чат", () => nav({ name: "chat" })],
                ].map(([label, go]) => (
                  <li key={label as string}>
                    <button
                      type="button"
                      onClick={go as () => void}
                      className="group flex w-full items-center justify-between rounded-lg border border-ink-700/60 bg-ink-850 px-3.5 py-2.5 text-left text-[13px] font-bold text-ink-300 transition-all duration-200 hover:border-ink-500 hover:text-ink-100"
                    >
                      {label as string}
                      <span className="text-ink-600 transition-all duration-200 group-hover:translate-x-0.5 group-hover:text-flare-400">→</span>
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          </aside>
        </Reveal>
      </div>
    </div>
  );
}
