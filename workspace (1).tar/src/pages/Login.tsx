import { useState, type FormEvent } from "react";
import { useAuth } from "../state/AuthContext";
import { useToast } from "../state/ToastContext";
import { IcAi, IcBolt, IcDrum, IcGlobe } from "../components/icons2";
import { IcWave as IcWaveOld, IcWave } from "../components/icons";

const PAIRS: [string, string][] = [
  ["#ffa62b", "#ff5470"],
  ["#52dcc4", "#4f8dff"],
  ["#ff7d92", "#ffa62b"],
  ["#9be15d", "#2cc2aa"],
  ["#4f8dff", "#9be15d"],
  ["#ff5470", "#52dcc4"],
];

const TICKER = [
  { icon: <IcWaveOld style={{ fontSize: 15 }} />, label: "Чарты с реальным звуком" },
  { icon: <IcAi style={{ fontSize: 15 }} />, label: "AI-студия битов" },
  { icon: <IcDrum style={{ fontSize: 15 }} />, label: "Beat Pro-секвенсор" },
  { icon: <IcGlobe style={{ fontSize: 15 }} />, label: "Поиск любого трека в мире" },
  { icon: <IcBolt style={{ fontSize: 15 }} />, label: "Квесты и XP" },
];

const BARS = [18, 34, 26, 44, 30, 52, 38, 60, 42, 54, 32, 46, 24, 38, 20, 30, 16];

export function LoginPage() {
  const { login } = useAuth();
  const toast = useToast();
  const [name, setName] = useState("");
  const [pair, setPair] = useState(0);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (name.trim().length < 2) return;
    login(name, PAIRS[pair]);
    toast(`Добро пожаловать в Soundscape, ${name.trim()}!`, "ok");
  };

  return (
    <div className="relative flex min-h-screen items-center overflow-hidden px-5 py-10 md:px-12">
      {/* фоновые свечения */}
      <span className="pointer-events-none absolute -top-32 right-[-10%] h-[480px] w-[480px] rounded-full bg-flare-500/10 blur-3xl" />
      <span className="pointer-events-none absolute bottom-[-20%] left-[-8%] h-[420px] w-[420px] rounded-full bg-wave-500/10 blur-3xl" />

      <div className="mx-auto grid w-full max-w-5xl items-center gap-12 lg:grid-cols-[1.15fr_1fr]">
        {/* левая часть — характер платформы */}
        <div className="page-enter">
          <div className="flex h-20 items-end gap-[5px]" aria-hidden>
            {BARS.map((h, i) => (
              <i
                key={i}
                className="w-[5px] rounded-full"
                style={{
                  height: `${h * 1.6}px`,
                  background: i % 3 === 0 ? "#ffa62b" : i % 3 === 1 ? "#52dcc4" : "#2b3550",
                  animation: "kf-eq 1.15s ease-in-out infinite",
                  animationDelay: `${-i * 0.13}s`,
                }}
              />
            ))}
          </div>

          <h1
            className="font-display mt-6 text-[44px] leading-[0.95] font-black tracking-tight text-ink-100 sm:text-6xl xl:text-7xl"
            style={{ textShadow: "5px 5px 0 rgba(255,166,43,0.22), 10px 10px 0 rgba(82,220,196,0.12)" }}
          >
            SOUND
            <span className="text-flare-400">SCAPE</span>
          </h1>
          <p className="mt-5 max-w-md text-lg font-semibold text-ink-300">
            Музыкальная соцсеть, которой ещё нет в РФ: чарты, друзья, AI-студия битов и мировой поиск — всё в одном месте.
          </p>

          <div className="mt-8 flex flex-wrap gap-2.5">
            {TICKER.map((t) => (
              <span
                key={t.label}
                className="flex items-center gap-2 rounded-full border border-ink-700 bg-ink-900/70 px-3.5 py-2 text-[13px] font-bold text-ink-300 transition-colors duration-200 hover:border-ink-500 hover:text-ink-100"
              >
                <span className="text-flare-400">{t.icon}</span>
                {t.label}
              </span>
            ))}
          </div>

          <p className="font-mono mt-10 text-[11px] tracking-[0.22em] text-ink-500 uppercase">
            9 треков в чарте · 8 друзей онлайн · 16 шагов в секвенсоре
          </p>
        </div>

        {/* правая часть — вход */}
        <form
          onSubmit={submit}
          className="page-enter rounded-2xl border border-ink-700 bg-ink-900/80 p-7 shadow-2xl shadow-black/50 backdrop-blur sm:p-9"
          style={{ animationDelay: "0.12s" }}
        >
          <p className="font-mono text-[11px] font-semibold tracking-[0.22em] text-flare-400 uppercase">Вход / регистрация</p>
          <h2 className="font-display mt-2 text-2xl font-black text-ink-100">Создай свой профиль</h2>
          <p className="mt-1.5 text-sm font-medium text-ink-400">Аккаунт живёт в этом браузере — без почты и паролей.</p>

          <label className="mt-7 block">
            <span className="text-[13px] font-bold text-ink-200">Как тебя зовут?</span>
            <input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={24}
              placeholder="Например, Даниил"
              className="mt-2 w-full rounded-xl border border-ink-600 bg-ink-850 px-4 py-3.5 text-base font-semibold text-ink-100 outline-none transition-all duration-200 placeholder:font-medium placeholder:text-ink-500 focus:border-flare-500/70 focus:shadow-[0_0_0_4px_rgba(255,166,43,0.12)]"
            />
          </label>

          <div className="mt-5">
            <span className="text-[13px] font-bold text-ink-200">Цвет профиля</span>
            <div className="mt-2.5 flex flex-wrap gap-3">
              {PAIRS.map((p, i) => (
                <button
                  key={i}
                  type="button"
                  aria-label={`Вариант ${i + 1}`}
                  onClick={() => setPair(i)}
                  className={`h-10 w-10 rounded-full transition-all duration-200 hover:scale-110 ${
                    pair === i ? "ring-2 ring-white/80 ring-offset-2 ring-offset-ink-900 scale-110" : ""
                  }`}
                  style={{ background: `linear-gradient(135deg, ${p[0]}, ${p[1]})` }}
                />
              ))}
            </div>
          </div>

          <button
            type="submit"
            disabled={name.trim().length < 2}
            className="font-display mt-8 flex w-full items-center justify-center gap-2.5 rounded-xl bg-flare-500 py-4 text-sm font-bold text-ink-950 shadow-lg shadow-flare-500/25 transition-all duration-200 hover:bg-flare-400 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40 disabled:shadow-none"
          >
            Войти в Soundscape
            <IcWave style={{ fontSize: 17 }} />
          </button>
          <p className="mt-4 text-center text-xs font-medium text-ink-500">
            Нажимая «Войти», ты соглашаешься слушать хорошую музыку каждый день
          </p>
        </form>
      </div>
    </div>
  );
}
