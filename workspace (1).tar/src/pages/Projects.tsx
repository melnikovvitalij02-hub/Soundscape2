import { useState } from "react";
import { DRUMS, DRUM_COLORS } from "../audio/engine";
import type { Nav, Route } from "../router";
import { useStudio } from "../state/StudioContext";
import { useToast } from "../state/ToastContext";
import { Reveal } from "../components/bits";
import { IcAi, IcDrum, IcTrash } from "../components/icons2";
import { IcPause, IcPlay } from "../components/icons";

function MiniViz({ pattern, active }: { pattern: boolean[][]; active: boolean }) {
  return (
    <div className="flex flex-col gap-[3px]">
      {pattern.map((row, r) => (
        <div key={r} className="flex gap-[3px]">
          {row.map((on, c) => (
            <span
              key={c}
              className={`h-2 flex-1 rounded-[2px] transition-opacity duration-300 ${active ? "" : "opacity-70"}`}
              style={{ background: on ? DRUM_COLORS[DRUMS[r]] : "#181e2c" }}
            />
          ))}
        </div>
      ))}
    </div>
  );
}

export function ProjectsPage({ nav }: { nav: Nav }) {
  const { projects, playingProjectId, engineStep, playProject, stopProject, deleteProject, pro } = useStudio();
  const toast = useToast();
  const [confirming, setConfirming] = useState<string | null>(null);

  const fmtDate = (ts: number) =>
    new Date(ts).toLocaleDateString("ru-RU", { day: "numeric", month: "short" }) +
    " · " +
    new Date(ts).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });

  return (
    <div className="mx-auto max-w-5xl">
      <header className="mb-7 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono flex items-center gap-2 text-[11px] font-semibold tracking-[0.22em] text-flare-400 uppercase">
            <IcDrum style={{ fontSize: 15 }} /> Проекты
          </p>
          <h1 className="font-display mt-2 text-3xl font-black tracking-tight text-ink-100 md:text-4xl">Твоя бит-полка</h1>
          <p className="mt-2 text-[15px] font-medium text-ink-300">
            Сохранённые биты из Beat Pro и генерации AI-студии. Играют прямо здесь — без экспорта и рендера.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className="font-mono rounded-full border border-ink-600 px-4 py-2 text-[11px] font-semibold tracking-wider text-ink-300 uppercase">
            {pro ? `${projects.length} · безлимит` : `${projects.length}/3 · Free`}
          </span>
          <button
            type="button"
            onClick={() => nav({ name: "beat" })}
            className="font-display flex items-center gap-2 rounded-full bg-flare-500 px-5 py-2.5 text-[13px] font-bold text-ink-950 shadow-lg shadow-flare-500/20 transition-all duration-200 hover:bg-flare-400 active:scale-95"
          >
            <IcPlay style={{ fontSize: 13 }} /> Новый бит
          </button>
        </div>
      </header>

      {projects.length === 0 ? (
        <Reveal>
          <div className="flex flex-col items-center rounded-2xl border border-dashed border-ink-600 bg-ink-900/40 px-6 py-16 text-center">
            <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-ink-800 text-flare-400">
              <IcDrum style={{ fontSize: 30 }} />
            </span>
            <h2 className="font-display mt-5 text-xl font-bold text-ink-100">Проектов пока нет</h2>
            <p className="mt-2 max-w-sm text-sm font-medium text-ink-400">
              Собери первый бит в секвенсоре или сгенерируй в AI-студии — он появится здесь со своим звуком.
            </p>
            <div className="mt-6 flex gap-3">
              <button
                type="button"
                onClick={() => nav({ name: "beat" })}
                className="font-display rounded-full bg-flare-500 px-6 py-3 text-[13px] font-bold text-ink-950 transition-all duration-200 hover:bg-flare-400 active:scale-95"
              >
                Открыть Beat Pro
              </button>
              <button
                type="button"
                onClick={() => nav({ name: "ai" })}
                className="font-display flex items-center gap-2 rounded-full border border-ink-600 px-6 py-3 text-[13px] font-bold text-ink-200 transition-all duration-200 hover:border-wave-500/60 hover:text-wave-300"
              >
                <IcAi style={{ fontSize: 15 }} /> AI-студия
              </button>
            </div>
          </div>
        </Reveal>
      ) : (
        <div className="stagger grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {projects.map((p) => {
            const active = playingProjectId === p.id;
            return (
              <article
                key={p.id}
                className={`group flex flex-col rounded-2xl border bg-ink-900/70 p-5 transition-all duration-300 hover:-translate-y-1 ${
                  active ? "border-flare-500/60 shadow-[0_0_30px_rgba(255,166,43,0.12)]" : "border-ink-700/70 hover:border-ink-500"
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="truncate text-[15px] font-bold text-ink-100">{p.name}</h3>
                    <p className="font-mono mt-0.5 text-[11px] text-ink-500">
                      {p.bpm} BPM · {fmtDate(p.createdAt)}
                    </p>
                  </div>
                  <span
                    className={`flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-bold tracking-wider uppercase ${
                      p.origin === "ai" ? "bg-wave-500/15 text-wave-300" : "bg-flare-500/15 text-flare-300"
                    }`}
                  >
                    {p.origin === "ai" ? <IcAi style={{ fontSize: 11 }} /> : <IcDrum style={{ fontSize: 11 }} />}
                    {p.origin === "ai" ? "AI" : "Beat Pro"}
                  </span>
                </div>

                <div className="mt-4">
                  <MiniViz pattern={p.pattern} active={active} />
                </div>

                <div className="mt-4 flex items-center gap-2 border-t border-ink-700/60 pt-4">
                  <button
                    type="button"
                    onClick={() => (active ? stopProject() : playProject(p))}
                    aria-label={active ? "Остановить" : "Играть"}
                    className={`flex h-10 w-10 items-center justify-center rounded-full transition-all duration-200 active:scale-90 ${
                      active
                        ? "bg-ink-100 text-ink-950 shadow-[0_0_18px_rgba(255,166,43,0.4)]"
                        : "bg-ink-700 text-ink-100 hover:bg-flare-500 hover:text-ink-950"
                    }`}
                  >
                    {active ? <IcPause style={{ fontSize: 16 }} /> : <IcPlay style={{ fontSize: 16, marginLeft: 2 }} />}
                  </button>
                  {active && (
                    <span className="flex items-center gap-2 text-[11px] font-bold text-flare-300">
                      <span className="eq text-flare-400" style={{ height: 11 }}><i /><i /><i /><i /></span>
                      играет · шаг {engineStep + 1 > 0 ? engineStep + 1 : "—"}
                    </span>
                  )}
                  <div className="ml-auto">
                    {confirming === p.id ? (
                      <span className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            deleteProject(p.id);
                            setConfirming(null);
                            toast(`Проект «${p.name}» удалён`, "info");
                          }}
                          className="rounded-full bg-beat-500 px-3 py-1.5 text-[11px] font-bold text-white transition-all hover:bg-beat-400 active:scale-95"
                        >
                          Удалить
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirming(null)}
                          className="rounded-full border border-ink-600 px-3 py-1.5 text-[11px] font-bold text-ink-300 hover:text-ink-100"
                        >
                          Нет
                        </button>
                      </span>
                    ) : (
                      <button
                        type="button"
                        aria-label="Удалить проект"
                        onClick={() => setConfirming(p.id)}
                        className="flex h-9 w-9 items-center justify-center rounded-full text-ink-500 transition-all duration-200 hover:bg-beat-500/15 hover:text-beat-400"
                      >
                        <IcTrash style={{ fontSize: 16 }} />
                      </button>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}

export type { Route };
