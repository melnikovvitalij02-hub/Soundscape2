import { useState } from "react";
import { PLAYLISTS, TRACKS, trackById } from "../data/music";
import { ME, USERS } from "../data/people";
import type { Nav } from "../router";
import { usePlayer } from "../state/PlayerProvider";
import { Collage, Cover, Reveal, SectionTitle } from "../components/bits";
import { PlaylistCard, TrackRow } from "../components/tracks";
import { IcChart, IcHeart, IcHeartFill, IcNote, IcPlay, IcUsers } from "../components/icons";

type Tab = "liked" | "playlists" | "albums";

const TABS: { key: Tab; label: string }[] = [
  { key: "liked", label: "Любимое" },
  { key: "playlists", label: "Плейлисты" },
  { key: "albums", label: "Синглы" },
];

export function LibraryPage({ nav }: { nav: Nav }) {
  const { liked, friends, playTrack } = usePlayer();
  const [tab, setTab] = useState<Tab>("liked");

  const likedTracks = liked.map((id) => trackById(id)).filter((t): t is NonNullable<typeof t> => Boolean(t));
  const likedContext = likedTracks.map((t) => t.id);
  const topGenre = "Поп";

  return (
    <div className="mx-auto max-w-5xl">
      <header className="mb-7">
        <p className="font-mono text-[11px] font-semibold tracking-[0.22em] text-flare-400 uppercase">Моя коллекция</p>
        <h1 className="font-display mt-2 text-3xl font-black tracking-tight text-ink-100 md:text-4xl">Библиотека</h1>
        <p className="mt-2 text-[15px] font-medium text-ink-300">
          Всё, что вы лайкнули и собрали — всегда под рукой, даже офлайн.
        </p>
      </header>

      {/* статистика */}
      <div className="stagger mb-8 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          { icon: IcHeartFill, label: "любимых треков", value: String(liked.length), color: "text-beat-400" },
          { icon: IcUsers, label: "друзей", value: String(friends.length), color: "text-wave-400" },
          { icon: IcNote, label: "минут за неделю", value: ME.minutesWeek.toLocaleString("ru-RU"), color: "text-flare-400" },
          { icon: IcChart, label: "любимый жанр", value: topGenre, color: "text-flare-400" },
        ].map((s, i) => (
          <div key={i} className="rounded-xl border border-ink-700/70 bg-ink-900/70 p-4 transition-colors duration-200 hover:border-ink-500">
            <s.icon style={{ fontSize: 17 }} className={s.color} />
            <p className="font-display mt-2 text-xl font-black text-ink-100">{s.value}</p>
            <p className="font-mono text-[10px] font-semibold tracking-widest text-ink-500 uppercase">{s.label}</p>
          </div>
        ))}
      </div>

      {/* вкладки */}
      <div className="mb-6 flex gap-2">
        {TABS.map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => setTab(t.key)}
            className={`rounded-full px-5 py-2.5 text-[13px] font-bold transition-all duration-200 ${
              tab === t.key
                ? "bg-flare-500 text-ink-950 shadow-lg shadow-flare-500/20"
                : "border border-ink-600/80 text-ink-300 hover:border-ink-400 hover:text-ink-100"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "liked" &&
        (likedTracks.length === 0 ? (
          <Reveal>
            <div className="mt-10 flex flex-col items-center rounded-2xl border border-dashed border-ink-600 px-6 py-16 text-center">
              <span className="flex h-20 w-20 items-center justify-center rounded-full bg-ink-850 text-beat-400">
                <IcHeart style={{ fontSize: 34 }} />
              </span>
              <h2 className="font-display mt-5 text-xl font-bold text-ink-100">Пока ни одного лайка</h2>
              <p className="mt-2 max-w-sm text-sm font-medium text-ink-400">
                Жмите на сердечко у трека — он появится здесь и в волне рекомендаций. Начните с чарта недели.
              </p>
              <button
                type="button"
                onClick={() => nav({ name: "charts" })}
                className="font-display mt-6 flex items-center gap-2 rounded-full bg-flare-500 px-6 py-3 text-[13px] font-bold text-ink-950 shadow-lg shadow-flare-500/25 transition-all duration-200 hover:scale-[1.04] hover:bg-flare-400"
              >
                <IcChart style={{ fontSize: 15 }} /> Открыть чарт
              </button>
            </div>
          </Reveal>
        ) : (
          <Reveal>
            <section>
              <div className="mb-4 flex items-center gap-4">
                <Collage trackIds={likedContext} className="h-20 w-20 shadow-2xl shadow-black/50" />
                <div>
                  <p className="font-mono text-[10px] font-semibold tracking-[0.2em] text-ink-500 uppercase">автосборка</p>
                  <h2 className="font-display text-lg font-bold text-ink-100">Моё любимое</h2>
                  <p className="font-mono text-xs text-ink-400">{likedTracks.length} треков</p>
                </div>
                <button
                  type="button"
                  onClick={() => playTrack(likedContext[0], likedContext)}
                  className="font-display ml-auto flex items-center gap-2 rounded-full bg-flare-500 px-5 py-2.5 text-[12px] font-bold text-ink-950 shadow-lg shadow-flare-500/20 transition-all duration-200 hover:scale-[1.04] hover:bg-flare-400 active:scale-95"
                >
                  <IcPlay style={{ fontSize: 14 }} /> Слушать
                </button>
              </div>
              <div className="rounded-xl border border-ink-700/70 bg-ink-900/60 p-2">
                {likedTracks.map((t, i) => (
                  <TrackRow key={t.id} track={t} pos={i + 1} context={likedContext} showPlays={false} />
                ))}
              </div>
            </section>
          </Reveal>
        ))}

      {tab === "playlists" && (
        <div>
          <SectionTitle kicker="редакция + ваше" title="Плейлисты" />
          <div className="grid grid-cols-2 gap-x-5 gap-y-7 sm:grid-cols-3 lg:grid-cols-4">
            {PLAYLISTS.map((pl, i) => (
              <Reveal key={pl.id} delay={i * 60}>
                <PlaylistCard pl={pl} width="w-full" />
              </Reveal>
            ))}
          </div>
        </div>
      )}

      {tab === "albums" && (
        <div>
          <SectionTitle kicker="синглы из чарта" title="Релизы 2022–2026" />
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {TRACKS.map((t, i) => (
              <Reveal key={t.id} delay={i * 40}>
                <button
                  type="button"
                  onClick={() => playTrack(t.id, [t.id])}
                  className="group flex w-full flex-col rounded-xl border border-ink-700/70 bg-ink-900/70 p-3 text-left transition-all duration-300 hover:-translate-y-1 hover:border-ink-500 hover:bg-ink-850"
                >
                  <Cover src={t.cover} alt={t.title} className="aspect-square w-full rounded-lg!">
                    <span className="absolute inset-0 flex items-center justify-center bg-ink-950/40 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                      <span className="flex h-11 w-11 items-center justify-center rounded-full bg-flare-500 text-ink-950 shadow-xl transition-transform duration-200 group-hover:scale-110">
                        <IcPlay style={{ fontSize: 17, marginLeft: 2 }} />
                      </span>
                    </span>
                  </Cover>
                  <span className="mt-3 truncate text-sm font-bold text-ink-100 group-hover:text-flare-300">{t.title}</span>
                  <span className="truncate text-xs font-medium text-ink-400">{t.artist}</span>
                  <span className="font-mono mt-1 text-[10px] tracking-wider text-ink-500 uppercase">
                    сингл · {t.year} · {t.genre}
                  </span>
                </button>
              </Reveal>
            ))}
          </div>
          <p className="font-mono mt-6 text-center text-[10px] tracking-widest text-ink-500 uppercase">
            каталог Soundscape · {USERS.length} авторов волн · {TRACKS.length} релизов
          </p>
        </div>
      )}
    </div>
  );
}
