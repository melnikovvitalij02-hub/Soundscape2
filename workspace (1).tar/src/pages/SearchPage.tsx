import { useEffect, useMemo, useRef, useState } from "react";
import { CHART, PLAYLISTS, TRACKS, chartIds, fmtTime, trackById } from "../data/music";
import { USERS, fmtNum } from "../data/people";
import type { Nav } from "../router";
import { usePlayer } from "../state/PlayerProvider";
import { emitEvent } from "../state/StudioContext";
import { useToast } from "../state/ToastContext";
import { resolveFullStream, searchItunes, searchSoundCloud, toPlayable, type GlobalTrack } from "../services";
import { Avatar, Eq, Reveal, SectionTitle } from "../components/bits";
import { PlaylistCard, TrackCard, TrackRow } from "../components/tracks";
import { IcApple, IcExternal, IcGlobe } from "../components/icons2";
import { IcClose, IcNote, IcPause, IcPlay, IcSearch, IcUsers, IcWave } from "../components/icons";

type Tab = "all" | "tracks" | "artists" | "friends" | "playlists";
type Mode = "local" | "global";

const TABS: { key: Tab; label: string }[] = [
  { key: "all", label: "Всё" },
  { key: "tracks", label: "Треки" },
  { key: "artists", label: "Артисты" },
  { key: "friends", label: "Друзья" },
  { key: "playlists", label: "Плейлисты" },
];

const SUGGESTIONS = ["Zivert", "Матушка", "Шёлк", "R&B", "BEARWOLF", "фолк"];
const GLOBAL_SUGGESTIONS = ["The Weeknd", "Billie Eilish", "Kendrick Lamar", "Daft Punk", "Земфира", "Coldplay"];

export function SearchPage({ query, mode: initialMode, nav }: { query?: string; mode?: Mode; nav: Nav }) {
  const [q, setQ] = useState(query ?? "");
  const [tab, setTab] = useState<Tab>("all");
  const [mode, setMode] = useState<Mode>(initialMode ?? "local");
  const inputRef = useRef<HTMLInputElement>(null);
  const toast = useToast();
  const { playTrack, isFriend, currentId, isPlaying } = usePlayer();

  /* ---------- мировой поиск: SoundCloud (полные) → iTunes (превью) ---------- */
  const [gResults, setGResults] = useState<GlobalTrack[]>([]);
  const [gLoading, setGLoading] = useState(false);
  const [gError, setGError] = useState(false);
  const [gQuery, setGQuery] = useState("");
  const [gSource, setGSource] = useState<"soundcloud" | "itunes">("soundcloud");
  const [resolvingId, setResolvingId] = useState<string | null>(null);

  useEffect(() => {
    if (mode !== "global" || q.trim().length < 2) {
      setGResults([]);
      setGError(false);
      return;
    }
    const h = window.setTimeout(async () => {
      setGLoading(true);
      setGError(false);
      const norm = q.trim();
      try {
        let res = await searchSoundCloud(norm);
        if (res.length) {
          setGSource("soundcloud");
        } else {
          res = await searchItunes(norm);
          setGSource("itunes");
        }
        setGResults(res);
        setGQuery(norm);
      } catch {
        try {
          const res = await searchItunes(norm);
          setGSource("itunes");
          setGResults(res);
          setGQuery(norm);
        } catch {
          setGError(true);
        }
      } finally {
        setGLoading(false);
      }
    }, 450);
    return () => window.clearTimeout(h);
  }, [q, mode]);

  const playGlobal = async (g: GlobalTrack) => {
    const queue = gResults.map((x) => `g${x.key}`);
    if (g.source === "itunes") {
      toPlayable(g);
      playTrack(`g${g.key}`, queue);
      emitEvent("global-play");
      return;
    }
    if (resolvingId) return;
    setResolvingId(g.key);
    try {
      const { src, hls } = await resolveFullStream(g);
      if (!src && !hls) throw new Error("no stream");
      toPlayable(g, { src: src ?? "", hlsUrl: hls });
      playTrack(`g${g.key}`, queue);
      emitEvent("global-play");
    } catch {
      toast("SoundCloud не отдал поток — попробуй другой трек", "info");
    } finally {
      setResolvingId(null);
    }
  };

  /* ---------- локальный поиск ---------- */
  const norm = q.trim().toLowerCase();
  const res = useMemo(() => {
    const tracks = norm
      ? TRACKS.filter(
          (t) =>
            t.title.toLowerCase().includes(norm) ||
            t.artist.toLowerCase().includes(norm) ||
            t.genre.toLowerCase().includes(norm)
        )
      : [];
    const artistNames = [...new Set(tracks.map((t) => t.artist))];
    const friends = norm
      ? USERS.filter(
          (u) =>
            u.name.toLowerCase().includes(norm) ||
            u.username.toLowerCase().includes(norm) ||
            u.bio.toLowerCase().includes(norm) ||
            u.tags.some((t) => t.toLowerCase().includes(norm))
        )
      : [];
    const playlists = norm
      ? PLAYLISTS.filter(
          (p) => p.title.toLowerCase().includes(norm) || p.desc.toLowerCase().includes(norm) || p.tag.toLowerCase().includes(norm)
        )
      : [];
    return { tracks, artistNames, friends, playlists };
  }, [norm]);

  const total = res.tracks.length + res.artistNames.length + res.friends.length + res.playlists.length;
  const chartPos = (id: string) => {
    const i = CHART.findIndex((c) => c.trackId === id);
    return i === -1 ? null : i + 1;
  };

  return (
    <div className="mx-auto max-w-4xl">
      <header className="mb-6">
        <p className="font-mono text-[11px] font-semibold tracking-[0.22em] text-flare-400 uppercase">Поиск по Soundscape</p>
        <h1 className="font-display mt-2 text-3xl font-black tracking-tight text-ink-100 md:text-4xl">Что будем искать?</h1>
      </header>

      <Reveal>
        <div className="group flex items-center gap-3 rounded-xl border border-ink-600/80 bg-ink-850 px-4 py-3.5 transition-all duration-300 focus-within:border-flare-500/70 focus-within:shadow-[0_0_0_4px_rgba(139,92,246,0.14)]">
          {mode === "global" ? (
            <IcGlobe style={{ fontSize: 20 }} className="shrink-0 text-wave-400" />
          ) : (
            <IcSearch style={{ fontSize: 20 }} className="shrink-0 text-ink-400 transition-colors group-focus-within:text-flare-400" />
          )}
          <input
            ref={inputRef}
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={mode === "global" ? "Абсолютно любой трек в мире — артист или название…" : "Трек, артист, друг или жанр…"}
            className="w-full bg-transparent text-lg font-semibold text-ink-100 outline-none placeholder:font-medium placeholder:text-ink-500"
          />
          {q && (
            <button
              type="button"
              aria-label="Очистить"
              onClick={() => {
                setQ("");
                inputRef.current?.focus();
              }}
              className="shrink-0 rounded-full bg-ink-700 p-1.5 text-ink-300 transition-colors hover:bg-ink-600 hover:text-ink-100"
            >
              <IcClose style={{ fontSize: 14 }} />
            </button>
          )}
        </div>
        <div className="mt-3.5 flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setMode("global")}
            className={`flex items-center gap-2 rounded-full px-4 py-2 text-[13px] font-bold transition-all duration-200 ${
              mode === "global" ? "bg-wave-500 text-ink-950 shadow-lg shadow-wave-500/20" : "border border-ink-600 text-ink-300 hover:border-ink-400 hover:text-ink-100"
            }`}
          >
            <IcGlobe style={{ fontSize: 15 }} /> Во всём мире · SoundCloud
          </button>
          <button
            type="button"
            onClick={() => setMode("local")}
            className={`flex items-center gap-2 rounded-full px-4 py-2 text-[13px] font-bold transition-all duration-200 ${
              mode === "local" ? "bg-flare-500 text-ink-950 shadow-lg shadow-flare-500/20" : "border border-ink-600 text-ink-300 hover:border-ink-400 hover:text-ink-100"
            }`}
          >
            <IcWave style={{ fontSize: 14 }} /> В Soundscape
          </button>
          <span className="font-mono ml-1 hidden text-[10px] tracking-wider text-ink-600 uppercase sm:block">
            {mode === "global" ? "полные версии треков · играет в общем плеере" : "чарты · друзья · плейлисты"}
          </span>
        </div>
      </Reveal>

      {mode === "global" ? (
        <div className="mt-8">
          {!norm && (
            <Reveal>
              <p className="font-mono text-[11px] font-semibold tracking-[0.2em] text-ink-400 uppercase">Ищи кого угодно — от The Weeknd до Земфиры</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {GLOBAL_SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => {
                      setQ(s.trim());
                      inputRef.current?.focus();
                    }}
                    className="rounded-full border border-ink-600/80 px-4 py-2 text-sm font-bold text-ink-200 transition-all duration-200 hover:-translate-y-0.5 hover:border-wave-500/60 hover:text-wave-300"
                  >
                    {s.trim()}
                  </button>
                ))}
              </div>
              <p className="mt-5 max-w-lg text-[13px] font-medium text-ink-500">
                Работает настоящий SoundCloud API: находятся полные версии треков и играют прямо в плеере. Если SoundCloud молчит — автоматически включается каталог iTunes.
              </p>
            </Reveal>
          )}

          {gLoading && (
            <div className="mt-8 rounded-xl border border-ink-700/70 bg-ink-900/60 p-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="flex items-center gap-4 px-2 py-2.5">
                  <span className="h-12 w-12 shrink-0 animate-pulse rounded-md bg-ink-750" />
                  <span className="flex-1">
                    <span className="block h-3.5 w-1/3 animate-pulse rounded bg-ink-750" />
                    <span className="mt-2 block h-2.5 w-1/4 animate-pulse rounded bg-ink-800" />
                  </span>
                </div>
              ))}
            </div>
          )}

          {!gLoading && gError && (
            <Reveal>
              <div className="mt-8 flex flex-col items-center rounded-2xl border border-dashed border-ink-600 px-6 py-14 text-center">
                <span className="flex h-14 w-14 items-center justify-center rounded-full bg-beat-500/12 text-beat-400">
                  <IcGlobe style={{ fontSize: 26 }} />
                </span>
                <p className="font-display mt-4 text-lg font-bold text-ink-100">Мир не отвечает</p>
                <p className="mt-1.5 max-w-sm text-sm font-medium text-ink-400">SoundCloud и iTunes сейчас недоступны. Проверь интернет и попробуй ещё раз.</p>
                <button
                  type="button"
                  onClick={() => setQ(q + " ")}
                  className="font-display mt-5 rounded-full border border-ink-600 px-6 py-2.5 text-[13px] font-bold text-ink-200 transition-all hover:border-wave-500/60 hover:text-wave-300"
                >
                  Повторить запрос
                </button>
              </div>
            </Reveal>
          )}

          {!gLoading && !gError && norm && gResults.length === 0 && (
            <Reveal>
              <div className="mt-10 flex flex-col items-center text-center">
                <span className="flex h-20 w-20 items-center justify-center rounded-full border border-dashed border-ink-600 text-ink-500">
                  <IcNote style={{ fontSize: 34 }} />
                </span>
                <h2 className="font-display mt-5 text-xl font-bold text-ink-100">Во всём мире по «{q}» — пусто</h2>
                <p className="mt-2 max-w-sm text-sm font-medium text-ink-400">Странно, но бывает: попробуй написать артиста по-английски или сократить запрос.</p>
              </div>
            </Reveal>
          )}

          {!gLoading && !gError && gResults.length > 0 && (
            <Reveal>
              <section>
                <SectionTitle
                  kicker={gSource === "soundcloud" ? `SoundCloud · по запросу «${gQuery}»` : `iTunes (резерв) · по запросу «${gQuery}»`}
                  title={gSource === "soundcloud" ? `${gResults.length} полных версий` : `Найдено ${gResults.length} превью`}
                />
                <div className="stagger rounded-xl border border-ink-700/70 bg-ink-900/60 p-2">
                  {gResults.map((g, i) => {
                    const pid = `g${g.key}`;
                    const active = currentId === pid;
                    const resolving = resolvingId === g.key;
                    return (
                      <div
                        key={`${gSource}-${g.key}`}
                        onDoubleClick={() => playGlobal(g)}
                        className={`group flex items-center gap-3.5 rounded-lg px-2.5 py-2 transition-colors duration-150 md:gap-4 ${
                          active ? "bg-ink-800" : "hover:bg-ink-850"
                        }`}
                      >
                        <span className="font-mono w-6 text-center text-xs text-ink-500">{i + 1}</span>
                        <img src={g.cover} alt="" className="h-11 w-11 shrink-0 rounded-md object-cover ring-1 ring-white/10" />
                        <span className="min-w-0 flex-1">
                          <span className={`block truncate text-sm font-bold ${active ? "text-wave-300" : "text-ink-100"}`}>{g.title}</span>
                          <span className="block truncate text-xs font-medium text-ink-400">
                            {g.artist}
                            {g.source === "itunes" && g.album && <span className="text-ink-500"> · {g.album}</span>}
                          </span>
                        </span>
                        <span
                          className={`font-mono hidden shrink-0 rounded-full border px-2.5 py-1 text-[9px] font-bold tracking-wider uppercase sm:block ${
                            g.source === "soundcloud"
                              ? "border-flare-500/40 text-flare-300"
                              : "border-wave-500/40 text-wave-300"
                          }`}
                        >
                          {g.source === "soundcloud" ? "полная версия" : "превью 30 c"}
                        </span>
                        <span className="font-mono w-10 text-right text-[11px] text-ink-500 tabular-nums">
                          {g.source === "soundcloud" ? fmtTime(g.duration) : "0:30"}
                        </span>
                        {active && isPlaying && <Eq playing className="shrink-0 text-wave-400" />}
                        <button
                          type="button"
                          aria-label="Слушать"
                          onClick={() => playGlobal(g)}
                          disabled={resolving}
                          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-ink-700 text-ink-100 opacity-100 transition-all duration-200 hover:bg-flare-500 hover:text-ink-950 active:scale-90 disabled:opacity-60 md:opacity-0 md:group-hover:opacity-100"
                        >
                          {resolving ? (
                            <span className="h-4 w-4 animate-spin rounded-full border-2 border-ink-300 border-t-transparent" />
                          ) : active && isPlaying ? (
                            <IcPause style={{ fontSize: 14 }} />
                          ) : (
                            <IcPlay style={{ fontSize: 14, marginLeft: 2 }} />
                          )}
                        </button>
                        {g.url && (
                          <a
                            href={g.url}
                            target="_blank"
                            rel="noreferrer"
                            aria-label="Открыть источник"
                            className="hidden h-9 w-9 shrink-0 items-center justify-center rounded-full text-ink-500 transition-all duration-200 hover:bg-ink-700 hover:text-ink-100 sm:flex"
                          >
                            <IcExternal style={{ fontSize: 15 }} />
                          </a>
                        )}
                      </div>
                    );
                  })}
                </div>
                <p className="font-mono mt-3 flex items-center justify-center gap-1.5 text-center text-[10px] tracking-widest text-ink-600 uppercase">
                  {gSource === "soundcloud" ? (
                    <>SoundCloud API · полные треки · двойной клик — играть</>
                  ) : (
                    <>
                      <IcApple style={{ fontSize: 12 }} /> данные и превью — Apple iTunes Search API
                    </>
                  )}
                </p>
              </section>
            </Reveal>
          )}
        </div>
      ) : norm && total === 0 ? (
        <Reveal>
          <div className="mt-14 flex flex-col items-center text-center">
            <span className="flex h-20 w-20 items-center justify-center rounded-full border border-dashed border-ink-600 text-ink-500">
              <IcNote style={{ fontSize: 34 }} />
            </span>
            <h2 className="font-display mt-5 text-xl font-bold text-ink-100">В Soundscape по «{q}» пусто</h2>
            <p className="mt-2 max-w-md text-sm font-medium text-ink-400">
              Зато во всём мире наверняка найдётся — там весь SoundCloud планеты.
            </p>
            <button
              type="button"
              onClick={() => setMode("global")}
              className="font-display mt-5 flex items-center gap-2 rounded-full bg-wave-500 px-6 py-3 text-[13px] font-bold text-ink-950 transition-all duration-200 hover:bg-wave-400 active:scale-95"
            >
              <IcGlobe style={{ fontSize: 15 }} /> Искать во всём мире
            </button>
          </div>
        </Reveal>
      ) : !norm ? (
        <div className="mt-8">
          <Reveal>
            <p className="font-mono text-[11px] font-semibold tracking-[0.2em] text-ink-400 uppercase">Попробуйте найти</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => {
                    setQ(s);
                    inputRef.current?.focus();
                  }}
                  className="rounded-full border border-ink-600/80 px-4 py-2 text-sm font-bold text-ink-200 transition-all duration-200 hover:-translate-y-0.5 hover:border-flare-500/60 hover:text-flare-300"
                >
                  {s}
                </button>
              ))}
            </div>
          </Reveal>
          <Reveal delay={120}>
            <section className="mt-10">
              <SectionTitle kicker="Прямо сейчас" title="В тренде у друзей" />
              <div className="stagger -mx-2 flex gap-5 overflow-x-auto px-2 pb-2">
                {chartIds.slice(0, 6).map((id) => (
                  <TrackCard key={id} track={trackById(id)!} context={chartIds} />
                ))}
              </div>
            </section>
          </Reveal>
        </div>
      ) : (
        <div className="mt-6">
          <div className="mb-6 flex flex-wrap gap-2">
            {TABS.map((t) => (
              <button
                key={t.key}
                type="button"
                onClick={() => setTab(t.key)}
                className={`rounded-full px-4 py-2 text-[13px] font-bold transition-all duration-200 ${
                  tab === t.key
                    ? "bg-flare-500 text-ink-950 shadow-lg shadow-flare-500/20"
                    : "border border-ink-600/80 text-ink-300 hover:border-ink-400 hover:text-ink-100"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {(tab === "all" || tab === "tracks") && res.tracks.length > 0 && (
            <Reveal>
              <section className="mb-8">
                <SectionTitle kicker={`найдено: ${res.tracks.length}`} title="Треки" />
                <div className="rounded-xl border border-ink-700/70 bg-ink-900/60 p-2">
                  {res.tracks.map((t) => {
                    const pos = chartPos(t.id);
                    return (
                      <TrackRow
                        key={t.id}
                        track={t}
                        context={res.tracks.map((x) => x.id)}
                        trend={pos ? <span className="font-mono text-[11px] text-ink-500">#{pos} в чарте</span> : undefined}
                      />
                    );
                  })}
                </div>
              </section>
            </Reveal>
          )}

          {(tab === "all" || tab === "artists") && res.artistNames.length > 0 && (
            <Reveal delay={60}>
              <section className="mb-8">
                <SectionTitle kicker={`найдено: ${res.artistNames.length}`} title="Артисты" />
                <div className="flex flex-wrap gap-4">
                  {res.artistNames.map((a) => {
                    const t = TRACKS.find((x) => x.artist === a)!;
                    return (
                      <button
                        key={a}
                        type="button"
                        onClick={() => {
                          setTab("tracks");
                          setQ(a);
                        }}
                        className="group flex w-40 flex-col items-center rounded-xl border border-ink-700/70 bg-ink-900/60 p-5 transition-all duration-300 hover:-translate-y-1 hover:border-ink-500 hover:bg-ink-850"
                      >
                        <img
                          src={t.cover}
                          alt={a}
                          className="h-24 w-24 rounded-full object-cover shadow-xl shadow-black/50 ring-2 ring-ink-600 transition-transform duration-300 group-hover:scale-105"
                        />
                        <p className="mt-3 truncate text-sm font-bold text-ink-100 group-hover:text-flare-300">{a}</p>
                        <p className="font-mono text-[11px] text-ink-500">{t.plays} прослушиваний</p>
                      </button>
                    );
                  })}
                </div>
              </section>
            </Reveal>
          )}

          {(tab === "all" || tab === "friends") && res.friends.length > 0 && (
            <Reveal delay={120}>
              <section className="mb-8">
                <SectionTitle kicker={`найдено: ${res.friends.length}`} title="Люди" />
                <div className="grid gap-3 sm:grid-cols-2">
                  {res.friends.map((u) => {
                    const t = trackById(u.listening ?? undefined);
                    const friend = isFriend(u.id);
                    return (
                      <button
                        key={u.id}
                        type="button"
                        onClick={() => nav({ name: "profile", id: u.id })}
                        className="group flex items-center gap-3.5 rounded-xl border border-ink-700/70 bg-ink-900/60 p-4 text-left transition-all duration-300 hover:-translate-y-0.5 hover:border-ink-500 hover:bg-ink-850"
                      >
                        <Avatar name={u.name} colors={u.colors} size={46} online={u.online} />
                        <span className="min-w-0 flex-1">
                          <span className="flex items-center gap-2">
                            <span className="truncate text-sm font-bold text-ink-100 group-hover:text-flare-300">{u.name}</span>
                            {friend && (
                              <span className="rounded bg-wave-500/15 px-1.5 py-0.5 text-[9px] font-bold tracking-wider text-wave-300 uppercase">друг</span>
                            )}
                          </span>
                          <span className="font-mono block truncate text-[11px] text-ink-500">@{u.username} · {fmtNum(u.followers)} подписчиков</span>
                          <span className="mt-0.5 flex items-center gap-1.5 truncate text-[11px] font-medium text-ink-400">
                            {t ? (
                              <>
                                <Eq playing className="text-wave-400" style={{ height: 9 }} /> слушает «{t.title}»
                              </>
                            ) : u.online ? (
                              "в сети"
                            ) : (
                              `был(а) ${u.lastSeen}`
                            )}
                          </span>
                        </span>
                        <IcUsers style={{ fontSize: 18 }} className="shrink-0 text-ink-500 transition-colors group-hover:text-wave-400" />
                      </button>
                    );
                  })}
                </div>
              </section>
            </Reveal>
          )}

          {(tab === "all" || tab === "playlists") && res.playlists.length > 0 && (
            <Reveal delay={180}>
              <section className="mb-8">
                <SectionTitle kicker={`найдено: ${res.playlists.length}`} title="Плейлисты" />
                <div className="flex flex-wrap gap-6">
                  {res.playlists.map((pl) => (
                    <PlaylistCard key={pl.id} pl={pl} />
                  ))}
                </div>
              </section>
            </Reveal>
          )}
        </div>
      )}
    </div>
  );
}
