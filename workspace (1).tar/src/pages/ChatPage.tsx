import { useEffect, useMemo, useRef, useState } from "react";
import { trackById } from "../data/music";
import { USERS, userById } from "../data/people";
import type { Nav } from "../router";
import { useStudio } from "../state/StudioContext";
import { Avatar, Eq } from "../components/bits";
import { IcChat, IcSend } from "../components/icons2";
import { IcBack } from "../components/icons";

const fmtTs = (ts: number) =>
  new Date(ts).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });

export function ChatPage({ nav }: { nav: Nav }) {
  const { chat, unread, typing, sendMessage, markRead, setDialogActive } = useStudio();
  const [active, setActive] = useState<string | null>(null);
  const [text, setText] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  const dialogs = useMemo(() => {
    const lastTs = (id: string) => {
      const msgs = chat[id] ?? [];
      return msgs.length ? msgs[msgs.length - 1].ts : 0;
    };
    return [...USERS].sort((a, b) => lastTs(b.id) - lastTs(a.id));
  }, [chat]);

  useEffect(() => {
    setDialogActive(active);
    if (active) markRead(active);
    return () => setDialogActive(null);
  }, [active, markRead, setDialogActive]);

  const msgs = active ? chat[active] ?? [] : [];
  const friend = active ? userById(active) : null;

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [msgs.length, typing, active]);

  const send = () => {
    const t = text.trim();
    if (!t || !active) return;
    sendMessage(active, t);
    setText("");
  };

  return (
    <div className="mx-auto max-w-5xl">
      <header className="mb-6">
        <p className="font-mono text-[11px] font-semibold tracking-[0.22em] text-flare-400 uppercase">Сообщения</p>
        <h1 className="font-display mt-2 text-3xl font-black tracking-tight text-ink-100 md:text-4xl">Чат</h1>
      </header>

      <div className="grid overflow-hidden rounded-2xl border border-ink-700/70 bg-ink-900/70 md:grid-cols-[300px_minmax(0,1fr)]" style={{ height: "min(640px, calc(100vh - 320px))" }}>
        {/* список диалогов */}
        <aside className={`${active ? "hidden md:flex" : "flex"} min-h-0 flex-col border-r border-ink-700/70`}>
          <div className="border-b border-ink-700/70 px-4 py-3">
            <p className="font-mono text-[10px] font-semibold tracking-widest text-ink-500 uppercase">
              {dialogs.filter((d) => (unread[d.id] ?? 0) > 0).length} непрочитанных
            </p>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto p-2">
            {dialogs.map((u) => {
              const last = (chat[u.id] ?? []).slice(-1)[0];
              const t = trackById(u.listening ?? undefined);
              return (
                <button
                  key={u.id}
                  type="button"
                  onClick={() => setActive(u.id)}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-all duration-200 ${
                    active === u.id ? "bg-ink-750" : "hover:bg-ink-850"
                  }`}
                >
                  <Avatar name={u.name} colors={u.colors} size={40} online={u.online} />
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center justify-between gap-2">
                      <span className="truncate text-[13px] font-bold text-ink-100">{u.name}</span>
                      {last && <span className="font-mono shrink-0 text-[9px] text-ink-500">{fmtTs(last.ts)}</span>}
                    </span>
                    <span className="flex items-center justify-between gap-2">
                      <span className="truncate text-[11px] font-medium text-ink-400">
                        {typing === u.id ? (
                          <span className="text-wave-300">печатает…</span>
                        ) : last ? (
                          `${last.from === "me" ? "Вы: " : ""}${last.text}`
                        ) : t ? (
                          `слушает «${t.title}»`
                        ) : (
                          "начать диалог"
                        )}
                      </span>
                      {(unread[u.id] ?? 0) > 0 && (
                        <span className="font-mono flex h-4.5 min-w-[18px] shrink-0 items-center justify-center rounded-full bg-flare-500 px-1 text-[9px] font-bold text-ink-950" style={{ height: 18 }}>
                          {unread[u.id]}
                        </span>
                      )}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>
        </aside>

        {/* тред */}
        <section className={`${active ? "flex" : "hidden md:flex"} min-h-0 flex-col`}>
          {!friend ? (
            <div className="flex flex-1 flex-col items-center justify-center gap-3 px-6 text-center">
              <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-ink-800 text-ink-500">
                <IcChat style={{ fontSize: 28 }} />
              </span>
              <p className="font-display text-lg font-bold text-ink-200">Выбери собеседника</p>
              <p className="max-w-xs text-sm font-medium text-ink-500">
                Друзья отвечают быстро — особенно те, кто сейчас в сети и что-то слушает.
              </p>
            </div>
          ) : (
            <>
              <div className="flex items-center gap-3 border-b border-ink-700/70 px-4 py-3">
                <button
                  type="button"
                  onClick={() => setActive(null)}
                  aria-label="Назад к списку"
                  className="flex h-8 w-8 items-center justify-center rounded-full text-ink-400 transition-colors hover:bg-ink-800 hover:text-ink-100 md:hidden"
                >
                  <IcBack style={{ fontSize: 17 }} />
                </button>
                <Avatar name={friend.name} colors={friend.colors} size={36} online={friend.online} />
                <div className="min-w-0">
                  <button
                    type="button"
                    onClick={() => nav({ name: "profile", id: friend.id })}
                    className="block truncate text-sm font-bold text-ink-100 transition-colors hover:text-flare-300"
                  >
                    {friend.name}
                  </button>
                  <p className="flex items-center gap-1.5 text-[11px] font-medium text-ink-400">
                    {typing === friend.id ? (
                      <span className="text-wave-300">печатает…</span>
                    ) : friend.online ? (
                      <>
                        {trackById(friend.listening ?? undefined) ? (
                          <>
                            <Eq playing style={{ height: 9 }} className="text-wave-400" /> слушает «{trackById(friend.listening!)!.title}»
                          </>
                        ) : (
                          "в сети"
                        )}
                      </>
                    ) : (
                      `был(а) ${friend.lastSeen}`
                    )}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => nav({ name: "profile", id: friend.id })}
                  className="ml-auto shrink-0 rounded-full border border-ink-600 px-3.5 py-1.5 text-[11px] font-bold text-ink-300 transition-colors hover:border-ink-400 hover:text-ink-100"
                >
                  профиль
                </button>
              </div>

              <div ref={scrollRef} className="min-h-0 flex-1 overflow-y-auto px-4 py-4">
                <div className="flex flex-col gap-2.5">
                  {msgs.length === 0 && (
                    <p className="py-8 text-center text-sm font-medium text-ink-500">
                      Напиши первым — {friend.name.split(" ")[0]} сейчас {friend.online ? "в сети" : "офлайн, но увидит"}.
                    </p>
                  )}
                  {msgs.map((m) => (
                    <div key={m.id} className={`flex ${m.from === "me" ? "justify-end" : "justify-start"}`}>
                      <div
                        className={`max-w-[78%] rounded-2xl px-4 py-2.5 ${
                          m.from === "me"
                            ? "rounded-br-md bg-flare-500 text-ink-950"
                            : "rounded-bl-md border border-ink-700 bg-ink-800 text-ink-100"
                        }`}
                      >
                        <p className="text-[13px] font-semibold leading-relaxed">{m.text}</p>
                        <p className={`font-mono mt-1 text-right text-[9px] ${m.from === "me" ? "text-ink-950/60" : "text-ink-500"}`}>
                          {fmtTs(m.ts)}
                        </p>
                      </div>
                    </div>
                  ))}
                  {typing === friend.id && (
                    <div className="flex justify-start">
                      <div className="flex items-center gap-1.5 rounded-2xl rounded-bl-md border border-ink-700 bg-ink-800 px-4 py-3">
                        {[0, 1, 2].map((i) => (
                          <span
                            key={i}
                            className="h-1.5 w-1.5 rounded-full bg-ink-400"
                            style={{ animation: "kf-breathe 1s ease-in-out infinite", animationDelay: `${i * 0.18}s` }}
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2.5 border-t border-ink-700/70 p-3.5">
                <input
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && send()}
                  placeholder={`Сообщение для ${friend.name.split(" ")[0]}…`}
                  className="w-full rounded-full border border-ink-600 bg-ink-850 px-4.5 py-3 text-sm font-semibold text-ink-100 outline-none transition-colors placeholder:font-medium placeholder:text-ink-500 focus:border-flare-500/70"
                  style={{ paddingLeft: 18 }}
                />
                <button
                  type="button"
                  onClick={send}
                  aria-label="Отправить"
                  disabled={!text.trim()}
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-flare-500 text-ink-950 shadow-lg shadow-flare-500/25 transition-all duration-200 hover:bg-flare-400 active:scale-90 disabled:opacity-40 disabled:shadow-none"
                >
                  <IcSend style={{ fontSize: 17 }} />
                </button>
              </div>
            </>
          )}
        </section>
      </div>
    </div>
  );
}
