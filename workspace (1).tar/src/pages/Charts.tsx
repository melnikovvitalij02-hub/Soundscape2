import { CHART, TRACKS, chartIds, shuffleArray, trackById } from "../data/music";
import { USERS } from "../data/people";
import type { Nav } from "../router";
import { usePlayer } from "../state/PlayerProvider";
import { Avatar, Cover, Eq, Reveal, Trend } from "../components/bits";
import { TrackRow } from "../components/tracks";
import { IcFire, IcPlay, IcShuffle, IcSpark, IcUp, IcVinyl } from "../components/icons";

const GENRES = ["Поп", "R&B", "Электро-поп", "Фолк-поп", "Инди-поп", "Хип-хоп", "Электроника"];

export function ChartsPage({ nav }: { nav: Nav }) {
  const { playTrack, currentId, isPlaying, queue } = usePlayer();
  const current = trackById(currentId) ?? trackById("t1")!;
  const listeners = USERS.filter((u) => u.listening);

  return (
    <div className="grid gap-10 lg:grid-cols-[minmax(0,1fr)_320px]">
      <div className="min-w-0">
        {/* шапка чарта */}
        <header className="mb-8 flex flex-col gap-8 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="font-mono flex items-center gap-2 text-[11px] font-semibold tracking-[0.22em] text-flare-400 uppercase">
              <IcFire style={{ fontSize: 15 }} /> Чарт · Россия · неделя 7 / 2026
            </p>
            <h1 className="font-display mt-3 text-4xl font-black tracking-tight text-ink-100 md:text-5xl">
              Топ-9 <span className="text-flare-400">треков</span>
            </h1>
            <p className="mt-3 max-w-md text-[15px] font-medium text-ink-300">
              Рейтинг обновляется каждую пятницу по прослушиваниям участников Soundscape. Позиции {`"`}живые{`"`} — слушай и двигай своих фаворитов.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => playTrack(chartIds[0], chartIds)}
                className="font-display flex items-center gap-2.5 rounded-full bg-flare-500 px-6 py-3 text-[13px] font-bold text-ink-950 shadow-lg shadow-flare-500/25 transition-all duration-200 hover:scale-[1.04] hover:bg-flare-400 active:scale-95"
              >
                <IcPlay style={{ fontSize: 15 }} /> Слушать чарт
              </button>
              <button
                type="button"
                onClick={() => {
                  const q = shuffleArray(chartIds);
                  playTrack(q[0], q);
                }}
                className="font-display flex items-center gap-2 rounded-full border border-ink-600 px-6 py-3 text-[13px] font-bold text-ink-200 transition-all duration-200 hover:border-ink-400 hover:bg-ink-800 hover:text-ink-100"
              >
                <IcShuffle style={{ fontSize: 15 }} /> Перемешать
              </button>
            </div>
          </div>

          {/* винил */}
          <div className="mx-auto flex shrink-0 flex-col items-center md:mx-0">
            <div className="relative">
              <span
                className={`absolute -inset-8 rounded-full blur-3xl ${isPlaying ? "breathe" : "opacity-30"}`}
                style={{ background: current.accent }}
              />
              <div className={`vinyl relative h-44 w-44 md:h-48 md:w-48 ${isPlaying ? "" : "vinyl-paused"}`}>
                <div className="absolute inset-0 rounded-full bg-ink-950 shadow-2xl shadow-black/60 ring-1 ring-white/10" />
                <div className="absolute inset-[7%] rounded-full opacity-60" style={{ background: "repeating-radial-gradient(circle, #141924 0 2px, #0a0d13 2px 5px)" }} />
                <div className="absolute inset-[30%] overflow-hidden rounded-full ring-2 ring-ink-700">
                  <img src={current.cover} alt={current.title} className="h-full w-full object-cover" />
                </div>
                <div className="absolute inset-[47%] rounded-full bg-ink-950 ring-2 ring-ink-700" />
              </div>
            </div>
            <p className="font-mono mt-5 flex items-center gap-2 text-[11px] font-semibold tracking-wider text-ink-300 uppercase">
              {isPlaying ? <Eq playing className="text-flare-400" style={{ height: 11 }} /> : <IcVinyl style={{ fontSize: 14 }} />}
              {isPlaying ? `в эфире: ${current.title}` : "на паузе"}
            </p>
            <p className="mt-0.5 text-xs font-medium text-ink-500">{current.artist}</p>
          </div>
        </header>

        {/* список чарта */}
        <section className="stagger rounded-2xl border border-ink-700/70 bg-ink-900/60 p-2 md:p-3">
          {CHART.map((c, i) => {
            const t = trackById(c.trackId);
            if (!t) return null;
            return (
              <TrackRow key={c.trackId} track={t} pos={i + 1} context={chartIds} trend={<Trend move={c.move} />} />
            );
          })}
          <p className="font-mono px-3 pt-3 pb-2 text-center text-[10px] tracking-widest text-ink-500 uppercase">
            позиции обновлены сегодня в 06:00 МСК · двойной клик по треку — играть
          </p>
        </section>
      </div>

      {/* правая колонка */}
      <aside className="min-w-0">
        <Reveal>
          <section className="rounded-2xl border border-ink-700/70 bg-ink-900/70 p-5">
            <h3 className="font-display flex items-center gap-2 text-sm font-bold text-ink-100">
              <IcSpark style={{ fontSize: 15 }} className="text-flare-400" /> Факты недели
            </h3>
            <ul className="mt-4 flex flex-col gap-4">
              <li className="flex gap-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-wave-500/15 text-wave-400"><IcUp style={{ fontSize: 16 }} /></span>
                <div>
                  <p className="text-[13px] font-bold text-ink-100">Рывок недели — «Аникс»</p>
                  <p className="text-xs font-medium text-ink-400">BEARWOLF поднялся сразу на 3 позиции — до 7-го места.</p>
                </div>
              </li>
              <li className="flex gap-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-flare-500/15 text-flare-400"><IcFire style={{ fontSize: 16 }} /></span>
                <div>
                  <p className="text-[13px] font-bold text-ink-100">Рекорд прослушиваний</p>
                  <p className="text-xs font-medium text-ink-400">«Матушка» держит 31,7 млн — абсолютный рекорд платформы.</p>
                </div>
              </li>
              <li className="flex gap-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-beat-500/15 text-beat-400"><IcSpark style={{ fontSize: 16 }} /></span>
                <div>
                  <p className="text-[13px] font-bold text-ink-100">Два дебюта</p>
                  <p className="text-xs font-medium text-ink-400">ENZRO и Саян впервые в топ-9 — встречайте новичков.</p>
                </div>
              </li>
            </ul>
          </section>
        </Reveal>

        <Reveal delay={100}>
          <section className="mt-6 rounded-2xl border border-ink-700/70 bg-ink-900/70 p-5">
            <h3 className="font-display text-sm font-bold text-ink-100">Друзья слушают</h3>
            <ul className="mt-3 flex flex-col gap-1">
              {listeners.map((u) => {
                const t = trackById(u.listening)!;
                const pos = CHART.findIndex((c) => c.trackId === t.id);
                return (
                  <li key={u.id}>
                    <button
                      type="button"
                      onClick={() => playTrack(t.id, chartIds)}
                      className="group flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left transition-colors duration-200 hover:bg-ink-850"
                    >
                      <Avatar name={u.name} colors={u.colors} size={36} online />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[13px] font-bold text-ink-200 group-hover:text-ink-100">
                          {u.name.split(" ")[0]}
                        </span>
                        <span className="block truncate text-[11px] font-medium text-ink-400">
                          «{t.title}» · #{pos + 1} в чарте
                        </span>
                      </span>
                      <Eq playing={queue.includes(t.id) && isPlaying && currentId === t.id} className="text-wave-400" style={{ height: 12 }} />
                    </button>
                  </li>
                );
              })}
            </ul>
          </section>
        </Reveal>

        <Reveal delay={160}>
          <section className="mt-6 rounded-2xl border border-ink-700/70 bg-ink-900/70 p-5">
            <h3 className="font-display text-sm font-bold text-ink-100">Жанры недели</h3>
            <div className="mt-3 flex flex-wrap gap-2">
              {GENRES.map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => nav({ name: "search", query: g })}
                  className="rounded-full border border-ink-600/80 px-3.5 py-1.5 text-xs font-bold text-ink-300 transition-all duration-200 hover:-translate-y-0.5 hover:border-flare-500/60 hover:text-flare-300"
                >
                  {g}
                </button>
              ))}
            </div>
            <p className="font-mono mt-4 text-[10px] tracking-widest text-ink-500 uppercase">
              всего в ротации: {TRACKS.length} треков
            </p>
          </section>
        </Reveal>
      </aside>
    </div>
  );
}
