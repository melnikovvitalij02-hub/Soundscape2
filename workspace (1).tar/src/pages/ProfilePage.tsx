import { trackById } from "../data/music";
import { fmtNum, userById } from "../data/people";
import type { Nav } from "../router";
import { useAuth } from "../state/AuthContext";
import { usePlayer } from "../state/PlayerProvider";
import { useStudio } from "../state/StudioContext";
import { useToast } from "../state/ToastContext";
import { Avatar, Cover, Eq, Reveal, SectionTitle } from "../components/bits";
import { LikeBtn, TrackRow } from "../components/tracks";
import { IcChat, IcCrown, IcLogout } from "../components/icons2";
import { IcBack, IcChart, IcUsers, IcWave } from "../components/icons";

export function ProfilePage({ id, nav }: { id: string; nav: Nav }) {
  const { me, logout } = useAuth();
  const player = usePlayer();
  const { level, xp, pro, projects } = useStudio();
  const toast = useToast();

  /* ---------- свой профиль ---------- */
  if (id === "me" && me) {
    return (
      <div className="mx-auto max-w-4xl">
        <Reveal>
          <header
            className="relative overflow-hidden rounded-2xl p-7 md:p-9"
            style={{ background: `linear-gradient(120deg, ${me.colors[0]}2e, transparent 55%), #0e1219`, border: "1px solid #20283977" }}
          >
            <span
              className="pointer-events-none absolute -top-16 -right-16 h-56 w-56 rounded-full blur-3xl"
              style={{ background: me.colors[0], opacity: 0.18 }}
            />
            <div className="relative flex flex-wrap items-center gap-5">
              <Avatar name={me.name} colors={me.colors} size={88} />
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2.5">
                  <h1 className="font-display text-2xl font-black text-ink-100 md:text-3xl">{me.name}</h1>
                  {pro ? (
                    <span className="flex items-center gap-1.5 rounded-full bg-flare-500/15 px-3 py-1 text-[10px] font-bold tracking-wider text-flare-300 uppercase">
                      <IcCrown style={{ fontSize: 12 }} /> Beat Pro
                    </span>
                  ) : (
                    <span className="rounded-full bg-ink-700/70 px-3 py-1 text-[10px] font-bold tracking-wider text-ink-300 uppercase">Free</span>
                  )}
                </div>
                <p className="font-mono mt-1 text-sm text-ink-400">@{me.username} · с нами с 2026</p>
                <p className="mt-2 max-w-md text-sm font-medium text-ink-300">
                  Слушаю чарты, собираю биты в Beat Pro и охочусь за квестами. Это мой профиль — здесь всё про меня.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  toast("Вы вышли из аккаунта. До встречи в эфире!", "info");
                  logout();
                }}
                className="font-display flex items-center gap-2 rounded-full border border-beat-500/50 px-5 py-2.5 text-[13px] font-bold text-beat-400 transition-all duration-200 hover:bg-beat-500/10 active:scale-95"
              >
                <IcLogout style={{ fontSize: 16 }} /> Выйти
              </button>
            </div>
          </header>
        </Reveal>

        <Reveal delay={80}>
          <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-4">
            {[
              [`${level}`, "уровень", "text-flare-300"],
              [`${xp}`, "XP всего", "text-ink-100"],
              [`${projects.length}`, "битов в проектах", "text-wave-300"],
              [`${player.likes.length}`, "любимых треков", "text-beat-400"],
            ].map(([v, l, c]) => (
              <div key={l as string} className="rounded-xl border border-ink-700/70 bg-ink-900/70 p-4 text-center">
                <p className={`font-display text-2xl font-black ${c}`}>{v}</p>
                <p className="mt-0.5 text-[11px] font-bold tracking-wide text-ink-500 uppercase">{l}</p>
              </div>
            ))}
          </div>
        </Reveal>

        <Reveal delay={140}>
          <section className="mt-8">
            <SectionTitle kicker="быстрый доступ" title="Мои инструменты" />
            <div className="grid gap-3 sm:grid-cols-3">
              {[
                { t: "Beat Pro", d: "Секвенсор на 16 шагов", go: () => nav({ name: "beat" }), icon: <IcWave style={{ fontSize: 20 }} /> },
                { t: "Моя коллекция", d: "Лайки и плейлисты", go: () => nav({ name: "library" }), icon: <IcChart style={{ fontSize: 20 }} /> },
                { t: "Квесты", d: "Забрать ежедневный XP", go: () => nav({ name: "games" }), icon: <IcCrown style={{ fontSize: 20 }} /> },
              ].map((x) => (
                <button
                  key={x.t}
                  type="button"
                  onClick={x.go}
                  className="group rounded-xl border border-ink-700/70 bg-ink-900/70 p-5 text-left transition-all duration-300 hover:-translate-y-1 hover:border-flare-500/50"
                >
                  <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-ink-800 text-flare-400 transition-colors group-hover:bg-flare-500/15">
                    {x.icon}
                  </span>
                  <p className="font-display mt-3 text-sm font-bold text-ink-100 group-hover:text-flare-300">{x.t}</p>
                  <p className="mt-0.5 text-xs font-medium text-ink-500">{x.d}</p>
                </button>
              ))}
            </div>
          </section>
        </Reveal>

        {!pro && (
          <Reveal delay={200}>
            <button
              type="button"
              onClick={() => nav({ name: "pricing" })}
              className="mt-6 flex w-full items-center gap-4 rounded-2xl border border-flare-500/40 bg-gradient-to-r from-flare-500/10 to-transparent p-5 text-left transition-all duration-300 hover:-translate-y-0.5"
            >
              <IcCrown style={{ fontSize: 24 }} className="shrink-0 text-flare-400" />
              <span className="flex-1">
                <span className="font-display block text-sm font-bold text-flare-300">Прокачай профиль до Beat Pro</span>
                <span className="block text-xs font-medium text-ink-400">AI-студия, безлимит битов и значок в чатах — 499 ₽/мес</span>
              </span>
              <span className="font-display shrink-0 rounded-full bg-flare-500 px-4 py-2 text-xs font-bold text-ink-950">Подключить</span>
            </button>
          </Reveal>
        )}
      </div>
    );
  }

  /* ---------- чужой профиль ---------- */
  const u = userById(id);
  if (!u) {
    return (
      <div className="py-20 text-center">
        <p className="font-display text-xl font-bold text-ink-200">Такого профиля нет</p>
        <button type="button" onClick={() => nav({ name: "friends" })} className="font-display mt-4 rounded-full bg-flare-500 px-6 py-3 text-[13px] font-bold text-ink-950">
          К друзьям
        </button>
      </div>
    );
  }

  const isFriend = player.isFriend(u.id);
  const topTracks = u.topTrackIds.map((tid) => trackById(tid)).filter(Boolean);
  const topPl = u.playlistIds;

  return (
    <div className="mx-auto max-w-4xl">
      <button
        type="button"
        onClick={() => nav({ name: "friends" })}
        className="mb-4 flex items-center gap-2 text-sm font-bold text-ink-400 transition-colors hover:text-ink-100"
      >
        <IcBack style={{ fontSize: 16 }} /> К друзьям
      </button>

      <Reveal>
        <header
          className="relative overflow-hidden rounded-2xl p-7 md:p-9"
          style={{ background: `linear-gradient(120deg, ${u.colors[0]}2e, transparent 55%), #0e1219`, border: "1px solid #20283977" }}
        >
          <span
            className="pointer-events-none absolute -top-16 -right-16 h-56 w-56 rounded-full blur-3xl"
            style={{ background: u.colors[0], opacity: 0.18 }}
          />
          <div className="relative flex flex-wrap items-center gap-5">
            <Avatar name={u.name} colors={u.colors} size={88} online={u.online} />
            <div className="min-w-0 flex-1">
              <h1 className="font-display text-2xl font-black text-ink-100 md:text-3xl">{u.name}</h1>
              <p className="font-mono mt-1 text-sm text-ink-400">
                @{u.username} · в Soundscape с {u.joined}
              </p>
              <p className="mt-2 max-w-md text-sm font-medium text-ink-300">{u.bio}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {u.tags.map((t) => (
                  <span key={t} className="rounded-full border border-ink-600 px-3 py-1 text-[11px] font-bold text-ink-300">
                    #{t}
                  </span>
                ))}
              </div>
            </div>
            <div className="flex w-full flex-col gap-2.5 sm:w-auto">
              <button
                type="button"
                onClick={() => {
                  player.toggleFriend(u.id);
                  toast(isFriend ? `Вы больше не друзья с ${u.name.split(" ")[0]}` : `${u.name.split(" ")[0]} теперь ваш друг!`, "user");
                }}
                className={`font-display flex items-center justify-center gap-2 rounded-full px-6 py-2.5 text-[13px] font-bold transition-all duration-200 active:scale-95 ${
                  isFriend
                    ? "border border-wave-500/60 text-wave-300 hover:bg-wave-500/10"
                    : "bg-flare-500 text-ink-950 shadow-lg shadow-flare-500/25 hover:bg-flare-400"
                }`}
              >
                <IcUsers style={{ fontSize: 15 }} /> {isFriend ? "Вы друзья" : "Добавить в друзья"}
              </button>
              <button
                type="button"
                onClick={() => nav({ name: "chat" })}
                className="font-display flex items-center justify-center gap-2 rounded-full border border-ink-600 px-6 py-2.5 text-[13px] font-bold text-ink-200 transition-all duration-200 hover:border-ink-400 hover:text-ink-100"
              >
                <IcChat style={{ fontSize: 15 }} /> Написать
              </button>
            </div>
          </div>
        </header>
      </Reveal>

      {/* статус + статы */}
      <Reveal delay={80}>
        <div className="mt-5 grid gap-3 md:grid-cols-[1.3fr_1fr_1fr]">
          <div className="flex items-center gap-3.5 rounded-xl border border-ink-700/70 bg-ink-900/70 p-4">
            {u.listening ? (
              <>
                <Cover src={trackById(u.listening)!.cover} alt="" className="h-12 w-12">
                  <Eq playing className="absolute inset-0 m-auto text-white" />
                </Cover>
                <div className="min-w-0">
                  <p className="font-mono text-[10px] font-bold tracking-widest text-wave-300 uppercase">слушает прямо сейчас</p>
                  <button
                    type="button"
                    onClick={() => player.playTrack(u.listening!, [u.listening!])}
                    className="block truncate text-sm font-bold text-ink-100 transition-colors hover:text-flare-300"
                  >
                    «{trackById(u.listening)!.title}» — {trackById(u.listening)!.artist}
                  </button>
                </div>
              </>
            ) : (
              <div>
                <p className="text-sm font-bold text-ink-200">{u.online ? "В сети" : `Был(а) ${u.lastSeen}`}</p>
                <p className="text-xs font-medium text-ink-500">Сейчас ничего не играет</p>
              </div>
            )}
          </div>
          {[
            [fmtNum(u.followers), "подписчиков"],
            [`${Math.round(u.minutesWeek / 60)} ч ${u.minutesWeek % 60} мин`, "за неделю"],
          ].map(([v, l]) => (
            <div key={l as string} className="rounded-xl border border-ink-700/70 bg-ink-900/70 p-4">
              <p className="font-display text-xl font-black text-ink-100">{v}</p>
              <p className="mt-0.5 text-[11px] font-bold tracking-wide text-ink-500 uppercase">{l}</p>
            </div>
          ))}
        </div>
      </Reveal>

      {/* топ треки */}
      <Reveal delay={140}>
        <section className="mt-9">
          <SectionTitle kicker="личное" title={`Топ треков — ${u.name.split(" ")[0]}`} />
          <div className="rounded-xl border border-ink-700/70 bg-ink-900/60 p-2">
            {topTracks.map((t, i) => (
              <TrackRow key={t!.id} track={t!} pos={i + 1} context={u.topTrackIds} trend={<LikeBtn id={t!.id} className="mr-1" />} />
            ))}
          </div>
        </section>
      </Reveal>

      {/* плейлисты */}
      <Reveal delay={200}>
        <section className="mt-9">
          <SectionTitle kicker="подборки" title="Собранные плейлисты" />
          <div className="flex flex-wrap gap-4">
            {topPl.map((pid) => {
              const pl = { p1: "Русские хиты · 2026", p2: "Ночная поездка", p3: "Энергия · Тренировка", p4: "Душевное", p5: "Новая музыка · Пятница" }[pid];
              return (
                <div key={pid} className="w-40 rounded-xl border border-ink-700/70 bg-ink-900/60 p-3.5 transition-all duration-300 hover:-translate-y-1 hover:border-ink-500">
                  <div className="grid aspect-square grid-cols-2 overflow-hidden rounded-lg">
                    {(pid === "p2" ? ["t5", "t7", "t6", "t1"] : pid === "p3" ? ["t9", "t1", "t8", "t7"] : pid === "p4" ? ["t2", "t3", "t5", "t4"] : pid === "p5" ? ["t5", "t9", "t7", "t8"] : ["t1", "t2", "t3", "t4"]).map((tid) => (
                      <img key={tid} src={trackById(tid)!.cover} alt="" className="h-full w-full object-cover" />
                    ))}
                  </div>
                  <p className="mt-2.5 truncate text-[13px] font-bold text-ink-100">{pl}</p>
                  <p className="font-mono text-[10px] text-ink-500">плейлист · 4 трека</p>
                </div>
              );
            })}
          </div>
        </section>
      </Reveal>
    </div>
  );
}
