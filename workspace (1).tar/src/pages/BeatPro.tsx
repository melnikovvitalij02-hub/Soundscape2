import { useEffect, useState } from "react";
import { DRUMS, DRUM_COLORS, DRUM_LABELS, STEPS, STYLES, emptyPattern, generatePattern, type Pattern, type StyleKey } from "../audio/engine";
import type { Nav } from "../router";
import { useStudio, emitEvent } from "../state/StudioContext";
import { useToast } from "../state/ToastContext";
import { IconBtn } from "../components/bits";
import { IcCheck, IcCrown, IcDice, IcTrash } from "../components/icons2";
import { IcPause, IcPlay } from "../components/icons";

export function BeatProPage({ nav }: { nav: Nav }) {
  const { engine, stopProject, projects, pro, saveProject } = useStudio();
  const toast = useToast();
  const [pattern, setPattern] = useState<Pattern>(emptyPattern);
  const [bpm, setBpm] = useState(128);
  const [name, setName] = useState("");
  const [playing, setPlaying] = useState(false);
  const [step, setStep] = useState(-1);

  useEffect(() => {
    stopProject();
    engine.onStep = (s) => setStep(s);
    setPlaying(engine.playing);
    return () => {
      engine.onStep = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    engine.setPattern(pattern);
    engine.setBpm(bpm);
  }, [pattern, bpm, engine]);

  const togglePlay = () => {
    if (engine.playing) {
      engine.stop();
      setPlaying(false);
    } else {
      engine.start();
      setPlaying(true);
      toast("Жми на клетки — бит дописывается на лету", "play");
    }
  };

  const applyStyle = (key: StyleKey) => {
    const g = generatePattern(key);
    setPattern(g.pattern);
    setBpm(g.bpm);
    const meta = STYLES.find((s) => s.key === key)!;
    if (!name.trim()) setName(`Бит «${meta.label}»`);
    engine.setPattern(g.pattern);
    engine.setBpm(g.bpm);
    toast(`Пресет «${meta.label}» загружен · ${g.bpm} BPM`, "info");
  };

  const randomize = () => {
    const key = STYLES[Math.floor(Math.random() * STYLES.length)].key;
    applyStyle(key);
  };

  const toggleCell = (r: number, c: number) =>
    setPattern((p) => p.map((row, ri) => (ri === r ? row.map((v, ci) => (ci === c ? !v : v)) : row)));

  const save = () => {
    const res = saveProject({
      name: name.trim() || `Бит ${projects.length + 1}`,
      bpm,
      pattern,
      origin: "manual",
    });
    if (res.ok) {
      emitEvent("beat-save");
      toast("Бит сохранён в проекты +80 XP по квесту", "ok");
    } else {
      toast("Лимит Free — 3 проекта. Beat Pro снимает ограничение", "info");
      nav({ name: "pricing" });
    }
  };

  const usedCells = pattern.flat().filter(Boolean).length;

  return (
    <div className="mx-auto max-w-5xl">
      <header className="mb-7 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono flex items-center gap-2 text-[11px] font-semibold tracking-[0.22em] text-flare-400 uppercase">
            <IcPlay style={{ fontSize: 13 }} /> Beat Pro · драм-машина
          </p>
          <h1 className="font-display mt-2 text-3xl font-black tracking-tight text-ink-100 md:text-4xl">
            Собери свой бит
          </h1>
          <p className="mt-2 max-w-lg text-[15px] font-medium text-ink-300">
            16 шагов, 5 дорожек, живой звук прямо в браузере. Кликай по клеткам во время воспроизведения — секвенсор пишет на лету.
          </p>
        </div>
        <div className="font-mono rounded-full border border-ink-600 px-4 py-2 text-[11px] font-semibold tracking-wider text-ink-300 uppercase">
          {pro ? "∞ проектов · Beat Pro" : `проекты: ${projects.length}/3 · Free`}
        </div>
      </header>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_280px]">
        {/* секвенсор */}
        <section className="rounded-2xl border border-ink-700/70 bg-ink-900/70 p-5 md:p-6">
          {/* транспорт */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={togglePlay}
              className={`font-display flex items-center gap-2.5 rounded-full px-6 py-3 text-[13px] font-bold transition-all duration-200 active:scale-95 ${
                playing
                  ? "bg-ink-100 text-ink-950 hover:bg-white"
                  : "bg-flare-500 text-ink-950 shadow-lg shadow-flare-500/25 hover:bg-flare-400"
              }`}
            >
              {playing ? <IcPause style={{ fontSize: 15 }} /> : <IcPlay style={{ fontSize: 15 }} />}
              {playing ? "Стоп" : "Играть"}
            </button>

            <div className="flex items-center gap-3 rounded-full border border-ink-600/80 px-4 py-2">
              <span className="font-mono text-[11px] font-semibold tracking-wider text-ink-400 uppercase">BPM</span>
              <input
                type="range"
                min={70}
                max={170}
                value={bpm}
                onChange={(e) => setBpm(Number(e.target.value))}
                className="w-28 cursor-pointer"
                aria-label="Темп"
              />
              <span className="font-mono w-8 text-sm font-bold text-flare-300 tabular-nums">{bpm}</span>
            </div>

            <IconBtn label="Случайный стиль" onClick={randomize}>
              <IcDice style={{ fontSize: 18 }} />
            </IconBtn>
            <IconBtn label="Очистить всё" onClick={() => setPattern(emptyPattern())}>
              <IcTrash style={{ fontSize: 17 }} />
            </IconBtn>
            <span className="font-mono ml-auto hidden text-[11px] text-ink-500 sm:block">{usedCells} активных шагов</span>
          </div>

          {/* сетка */}
          <div className="mt-6 overflow-x-auto pb-1">
            <div className="min-w-[560px]">
              {/* линейка шагов */}
              <div className="mb-2 flex items-center gap-[5px] pl-[104px]">
                {Array.from({ length: STEPS }).map((_, i) => (
                  <span
                    key={i}
                    className={`font-mono flex-1 text-center text-[9px] tabular-nums ${
                      step === i ? "font-bold text-flare-300" : i % 4 === 0 ? "text-ink-400" : "text-ink-600"
                    }`}
                  >
                    {i + 1}
                  </span>
                ))}
              </div>

              {DRUMS.map((drum, r) => (
                <div key={drum} className="mb-[5px] flex items-center gap-[5px]">
                  <button
                    type="button"
                    onClick={() => engine.hit(drum)}
                    title={`Послушать: ${DRUM_LABELS[drum]}`}
                    className="group flex h-9 w-[99px] shrink-0 items-center gap-2 rounded-md border border-ink-700 bg-ink-850 px-2.5 transition-all duration-150 hover:border-ink-500 hover:bg-ink-800 active:scale-95"
                  >
                    <span className="h-2 w-2 shrink-0 rounded-sm" style={{ background: DRUM_COLORS[drum] }} />
                    <span className="truncate text-[11px] font-bold text-ink-300 group-hover:text-ink-100">
                      {DRUM_LABELS[drum]}
                    </span>
                  </button>
                  {pattern[r].map((on, c) => (
                    <button
                      key={c}
                      type="button"
                      aria-label={`${DRUM_LABELS[drum]}, шаг ${c + 1}`}
                      onClick={() => toggleCell(r, c)}
                      className={`h-9 flex-1 rounded-md border transition-all duration-100 active:scale-90 ${
                        c % 4 === 0 ? "ml-[7px]" : ""
                      } ${
                        on
                          ? "border-transparent shadow-md"
                          : step === c
                            ? "border-ink-500 bg-ink-700"
                            : "border-ink-700/70 bg-ink-850 hover:border-ink-500 hover:bg-ink-800"
                      }`}
                      style={
                        on
                          ? {
                              background: DRUM_COLORS[drum],
                              boxShadow: step === c ? `0 0 14px ${DRUM_COLORS[drum]}aa` : `0 2px 10px ${DRUM_COLORS[drum]}33`,
                              transform: step === c ? "scale(1.08)" : undefined,
                            }
                          : undefined
                      }
                    />
                  ))}
                </div>
              ))}
            </div>
          </div>

          {/* сохранение */}
          <div className="mt-6 flex flex-wrap items-center gap-3 border-t border-ink-700/70 pt-5">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={32}
              placeholder={`Название — «Бит ${projects.length + 1}»`}
              className="w-56 rounded-lg border border-ink-600 bg-ink-850 px-3.5 py-2.5 text-sm font-semibold text-ink-100 outline-none transition-colors placeholder:font-medium placeholder:text-ink-500 focus:border-flare-500/70"
            />
            <button
              type="button"
              onClick={save}
              className="font-display flex items-center gap-2 rounded-full bg-wave-500 px-5 py-2.5 text-[13px] font-bold text-ink-950 transition-all duration-200 hover:bg-wave-400 active:scale-95"
            >
              <IcCheck style={{ fontSize: 15 }} /> Сохранить в проекты
            </button>
            <button
              type="button"
              onClick={() => nav({ name: "projects" })}
              className="text-[13px] font-bold text-ink-400 underline-offset-4 transition-colors hover:text-ink-100 hover:underline"
            >
              Открыть проекты →
            </button>
          </div>
        </section>

        {/* правая колонка */}
        <aside className="flex flex-col gap-5">
          <section className="rounded-2xl border border-ink-700/70 bg-ink-900/70 p-5">
            <h3 className="font-display text-sm font-bold text-ink-100">Пресеты</h3>
            <div className="mt-3 grid grid-cols-2 gap-2.5">
              {STYLES.map((s) => (
                <button
                  key={s.key}
                  type="button"
                  onClick={() => applyStyle(s.key)}
                  className="group rounded-xl border border-ink-600/80 bg-ink-850 p-3.5 text-left transition-all duration-200 hover:-translate-y-0.5 hover:border-flare-500/60 hover:bg-ink-800"
                >
                  <p className="text-[13px] font-bold text-ink-100 group-hover:text-flare-300">{s.label}</p>
                  <p className="font-mono mt-1 text-[10px] text-ink-500">
                    {s.bpm[0]}–{s.bpm[1]} BPM
                  </p>
                </button>
              ))}
            </div>
            <p className="mt-3 text-xs font-medium text-ink-500">{STYLES[0].desc}</p>
          </section>

          <section className="rounded-2xl border border-ink-700/70 bg-ink-900/70 p-5">
            <h3 className="font-display text-sm font-bold text-ink-100">Как читать сетку</h3>
            <ul className="mt-3 flex flex-col gap-2.5 text-[13px] font-medium text-ink-300">
              <li className="flex gap-2.5">
                <span className="mt-1 h-2 w-2 shrink-0 rounded-sm bg-flare-400" />
                Каждая строка — инструмент, клик по названию даёт превью звука.
              </li>
              <li className="flex gap-2.5">
                <span className="mt-1 h-2 w-2 shrink-0 rounded-sm bg-wave-400" />
                Вертикаль — доли такта: шаг 1, 5, 9, 13 — сильная доля.
              </li>
              <li className="flex gap-2.5">
                <span className="mt-1 h-2 w-2 shrink-0 rounded-sm bg-beat-400" />
                Сохранённые биты попадают в «Проекты» и играют по всей платформе.
              </li>
            </ul>
          </section>

          {!pro && (
            <section
              className="cursor-pointer rounded-2xl border border-flare-500/40 bg-gradient-to-br from-flare-500/12 to-transparent p-5 transition-transform duration-200 hover:-translate-y-0.5"
              onClick={() => nav({ name: "pricing" })}
            >
              <p className="font-display flex items-center gap-2 text-sm font-bold text-flare-300">
                <IcCrown style={{ fontSize: 16 }} /> Beat Pro · 499 ₽/мес
              </p>
              <p className="mt-2 text-[13px] font-medium text-ink-300">
                Безлимит проектов, AI-генерация битов и ранний доступ к новым звукам.
              </p>
            </section>
          )}
        </aside>
      </div>
    </div>
  );
}
