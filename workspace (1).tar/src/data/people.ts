export interface User {
  id: string;
  name: string;
  username: string;
  bio: string;
  colors: [string, string];
  followers: number;
  following: number;
  minutesWeek: number;
  joined: string;
  online: boolean;
  lastSeen?: string;
  /** id трека, который человек слушает прямо сейчас */
  listening: string | null;
  topTrackIds: string[];
  playlistIds: string[];
  tags: string[];
  defaultFriend: boolean;
}

export const ME = {
  name: "Даниил Крапивин",
  username: "you.wav",
  colors: ["#ffa62b", "#ff5470"] as [string, string],
  minutesWeek: 1284,
};

export const USERS: User[] = [
  {
    id: "u1",
    name: "Алина Валеева",
    username: "lina.wav",
    bio: "Собираю плейлисты, как открытки. Если трек зацепил — скину первым делом.",
    colors: ["#ffa62b", "#ff5470"],
    followers: 1240,
    following: 312,
    minutesWeek: 2140,
    joined: "март 2024",
    online: true,
    listening: "t3",
    topTrackIds: ["t3", "t5", "t8"],
    playlistIds: ["p1", "p4"],
    tags: ["поп", "плейлисты", "новинки"],
    defaultFriend: true,
  },
  {
    id: "u2",
    name: "Марк Гордин",
    username: "markbeats",
    bio: "Битмейкер. Пишу глитч и электронику, ищу вокалистов в пару треков.",
    colors: ["#52dcc4", "#4f8dff"],
    followers: 3480,
    following: 190,
    minutesWeek: 1730,
    joined: "январь 2023",
    online: true,
    listening: "t7",
    topTrackIds: ["t7", "t9", "t1"],
    playlistIds: ["p2", "p3"],
    tags: ["электроника", "продакшн", "биты"],
    defaultFriend: true,
  },
  {
    id: "u3",
    name: "Соня Ким",
    username: "sonya.fm",
    bio: "Веду ночной эфир интернет-радио. Пишите в личку, что поставить в 3 часа ночи.",
    colors: ["#ff7d92", "#ffa62b"],
    followers: 892,
    following: 501,
    minutesWeek: 1980,
    joined: "июль 2024",
    online: false,
    lastSeen: "35 минут назад",
    listening: null,
    topTrackIds: ["t5", "t6", "t8"],
    playlistIds: ["p2", "p5"],
    tags: ["инди", "радио", "ночь"],
    defaultFriend: true,
  },
  {
    id: "u4",
    name: "Тимур Алиев",
    username: "timur.low",
    bio: "Бас — это всё. Хожу на все живые концерты, коллекционирую мерч.",
    colors: ["#4f8dff", "#2cc2aa"],
    followers: 456,
    following: 743,
    minutesWeek: 980,
    joined: "октябрь 2024",
    online: true,
    listening: "t1",
    topTrackIds: ["t1", "t9", "t7"],
    playlistIds: ["p3"],
    tags: ["хип-хоп", "бас", "концерты"],
    defaultFriend: false,
  },
  {
    id: "u5",
    name: "Кира Мельник",
    username: "kira.plays",
    bio: "Слушаю больше, чем сплю. Фолк, соул и всё, что звучит по-настоящему.",
    colors: ["#ff5470", "#9be15d"],
    followers: 2210,
    following: 428,
    minutesWeek: 2560,
    joined: "февраль 2023",
    online: true,
    listening: "t2",
    topTrackIds: ["t2", "t8", "t3"],
    playlistIds: ["p4", "p1"],
    tags: ["фолк", "соул", "топ-чарты"],
    defaultFriend: true,
  },
  {
    id: "u6",
    name: "Данил Орлов",
    username: "danil.onair",
    bio: "Диджей. Каждое утро — новый плейлист под кофе. Заказы на сеты в лс.",
    colors: ["#ffa62b", "#52dcc4"],
    followers: 5340,
    following: 122,
    minutesWeek: 1450,
    joined: "май 2022",
    online: false,
    lastSeen: "2 часа назад",
    listening: null,
    topTrackIds: ["t9", "t1", "t4"],
    playlistIds: ["p3", "p2"],
    tags: ["диджей", "хаус", "сеты"],
    defaultFriend: false,
  },
  {
    id: "u7",
    name: "Настя Юж",
    username: "nastya.noise",
    bio: "Шум — тоже музыка. Снимаю разборы аранжировок, монтирую по ночам.",
    colors: ["#2cc2aa", "#ff7d92"],
    followers: 764,
    following: 655,
    minutesWeek: 1120,
    joined: "август 2024",
    online: true,
    listening: "t6",
    topTrackIds: ["t6", "t7", "t5"],
    playlistIds: ["p5", "p2"],
    tags: ["электроника", "разборы", "саунд"],
    defaultFriend: false,
  },
  {
    id: "u8",
    name: "Егор Штарк",
    username: "yegor.wav",
    bio: "Саунд-дизайнер в геймдеве. Днём — взрывы, вечером — тихий фолк.",
    colors: ["#9be15d", "#4f8dff"],
    followers: 1830,
    following: 240,
    minutesWeek: 690,
    joined: "ноябрь 2023",
    online: false,
    lastSeen: "вчера в 23:14",
    listening: null,
    topTrackIds: ["t4", "t3", "t1"],
    playlistIds: ["p4", "p5"],
    tags: ["саунд-дизайн", "игры", "эмбиент"],
    defaultFriend: false,
  },
];

export const userById = (id: string) => USERS.find((u) => u.id === id);

export interface Activity {
  id: string;
  userId: string;
  kind: "listen" | "like" | "playlist" | "add";
  trackId?: string;
  playlistId?: string;
  when: string;
}

export const ACTIVITIES: Activity[] = [
  { id: "a1", userId: "u1", kind: "listen", trackId: "t3", when: "сейчас" },
  { id: "a2", userId: "u5", kind: "like", trackId: "t2", when: "4 мин назад" },
  { id: "a3", userId: "u2", kind: "playlist", playlistId: "p2", when: "18 мин назад" },
  { id: "a4", userId: "u7", kind: "listen", trackId: "t6", when: "сейчас" },
  { id: "a5", userId: "u4", kind: "like", trackId: "t9", when: "32 мин назад" },
  { id: "a6", userId: "u1", kind: "add", when: "1 час назад" },
  { id: "a7", userId: "u2", kind: "listen", trackId: "t7", when: "сейчас" },
  { id: "a8", userId: "u6", kind: "playlist", playlistId: "p3", when: "2 часа назад" },
];

export function fmtNum(n: number): string {
  if (n >= 1000) return `${(n / 1000).toFixed(1).replace(".", ",")} тыс`;
  return String(n);
}
