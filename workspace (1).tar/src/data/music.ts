export interface Track {
  id: string;
  title: string;
  artist: string;
  src: string;
  /** HLS-манифест (SoundCloud) — проигрывается через hls.js, если браузер не умеет сам */
  hlsUrl?: string;
  cover: string;
  /** примерная длительность в секундах (точная подтянется из метаданных mp3) */
  duration: number;
  accent: string;
  genre: string;
  plays: string;
  year: string;
}

const IMG = "https://image.qwenlm.ai/generated-images/";
const cov = (id: string) => `${IMG}${id}/_result.png`;

export const TRACKS: Track[] = [
  {
    id: "t1",
    title: "GAZ",
    artist: "Zivert",
    src: "https://ru.hitmoz.org/get/music/20260424/Zivert_-_GAZ_81356469.mp3",
    cover: cov("ea2089bd-c2c6-4ad2-af17-e954f5b58352"),
    duration: 161,
    accent: "#9be15d",
    genre: "Электро-поп",
    plays: "18,4 млн",
    year: "2026",
  },
  {
    id: "t2",
    title: "Матушка",
    artist: "Татьяна Куртукова",
    src: "https://ru.hitmoz.org/get/music/20221019/Tatyana_Kurtukova_-_Matushka_74861522.mp3",
    cover: cov("296553df-0f7f-4b30-95a0-2038bd53948d"),
    duration: 215,
    accent: "#ffa62b",
    genre: "Фолк-поп",
    plays: "31,7 млн",
    year: "2022",
  },
  {
    id: "t3",
    title: "Шёлк",
    artist: "Ваня Дмитриенко",
    src: "https://ru.hitmoz.org/get/music/20250811/Vanya_Dmitrienko_-_SHjolk_79393420.mp3",
    cover: cov("e26049ab-0d93-43d5-9916-0bdfa368b925"),
    duration: 184,
    accent: "#e8c98f",
    genre: "Поп",
    plays: "24,9 млн",
    year: "2025",
  },
  {
    id: "t4",
    title: "Тень",
    artist: "Xcho & MOT",
    src: "https://ru.hitmoz.org/get/music/20260508/By_Indiya_Xcho_MOT_-_SHadje_81430189.mp3",
    cover: cov("bbbf8398-6fa7-4e2f-ad6c-2db570b812e1"),
    duration: 178,
    accent: "#f5a524",
    genre: "R&B",
    plays: "9,1 млн",
    year: "2026",
  },
  {
    id: "t5",
    title: "Ты не бойся ночи",
    artist: "ENZRO",
    src: "https://ru.hitmoz.org/get/music/20260507/ENZRO_-_Ty_ne_bojjsya_nochi_81428177.mp3",
    cover: cov("cd6ee69f-8294-45a2-9be2-6dda16f7a2cf"),
    duration: 164,
    accent: "#7aa2ff",
    genre: "Инди-поп",
    plays: "6,8 млн",
    year: "2026",
  },
  {
    id: "t6",
    title: "Тону",
    artist: "HOLLYFLAME",
    src: "https://ru.hitmoz.org/get/music/20260206/HOLLYFLAME_-_Tonu_80790537.mp3",
    cover: cov("9b4b7a7d-ad72-4821-9359-83ab4019c6ac"),
    duration: 192,
    accent: "#4cc9f0",
    genre: "Электроника",
    plays: "5,2 млн",
    year: "2026",
  },
  {
    id: "t7",
    title: "Аникс",
    artist: "BEARWOLF",
    src: "https://ru.hitmoz.org/get/music/20260220/BEARWOLF_-_eniks_80897876.mp3",
    cover: cov("36e115cb-54f7-49f9-be9d-88dc6ad9459e"),
    duration: 151,
    accent: "#52dcc4",
    genre: "Глитч-хоп",
    plays: "4,4 млн",
    year: "2026",
  },
  {
    id: "t8",
    title: "Базовый минимум",
    artist: "SABI & MIA BOYKA",
    src: "https://ru.hitmoz.org/get/music/20250801/SABI_MIA_BOYKA_-_Bazovyjj_minimum_79356027.mp3",
    cover: cov("22904225-e096-402f-9148-cce997b53c08"),
    duration: 172,
    accent: "#ff6b6b",
    genre: "Поп",
    plays: "12,3 млн",
    year: "2025",
  },
  {
    id: "t9",
    title: "Мальборо",
    artist: "Саян",
    src: "https://ru.hitmoz.org/get/music/20260411/Sayan_-_Malboro_81256724.mp3",
    cover: cov("88be5d9b-2a95-4a8c-87ec-bb25f89ccd24"),
    duration: 167,
    accent: "#e5484d",
    genre: "Хип-хоп",
    plays: "3,9 млн",
    year: "2026",
  },
];

/* Реестр глобальных треков (SoundCloud / iTunes) — они живут в общем плеере
   наравне с чартами: очередь, лайки, «следующий» работают для всех. */
export const REGISTRY: Record<string, Track> = {};

export function registerGlobalTrack(t: Track) {
  REGISTRY[t.id] = t;
}

export const trackById = (id: string | undefined | null): Track | undefined =>
  (id && REGISTRY[id]) || TRACKS.find((t) => t.id === id);

/** Чарт недели: порядок = позиция, move — изменение за неделю */
export const CHART: { trackId: string; move: number | "new" }[] = [
  { trackId: "t1", move: 1 },
  { trackId: "t2", move: 0 },
  { trackId: "t3", move: 2 },
  { trackId: "t4", move: -1 },
  { trackId: "t5", move: "new" },
  { trackId: "t6", move: -2 },
  { trackId: "t7", move: 3 },
  { trackId: "t8", move: -1 },
  { trackId: "t9", move: "new" },
];

export const chartIds = CHART.map((c) => c.trackId);

export interface Playlist {
  id: string;
  title: string;
  desc: string;
  tag: string;
  listeners: string;
  trackIds: string[];
}

export const PLAYLISTS: Playlist[] = [
  {
    id: "p1",
    title: "Русские хиты · 2026",
    desc: "Всё, что сейчас разрывает чарты — в одном месте.",
    tag: "Хиты",
    listeners: "1,2 млн",
    trackIds: ["t1", "t2", "t3", "t4", "t8"],
  },
  {
    id: "p2",
    title: "Ночная поездка",
    desc: "Басы, неон и пустая трасса. Сделай громче.",
    tag: "Вайб",
    listeners: "486 тыс",
    trackIds: ["t5", "t7", "t6", "t1"],
  },
  {
    id: "p3",
    title: "Энергия · Тренировка",
    desc: "Разогрев, пик и заминка — темп держит чарт.",
    tag: "Спорт",
    listeners: "310 тыс",
    trackIds: ["t9", "t1", "t8", "t7"],
  },
  {
    id: "p4",
    title: "Душевное",
    desc: "Фолк, тепло и голос, от которого мурашки.",
    tag: "Фолк",
    listeners: "642 тыс",
    trackIds: ["t2", "t3", "t5", "t4"],
  },
  {
    id: "p5",
    title: "Новая музыка · Пятница",
    desc: "Свежие дропы недели, отобранные редакцией.",
    tag: "Новинки",
    listeners: "890 тыс",
    trackIds: ["t5", "t9", "t7", "t8"],
  },
];

export const playlistById = (id: string) => PLAYLISTS.find((p) => p.id === id);

export function fmtTime(sec: number): string {
  if (!Number.isFinite(sec) || sec <= 0) return "0:00";
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export function shuffleArray<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
