/* Внешние сервисы Soundscape:
   - SoundCloud (api-v2): поиск и ПОЛНЫЕ версии треков — transcodings → progressive mp3 или HLS;
   - iTunes Search API: резервный каталог (превью 30 сек);
   - ЮKassa: серверный платёжный контур с честным демо-фолбэком. */

import type { Track } from "./data/music";
import { registerGlobalTrack } from "./data/music";

/* ================= SOUNDCloud: полные версии ================= */

export interface GlobalTrack {
  key: string;
  title: string;
  artist: string;
  album: string;
  cover: string;
  src: string; // progressive mp3 (если получен сразу)
  url: string; // страница трека
  duration: number; // сек
  full: boolean; // полная версия
  hls?: string; // hls-манифест, если progressive нет
  source: "soundcloud" | "itunes";
  transcodings?: SCTranscoding[];
}

interface SCRaw {
  id?: number;
  title?: string;
  user?: { username?: string };
  artwork_url?: string | null;
  duration?: number;
  permalink_url?: string;
  media?: { transcodings?: SCTranscoding[] };
}
export interface SCTranscoding {
  url: string;
  format: { protocol: string; mime_type: string };
  quality: string;
}

const PROXIES = [
  (u: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
  (u: string) => `https://corsproxy.io/?url=${encodeURIComponent(u)}`,
];

const STATIC_CLIENT_IDS = [
  "a2f9f1f40d304dc79a1e3018553b14c4",
  "iZIs9mchVcX5lhVRyQGGAYlNPVldzAoX",
  "2t9loNvhH0kzuecsNr6rXZ3J0kVQ0pQy",
];

const API = "https://api-v2.soundcloud.com";
let scClientId: string | null = null;
let scResolving: Promise<string | null> | null = null;

async function fetchWithTimeout(url: string, ms = 6000): Promise<Response> {
  const ctrl = new AbortController();
  const t = window.setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { signal: ctrl.signal });
  } finally {
    window.clearTimeout(t);
  }
}

async function tryViaProxies(url: string, asText = false): Promise<string | null> {
  for (const px of PROXIES) {
    try {
      const res = await fetchWithTimeout(px(url));
      if (!res.ok) continue;
      return await res.text();
    } catch {
      /* пробуем следующий прокси */
    }
  }
  return asText ? null : null;
}

async function verifyClientId(id: string): Promise<boolean> {
  try {
    const res = await fetchWithTimeout(`${API}/search/tracks?q=test&limit=1&client_id=${id}`, 3500);
    return res.ok;
  } catch {
    return false;
  }
}

/** Добываем свежий client_id: статический список → парсинг бандлов soundcloud.com через прокси. */
async function resolveClientId(): Promise<string | null> {
  if (scClientId) return scClientId;
  if (scResolving) return scResolving;
  scResolving = (async () => {
    for (const id of STATIC_CLIENT_IDS) {
      if (await verifyClientId(id)) return (scClientId = id);
    }
    try {
      const html = await tryViaProxies("https://soundcloud.com");
      if (html) {
        const scripts = [...html.matchAll(/https:\/\/a-v2\.sndcdn\.com\/assets\/[0-9]+-[a-f0-9]+\.js/g)].map((m) => m[0]);
        for (const src of scripts.slice(0, 6)) {
          const js = await tryViaProxies(src);
          if (!js) continue;
          const m = js.match(/client_id\s*[:=]\s*"([A-Za-z0-9]{32})"/);
          if (m && (await verifyClientId(m[1]))) return (scClientId = m[1]);
        }
      }
    } catch {
      /* client_id не добыт */
    }
    return null;
  })();
  const res = await scResolving;
  scResolving = null;
  return res;
}

async function scFetch(path: string): Promise<unknown | null> {
  if (!scClientId) return null;
  const sep = path.includes("?") ? "&" : "?";
  const url = `${API}${path}${sep}client_id=${scClientId}`;
  try {
    const res = await fetchWithTimeout(url);
    if (res.ok) return await res.json();
  } catch {
    /* сеть */
  }
  return null;
}

export async function soundcloudAvailable(): Promise<boolean> {
  return (await resolveClientId()) !== null;
}

export async function searchSoundCloud(q: string): Promise<GlobalTrack[]> {
  const cid = await resolveClientId();
  if (!cid) return [];
  const data = (await scFetch(`/search/tracks?q=${encodeURIComponent(q)}&limit=24`)) as { collection?: SCRaw[] } | null;
  const list = data?.collection ?? [];
  return list
    .filter((t) => t.media?.transcodings?.length)
    .map((t) => ({
      key: String(t.id),
      title: t.title ?? "Без названия",
      artist: t.user?.username ?? "SoundCloud артист",
      album: "SoundCloud",
      cover: (t.artwork_url ?? "").replace("-large", "-t500x500") || "https://image.qwenlm.ai/generated-images/2f5bd768-d8c5-49f6-8878-c83bf23de37f/_result.png",
      src: "",
      url: t.permalink_url ?? "",
      duration: Math.round((t.duration ?? 0) / 1000),
      full: true,
      source: "soundcloud" as const,
      transcodings: t.media?.transcodings ?? [],
    }));
}

/** Разрешает полный поток трека: progressive mp3 или HLS-манифест. */
export async function resolveFullStream(g: GlobalTrack): Promise<{ src?: string; hls?: string }> {
  const cid = scClientId ?? (await resolveClientId());
  if (!cid) return {};
  const tcs = g.transcodings ?? [];
  const progressive =
    tcs.find((t) => t.format.protocol === "progressive" && t.format.mime_type.includes("mpeg")) ??
    tcs.find((t) => t.format.protocol === "progressive");
  const hls = tcs.find((t) => t.format.protocol === "hls");
  const pick = progressive ?? hls;
  if (!pick) return {};
  const res = (await scFetch(pick.url.startsWith("http") ? pick.url.replace(API, "") : pick.url)) as { url?: string } | null;
  const direct = res?.url;
  if (!direct) return {};
  return pick.format.protocol === "hls" ? { hls: direct } : { src: direct };
}

/* hls.js подгружается один раз по требованию */
let hlsPromise: Promise<any> | null = null;
export function loadHls(): Promise<any> {
  if (!hlsPromise) {
    hlsPromise = new Promise((resolve, reject) => {
      if ((window as any).Hls) return resolve((window as any).Hls);
      const s = document.createElement("script");
      s.src = "https://unpkg.com/hls.js@1/dist/hls.min.js";
      s.onload = () => resolve((window as any).Hls);
      s.onerror = () => {
        hlsPromise = null;
        reject(new Error("hls.js недоступен"));
      };
      document.head.appendChild(s);
    });
  }
  return hlsPromise;
}

/* ================= iTunes: резерв ================= */

export async function searchItunes(q: string): Promise<GlobalTrack[]> {
  const res = await fetchWithTimeout(
    `https://itunes.apple.com/search?term=${encodeURIComponent(q)}&media=music&entity=song&country=RU&limit=24`
  );
  if (!res.ok) throw new Error(`iTunes API: ${res.status}`);
  const data = (await res.json()) as { results?: SCRaw & any[] };
  const rows = (data as any).results ?? [];
  return rows
    .filter((r: any) => r.previewUrl)
    .map((r: any) => ({
      key: String(r.trackId),
      title: r.trackName ?? "Без названия",
      artist: r.artistName ?? "Неизвестный артист",
      album: r.collectionName ?? "",
      cover: String(r.artworkUrl100 ?? "").replace("100x100bb", "600x600bb") || "https://image.qwenlm.ai/generated-images/cd6ee69f-8294-45a2-9be2-6dda16f7a2cf/_result.png",
      src: r.previewUrl,
      url: r.trackViewUrl ?? "",
      duration: 30,
      full: false,
      source: "itunes" as const,
    }));
}

/** Регистрирует глобальный трек в плеере и возвращает его внутренний id. */
export function toPlayable(g: GlobalTrack, extra?: { src?: string; hlsUrl?: string }): Track {
  const t: Track = {
    id: `g${g.key}`,
    title: g.title,
    artist: g.artist,
    src: extra?.src ?? g.src,
    hlsUrl: extra?.hlsUrl,
    cover: g.cover,
    duration: g.duration || 30,
    accent: g.source === "soundcloud" ? "#8f7bff" : "#4fd8c0",
    genre: g.source === "soundcloud" ? "SoundCloud · полная версия" : "iTunes · превью",
    plays: g.full ? "полная версия" : "превью 30 c",
    year: "",
  };
  registerGlobalTrack(t);
  return t;
}

/* ================= ЮKassa ================= */

export interface YooPayment {
  id: string;
  demo: boolean;
}

export async function createYooKassaPayment(body: {
  description: string;
  value: string;
  capture: boolean;
}): Promise<YooPayment> {
  try {
    const res = await fetchWithTimeout("/api/yookassa/create-payment", 1600);
    if (res.ok) {
      const j = (await res.json()) as { id?: string };
      if (j?.id) return { id: j.id, demo: false };
    }
  } catch {
    /* сервер оплаты недоступен — демо-контур */
  }
  await new Promise((r) => setTimeout(r, 400));
  return { id: "ykp_" + Math.random().toString(36).slice(2, 10), demo: true };
}

export function luhnValid(num: string): boolean {
  const s = num.replace(/\D/g, "");
  if (s.length < 16) return false;
  let sum = 0;
  for (let i = 0; i < s.length; i++) {
    let d = Number(s[s.length - 1 - i]);
    if (i % 2 === 1) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    sum += d;
  }
  return sum % 10 === 0;
}

export function cardBrand(num: string): string {
  const s = num.replace(/\D/g, "");
  if (/^220[0-4]/.test(s)) return "Мир";
  if (s.startsWith("4")) return "Visa";
  if (s.startsWith("5")) return "Mastercard";
  return "Карта";
}
