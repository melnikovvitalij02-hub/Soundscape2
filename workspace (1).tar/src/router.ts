export type Route =
  | { name: "home" }
  | { name: "charts" }
  | { name: "search"; query?: string; mode?: "local" | "global" }
  | { name: "friends" }
  | { name: "profile"; id: string }
  | { name: "library" }
  | { name: "ai" }
  | { name: "beat" }
  | { name: "projects" }
  | { name: "pricing" }
  | { name: "games" }
  | { name: "chat" };

export type Nav = (r: Route) => void;
