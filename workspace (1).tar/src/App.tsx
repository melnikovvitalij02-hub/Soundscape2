import { useEffect, useRef, useState } from "react";
import type { Nav, Route } from "./router";
import { ToastProvider, useToast } from "./state/ToastContext";
import { AuthProvider, useAuth } from "./state/AuthContext";
import { StudioProvider, useStudio } from "./state/StudioContext";
import { PlayerProvider } from "./state/PlayerProvider";
import { Sidebar } from "./components/Sidebar";
import { SpaceBackground } from "./components/SpaceBackground";
import { PlayerBar } from "./components/PlayerBar";
import { Avatar } from "./components/bits";
import { IcBell, IcSearch } from "./components/icons";
import { userById } from "./data/people";
import { LoginPage } from "./pages/Login";
import { HomePage } from "./pages/Home";
import { ChartsPage } from "./pages/Charts";
import { SearchPage } from "./pages/SearchPage";
import { FriendsPage } from "./pages/Friends";
import { ProfilePage } from "./pages/ProfilePage";
import { LibraryPage } from "./pages/Library";
import { AiStudioPage } from "./pages/AiStudio";
import { BeatProPage } from "./pages/BeatPro";
import { ProjectsPage } from "./pages/Projects";
import { PricingPage } from "./pages/Pricing";
import { GamesPage } from "./pages/Games";
import { ChatPage } from "./pages/ChatPage";

const TITLES: Record<Route["name"], string> = {
  home: "Главная",
  charts: "Чарты",
  search: "Поиск",
  friends: "Друзья",
  profile: "Профиль",
  library: "Коллекция",
  ai: "AI Студия",
  beat: "Beat Pro",
  projects: "Проекты",
  pricing: "Тарифы",
  games: "Игры и квесты",
  chat: "Чат",
};

function TopBar({ route, nav }: { route: Route; nav: Nav }) {
  const toast = useToast();
  const { me } = useAuth();
  const { level, levelProgress } = useStudio();
  const profileName = route.name === "profile" ? (route.id === "me" ? "Мой профиль" : userById(route.id)?.name) : null;

  return (
    <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-ink-800/80 bg-ink-950/80 px-5 py-3 backdrop-blur-xl md:px-8">
      <p className="font-mono text-[11px] font-semibold tracking-[0.2em] text-ink-500 uppercase">
        Soundscape <span className="text-ink-600">/</span>{" "}
        <span className="text-flare-400">{profileName ?? TITLES[route.name]}</span>
      </p>

      <div className="ml-auto flex items-center gap-2">
        {/* уровень */}
        <button
          type="button"
          onClick={() => nav({ name: "games" })}
          title="Игры и квесты"
          className="group hidden items-center gap-2.5 rounded-full border border-ink-700 py-1.5 pr-3.5 pl-2.5 transition-all duration-200 hover:border-flare-500/50 sm:flex"
        >
          <span className="font-display rounded-full bg-flare-500/15 px-2 py-0.5 text-[10px] font-black text-flare-300">
            LVL {level}
          </span>
          <span className="h-1.5 w-14 overflow-hidden rounded-full bg-ink-700">
            <span
              className="block h-full rounded-full bg-gradient-to-r from-flare-500 to-wave-400 transition-all duration-500"
              style={{ width: `${Math.max(levelProgress * 100, 4)}%` }}
            />
          </span>
        </button>

        <button
          type="button"
          onClick={() => nav({ name: "search" })}
          className="group hidden items-center gap-2.5 rounded-full border border-ink-700 bg-ink-900/80 py-2 pr-14 pl-4 text-[13px] font-semibold text-ink-500 transition-all duration-200 hover:border-ink-500 hover:text-ink-300 lg:flex"
        >
          <IcSearch style={{ fontSize: 15 }} className="transition-colors group-hover:text-flare-400" />
          Любой трек, артист, друг…
        </button>
        <button
          type="button"
          onClick={() => nav({ name: "search" })}
          aria-label="Поиск"
          className="flex h-9 w-9 items-center justify-center rounded-full border border-ink-700 text-ink-400 transition-all duration-200 hover:border-ink-500 hover:text-ink-100 lg:hidden"
        >
          <IcSearch style={{ fontSize: 16 }} />
        </button>
        <button
          type="button"
          onClick={() => toast("Новых уведомлений нет — друзья тихо слушают музыку", "info")}
          aria-label="Уведомления"
          className="relative flex h-9 w-9 items-center justify-center rounded-full border border-ink-700 text-ink-400 transition-all duration-200 hover:border-ink-500 hover:text-ink-100"
        >
          <IcBell style={{ fontSize: 16 }} />
          <span className="absolute top-2 right-2.5 h-1.5 w-1.5 rounded-full bg-flare-400" />
        </button>
        {me && (
          <button type="button" onClick={() => nav({ name: "profile", id: "me" })} aria-label="Мой профиль" className="ml-1 transition-transform duration-200 hover:scale-105">
            <Avatar name={me.name} colors={me.colors} size={34} />
          </button>
        )}
      </div>
    </header>
  );
}

function Shell() {
  const [route, setRoute] = useState<Route>({ name: "home" });
  const nav: Nav = (r) => setRoute(r);
  const mainRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    mainRef.current?.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
  }, [route]);

  const routeKey = JSON.stringify(route);

  return (
    <div className="relative z-10 flex h-screen overflow-hidden">
      <Sidebar route={route} nav={nav} />

      <div ref={mainRef} className="relative min-w-0 flex-1 overflow-y-auto overscroll-contain">
        <TopBar route={route} nav={nav} />
        <main key={routeKey} className="page-enter relative mx-auto max-w-[1280px] px-5 pt-8 pb-44 md:px-8 md:pb-40">
          {route.name === "home" && <HomePage nav={nav} />}
          {route.name === "charts" && <ChartsPage nav={nav} />}
          {route.name === "search" && <SearchPage query={route.query} mode={route.mode} nav={nav} />}
          {route.name === "friends" && <FriendsPage nav={nav} />}
          {route.name === "profile" && <ProfilePage id={route.id} nav={nav} />}
          {route.name === "library" && <LibraryPage nav={nav} />}
          {route.name === "ai" && <AiStudioPage nav={nav} />}
          {route.name === "beat" && <BeatProPage nav={nav} />}
          {route.name === "projects" && <ProjectsPage nav={nav} />}
          {route.name === "pricing" && <PricingPage nav={nav} />}
          {route.name === "games" && <GamesPage nav={nav} />}
          {route.name === "chat" && <ChatPage nav={nav} />}
        </main>
      </div>

      <div className="noise" aria-hidden />
      <PlayerBar nav={nav} />
    </div>
  );
}

function Root() {
  const { me } = useAuth();
  return (
    <>
      <SpaceBackground />
      {me ? (
        <StudioProvider>
          <PlayerProvider>
            <Shell />
          </PlayerProvider>
        </StudioProvider>
      ) : (
        <div className="relative z-10">
          <LoginPage />
        </div>
      )}
    </>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <Root />
      </AuthProvider>
    </ToastProvider>
  );
}
