import { USERS } from "../data/people";
import type { Nav, Route } from "../router";
import { useAuth } from "../state/AuthContext";
import { useStudio } from "../state/StudioContext";
import { useToast } from "../state/ToastContext";
import { Avatar } from "./bits";
import { IcAi, IcChat, IcCrown, IcDrum, IcFolder, IcGame, IcLogout } from "./icons2";
import { IcChart, IcHome, IcLogo, IcSearch, IcUsers, IcWave } from "./icons";

interface Item {
  route: Route;
  label: string;
  icon: React.ReactNode;
  badge?: string | number;
  accent?: boolean;
}

export function Sidebar({ route, nav }: { route: Route; nav: Nav }) {
  const { me, logout } = useAuth();
  const { unread, projects, pro, level } = useStudio();
  const toast = useToast();

  const totalUnread = Object.values(unread).reduce((a, b) => a + b, 0);
  const online = USERS.filter((u) => u.online).slice(0, 4);

  const groups: { label: string; items: Item[] }[] = [
    {
      label: "Меню",
      items: [
        { route: { name: "home" }, label: "Главная", icon: <IcHome style={{ fontSize: 19 }} /> },
        { route: { name: "search" }, label: "Поиск", icon: <IcSearch style={{ fontSize: 19 }} /> },
        { route: { name: "charts" }, label: "Чарты", icon: <IcChart style={{ fontSize: 19 }} /> },
      ],
    },
    {
      label: "Студия",
      items: [
        {
          route: { name: "ai" },
          label: "AI Студия",
          icon: <IcAi style={{ fontSize: 19 }} />,
          badge: pro ? undefined : "PRO",
          accent: !pro,
        },
        { route: { name: "beat" }, label: "Beat Pro", icon: <IcDrum style={{ fontSize: 19 }} /> },
        { route: { name: "projects" }, label: "Проекты", icon: <IcFolder style={{ fontSize: 19 }} />, badge: projects.length || undefined },
      ],
    },
    {
      label: "Сообщество",
      items: [
        { route: { name: "friends" }, label: "Друзья", icon: <IcUsers style={{ fontSize: 19 }} /> },
        { route: { name: "chat" }, label: "Чат", icon: <IcChat style={{ fontSize: 19 }} />, badge: totalUnread || undefined },
        { route: { name: "games" }, label: "Игры и квесты", icon: <IcGame style={{ fontSize: 19 }} /> },
      ],
    },
    {
      label: "Коллекция",
      items: [
        { route: { name: "library" }, label: "Моя музыка", icon: <IcWave style={{ fontSize: 19 }} /> },
        { route: { name: "pricing" }, label: "Тарифы", icon: <IcCrown style={{ fontSize: 19 }} />, badge: pro ? "активен" : "499 ₽", accent: !pro },
      ],
    },
  ];

  const isActive = (r: Route) => r.name === route.name;

  return (
    <>
      {/* -------- десктоп -------- */}
      <aside className="hidden w-[248px] shrink-0 flex-col border-r border-ink-800/80 bg-ink-900/60 md:flex">
        <button type="button" onClick={() => nav({ name: "home" })} className="flex items-center gap-2.5 px-5 pt-5 pb-4 text-left">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-flare-500 text-ink-950 shadow-lg shadow-flare-500/30">
            <IcLogo style={{ fontSize: 20 }} />
          </span>
          <span className="font-display text-[15px] font-black tracking-tight text-ink-100">
            SOUNDSCAPE<span className="text-flare-400">.</span>
          </span>
        </button>

        <nav className="min-h-0 flex-1 overflow-y-auto px-3 pb-3">
          {groups.map((g) => (
            <div key={g.label} className="mt-3">
              <p className="font-mono px-2.5 pb-1.5 text-[9px] font-semibold tracking-[0.18em] text-ink-500 uppercase">{g.label}</p>
              {g.items.map((it) => (
                <button
                  key={it.label}
                  type="button"
                  onClick={() => nav(it.route)}
                  className={`group relative mb-0.5 flex w-full items-center gap-3 rounded-lg px-2.5 py-2 text-[13px] font-bold transition-all duration-200 ${
                    isActive(it.route) ? "bg-ink-750 text-ink-100" : "text-ink-300 hover:bg-ink-850 hover:text-ink-100"
                  }`}
                >
                  {isActive(it.route) && <span className="absolute top-1/2 left-0 h-4 w-[3px] -translate-y-1/2 rounded-r bg-flare-400" />}
                  <span className={`transition-colors ${isActive(it.route) ? "text-flare-400" : "text-ink-400 group-hover:text-ink-200"}`}>
                    {it.icon}
                  </span>
                  <span className="flex-1 text-left">{it.label}</span>
                  {it.badge !== undefined && (
                    <span
                      className={`font-mono rounded-full px-2 py-0.5 text-[9px] font-bold tracking-wider uppercase ${
                        it.accent ? "bg-flare-500/15 text-flare-300" : "bg-ink-700 text-ink-300"
                      }`}
                    >
                      {it.badge}
                    </span>
                  )}
                </button>
              ))}
            </div>
          ))}

          {/* онлайн-друзья */}
          <div className="mt-5">
            <p className="font-mono px-2.5 pb-2 text-[9px] font-semibold tracking-[0.18em] text-ink-500 uppercase">Сейчас в сети</p>
            {online.map((u) => (
              <button
                key={u.id}
                type="button"
                onClick={() => nav({ name: "profile", id: u.id })}
                className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-1.5 transition-colors duration-200 hover:bg-ink-850"
              >
                <Avatar name={u.name} colors={u.colors} size={26} online />
                <span className="truncate text-xs font-bold text-ink-300">{u.name}</span>
              </button>
            ))}
          </div>
        </nav>

        {/* низ: апселл + пользователь */}
        <div className="border-t border-ink-800/80 p-3">
          {!pro && (
            <button
              type="button"
              onClick={() => nav({ name: "pricing" })}
              className="mb-3 w-full rounded-xl border border-flare-500/35 bg-gradient-to-br from-flare-500/12 to-transparent p-3 text-left transition-all duration-200 hover:-translate-y-0.5 hover:border-flare-500/60"
            >
              <p className="font-display flex items-center gap-1.5 text-[12px] font-bold text-flare-300">
                <IcCrown style={{ fontSize: 13 }} /> Beat Pro
              </p>
              <p className="mt-1 text-[11px] font-medium text-ink-400">AI-биты и безлимит — 499 ₽/мес</p>
            </button>
          )}
          <div className="flex items-center gap-2.5 rounded-xl bg-ink-850 p-2.5">
            <button type="button" onClick={() => nav({ name: "profile", id: "me" })} className="shrink-0 transition-transform hover:scale-105" aria-label="Мой профиль">
              {me && <Avatar name={me.name} colors={me.colors} size={36} />}
            </button>
            <button type="button" onClick={() => nav({ name: "profile", id: "me" })} className="min-w-0 flex-1 text-left">
              <p className="truncate text-[13px] font-bold text-ink-100">{me?.name}</p>
              <p className="font-mono text-[10px] text-ink-500">LVL {level} {pro && "· PRO"}</p>
            </button>
            <button
              type="button"
              aria-label="Выйти из аккаунта"
              onClick={() => {
                toast("Вы вышли из аккаунта. До встречи в эфире!", "info");
                logout();
              }}
              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-ink-500 transition-all duration-200 hover:bg-beat-500/15 hover:text-beat-400"
            >
              <IcLogout style={{ fontSize: 16 }} />
            </button>
          </div>
        </div>
      </aside>

      {/* -------- мобильная нижняя панель -------- */}
      <nav className="fixed inset-x-0 bottom-[84px] z-40 border-t border-ink-800 bg-ink-900/95 backdrop-blur md:hidden" style={{ bottom: 84 }}>
        <div className="grid grid-cols-5">
          {(
            [
              { r: { name: "home" } as Route, label: "Главная", icon: <IcHome style={{ fontSize: 20 }} /> },
              { r: { name: "beat" } as Route, label: "Beat Pro", icon: <IcDrum style={{ fontSize: 20 }} /> },
              { r: { name: "search" } as Route, label: "Поиск", icon: <IcSearch style={{ fontSize: 20 }} /> },
              { r: { name: "chat" } as Route, label: "Чат", icon: <IcChat style={{ fontSize: 20 }} />, dot: totalUnread > 0 },
              { r: { name: "profile", id: "me" } as Route, label: "Профиль", icon: <IcWave style={{ fontSize: 20 }} /> },
            ] as { r: Route; label: string; icon: React.ReactNode; dot?: boolean }[]
          ).map((it) => (
            <button
              key={it.label}
              type="button"
              onClick={() => nav(it.r)}
              className={`relative flex flex-col items-center gap-0.5 py-2.5 text-[9px] font-bold transition-colors ${
                isActive(it.r) ? "text-flare-400" : "text-ink-400"
              }`}
            >
              <span className="relative">
                {it.icon}
                {it.dot && <span className="absolute -top-0.5 -right-1 h-2 w-2 rounded-full bg-flare-400" />}
              </span>
              {it.label}
            </button>
          ))}
        </div>
      </nav>

      {/* мобильный логотип-ссылка на игры (плавающий) */}
      <button
        type="button"
        onClick={() => nav({ name: "games" })}
        aria-label="Игры и квесты"
        className="fixed bottom-[170px] left-4 z-40 flex h-11 w-11 items-center justify-center rounded-full border border-ink-700 bg-ink-900/95 text-beat-400 shadow-xl backdrop-blur md:hidden"
        style={{ bottom: 170 }}
      >
        <IcGame style={{ fontSize: 20 }} />
      </button>
    </>
  );
}
