import { useRef, type PointerEvent as RPointerEvent } from "react";
import { chartIds, fmtTime, trackById } from "../data/music";
import type { Nav } from "../router";
import { usePlayer } from "../state/PlayerProvider";
import { Cover, IconBtn } from "./bits";
import { IcMute, IcNext, IcPause, IcPlay, IcPrev, IcRepeat, IcShuffle, IcVolume } from "./icons";
import { LikeBtn } from "./tracks";

function useDragBar(onFrac: (f: number) => void) {
  const ref = useRef<HTMLDivElement>(null);
  const onDown = (e: RPointerEvent<HTMLDivElement>) => {
    const el = ref.current;
    if (!el) return;
    const calc = (clientX: number) => {
      const r = el.getBoundingClientRect();
      return Math.min(Math.max((clientX - r.left) / r.width, 0), 1);
    };
    onFrac(calc(e.clientX));
    const move = (ev: globalThis.PointerEvent) => onFrac(calc(ev.clientX));
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };
  return { ref, onDown };
}

function ProgressBar({ frac, accent, onFrac }: { frac: number; accent: string; onFrac: (f: number) => void }) {
  const { ref, onDown } = useDragBar(onFrac);
  return (
    <div
      ref={ref}
      onPointerDown={onDown}
      className="group relative h-4 w-full cursor-pointer touch-none"
      role="slider"
      aria-label="Перемотка"
      aria-valuenow={Math.round(frac * 100)}
    >
      <div className="absolute top-1/2 right-0 left-0 h-[5px] -translate-y-1/2 overflow-hidden rounded-full bg-ink-700">
        <div
          className="h-full rounded-full transition-[width] duration-100 ease-linear"
          style={{ width: `${frac * 100}%`, background: accent }}
        />
      </div>
      <div
        className="absolute top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white opacity-0 shadow-md shadow-black/50 transition-opacity duration-150 group-hover:opacity-100"
        style={{ left: `${frac * 100}%` }}
      />
    </div>
  );
}

export function PlayerBar({ nav }: { nav: Nav }) {
  const p = usePlayer();
  const track = trackById(p.currentId);
  const accent = track?.accent ?? "#ffa62b";
  const dur = p.duration > 0 ? p.duration : track?.duration ?? 0;
  const frac = dur > 0 ? Math.min(p.progress / dur, 1) : 0;

  const volBar = useDragBar((f) => p.setVolume(f));
  const vol = p.muted ? 0 : p.volume;

  return (
    <footer className="fixed inset-x-0 bottom-0 z-50 border-t border-ink-700/70 bg-ink-900/95 backdrop-blur-xl">
      {/* тонкая полоса прогресса над панелью (на мобильных) */}
      {track && (
        <div className="px-3 pt-2 md:hidden">
          <ProgressBar frac={frac} accent={accent} onFrac={p.seekFrac} />
        </div>
      )}

      <div className="flex items-center gap-3 px-3 py-2.5 md:gap-5 md:px-5 md:py-3">
        {/* слева: трек */}
        <div className="flex min-w-0 flex-1 items-center gap-3 md:w-[30%] md:flex-none">
          {track ? (
            <>
              <span className="relative">
                <span
                  className={`absolute -inset-2.5 rounded-full blur-2xl ${p.isPlaying ? "breathe" : "opacity-25"}`}
                  style={{ background: accent, opacity: p.isPlaying ? undefined : 0.25 }}
                />
                <Cover src={track.cover} alt={track.title} className="relative h-[52px] w-[52px]">
                  <span className="absolute inset-0 flex items-center justify-center bg-ink-950/0 transition-colors duration-200 hover:bg-ink-950/40">
                    <button
                      type="button"
                      aria-label="Пауза/продолжить"
                      onClick={p.togglePlay}
                      className="text-ink-100 opacity-0 transition-opacity hover:opacity-100"
                    >
                      {p.isPlaying ? <IcPause style={{ fontSize: 18 }} /> : <IcPlay style={{ fontSize: 18 }} />}
                    </button>
                  </span>
                </Cover>
              </span>
              <span className="min-w-0">
                <span className="block max-w-[46vw] truncate text-sm font-bold text-ink-100 md:max-w-[220px]">
                  {track.title}
                </span>
                <span className="block truncate text-xs font-medium text-ink-300">{track.artist}</span>
              </span>
              <LikeBtn id={track.id} className="hidden sm:inline-flex" />
            </>
          ) : (
            <>
              <span className="hidden h-[52px] w-[52px] items-center justify-center rounded-md border border-dashed border-ink-600 text-ink-500 sm:flex">
                <span className="font-display text-lg">♪</span>
              </span>
              <div className="min-w-0">
                <p className="text-sm font-bold text-ink-200">В эфире тишина</p>
                <p className="truncate text-xs font-medium text-ink-400">Включи чарт недели — там сейчас жарко</p>
              </div>
              <button
                type="button"
                onClick={() => p.playTrack(chartIds[0], chartIds)}
                className="font-display ml-2 hidden shrink-0 items-center gap-2 rounded-full bg-flare-500 px-4 py-2 text-[11px] font-bold text-ink-950 transition-all duration-200 hover:scale-105 hover:bg-flare-400 active:scale-95 sm:flex"
              >
                <IcPlay style={{ fontSize: 12 }} /> Чарт недели
              </button>
            </>
          )}
        </div>

        {/* центр: управление */}
        <div className="flex flex-col items-center gap-1">
          <div className="flex items-center gap-1 md:gap-2">
            <IconBtn label="Перемешать" active={p.shuffle} onClick={p.toggleShuffle} className="hidden md:inline-flex">
              <IcShuffle style={{ fontSize: 17 }} />
            </IconBtn>
            <IconBtn label="Предыдущий трек" onClick={p.prev}>
              <IcPrev style={{ fontSize: 20 }} />
            </IconBtn>
            <button
              type="button"
              aria-label={p.isPlaying ? "Пауза" : "Слушать"}
              onClick={p.togglePlay}
              className="mx-1 flex h-11 w-11 items-center justify-center rounded-full bg-ink-100 text-ink-950 shadow-lg shadow-black/40 transition-all duration-200 hover:scale-108 hover:bg-white active:scale-95"
              style={{ boxShadow: p.isPlaying ? `0 0 28px ${accent}55` : undefined }}
            >
              {p.isPlaying ? <IcPause style={{ fontSize: 19 }} /> : <IcPlay style={{ fontSize: 19, marginLeft: 2 }} />}
            </button>
            <IconBtn label="Следующий трек" onClick={p.next}>
              <IcNext style={{ fontSize: 20 }} />
            </IconBtn>
            <IconBtn label="Повтор" active={p.repeat} onClick={p.toggleRepeat} className="hidden md:inline-flex">
              <IcRepeat style={{ fontSize: 17 }} />
            </IconBtn>
          </div>
          {track && (
            <div className="hidden w-[340px] items-center gap-2.5 md:flex xl:w-[420px]">
              <span className="font-mono w-9 text-right text-[11px] text-ink-400 tabular-nums">{fmtTime(p.progress)}</span>
              <ProgressBar frac={frac} accent={accent} onFrac={p.seekFrac} />
              <span className="font-mono w-9 text-[11px] text-ink-400 tabular-nums">{fmtTime(dur)}</span>
            </div>
          )}
        </div>

        {/* справа: очередь и громкость */}
        <div className="hidden flex-1 items-center justify-end gap-2.5 md:flex md:w-[30%] md:flex-none">
          {track && (
            <button
              type="button"
              onClick={() => nav({ name: "charts" })}
              className="font-mono rounded-full border border-ink-600/70 px-3 py-1.5 text-[11px] font-medium text-ink-300 transition-colors hover:border-ink-500 hover:text-ink-100"
              title="Открыть чарт"
            >
              в очереди: {p.queue.length}
            </button>
          )}
          <IconBtn label={p.muted ? "Включить звук" : "Без звука"} onClick={p.toggleMute}>
            {p.muted || p.volume === 0 ? <IcMute style={{ fontSize: 18 }} /> : <IcVolume style={{ fontSize: 18 }} />}
          </IconBtn>
          <div
            ref={volBar.ref}
            onPointerDown={volBar.onDown}
            className="group relative h-4 w-24 cursor-pointer touch-none lg:w-28"
            role="slider"
            aria-label="Громкость"
            aria-valuenow={Math.round(vol * 100)}
          >
            <div className="absolute top-1/2 right-0 left-0 h-[5px] -translate-y-1/2 overflow-hidden rounded-full bg-ink-700">
              <div className="h-full rounded-full bg-ink-200 transition-[width] duration-100" style={{ width: `${vol * 100}%` }} />
            </div>
            <div
              className="absolute top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white opacity-0 shadow-md transition-opacity duration-150 group-hover:opacity-100"
              style={{ left: `${vol * 100}%` }}
            />
          </div>
        </div>
      </div>
    </footer>
  );
}
