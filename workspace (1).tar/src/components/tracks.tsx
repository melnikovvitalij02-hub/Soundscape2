import type { Playlist, Track } from "../data/music";
import { fmtTime, trackById } from "../data/music";
import { usePlayer } from "../state/PlayerProvider";
import { Cover, Eq, IconBtn } from "./bits";
import { IcHeart, IcHeartFill, IcPause, IcPlay } from "./icons";

/* ---------- Кнопка лайка ---------- */
export function LikeBtn({ id, className = "" }: { id: string; className?: string }) {
  const { isLiked, toggleLike } = usePlayer();
  const liked = isLiked(id);
  return (
    <IconBtn
      label={liked ? "Убрать из любимого" : "В любимое"}
      onClick={() => toggleLike(id)}
      className={`${liked ? "!text-beat-500" : ""} ${className}`}
    >
      {liked ? <IcHeartFill style={{ fontSize: 17 }} /> : <IcHeart style={{ fontSize: 17 }} />}
    </IconBtn>
  );
}

/* ---------- Круглая кнопка play/pause поверх обложки ---------- */
function PlayOverlay({ track, context }: { track: Track; context: string[] }) {
  const { currentId, isPlaying, playTrack, togglePlay } = usePlayer();
  const isCur = currentId === track.id;
  return (
    <button
      type="button"
      aria-label={isCur && isPlaying ? "Пауза" : "Слушать"}
      onClick={(e) => {
        e.stopPropagation();
        if (isCur) togglePlay();
        else playTrack(track.id, context);
      }}
      className={`absolute right-1.5 bottom-1.5 flex h-9 w-9 items-center justify-center rounded-full bg-flare-500 text-ink-950 shadow-lg shadow-black/50 transition-all duration-200 hover:scale-110 hover:bg-flare-400 active:scale-95 ${
        isCur ? "opacity-100" : "translate-y-1.5 opacity-0 group-hover:translate-y-0 group-hover:opacity-100"
      }`}
    >
      {isCur && isPlaying ? <IcPause style={{ fontSize: 16 }} /> : <IcPlay style={{ fontSize: 16, marginLeft: 1 }} />}
    </button>
  );
}

/* ---------- Строка трека (чарт, поиск, библиотека) ---------- */
export function TrackRow({
  track,
  pos,
  context,
  trend,
  showGenre = true,
  showPlays = true,
}: {
  track: Track;
  pos?: number;
  context: string[];
  trend?: React.ReactNode;
  showGenre?: boolean;
  showPlays?: boolean;
}) {
  const { currentId, isPlaying, playTrack, togglePlay } = usePlayer();
  const isCur = currentId === track.id;

  return (
    <div
      onDoubleClick={() => playTrack(track.id, context)}
      className={`group flex cursor-default items-center gap-3 rounded-lg px-2.5 py-2 transition-colors duration-200 md:gap-4 md:px-3 ${
        isCur ? "bg-ink-800/90 ring-1 ring-ink-600/60" : "hover:bg-ink-800/70"
      }`}
    >
      {/* номер / эквалайзер / play */}
      <span className="flex w-7 shrink-0 items-center justify-center">
        {pos !== undefined && (
          <span className={`font-mono text-sm font-semibold ${isCur ? "text-flare-400" : "text-ink-400"} ${!isCur ? "group-hover:hidden" : ""}`}>
            {pos}
          </span>
        )}
        {isCur ? (
          <button type="button" onClick={togglePlay} aria-label="Пауза/продолжить" className="flex text-flare-400">
            <Eq playing={isPlaying} style={{ height: 15 }} />
          </button>
        ) : (
          <button
            type="button"
            aria-label={`Слушать ${track.title}`}
            onClick={() => playTrack(track.id, context)}
            className={`hidden text-ink-100 transition-transform group-hover:block hover:scale-110 ${pos === undefined ? "" : ""}`}
          >
            <IcPlay style={{ fontSize: 15 }} />
          </button>
        )}
      </span>

      {/* обложка */}
      <Cover src={track.cover} alt={track.title} className="h-11 w-11">
        <span className="absolute inset-0 hidden items-center justify-center bg-ink-950/50 group-hover:flex">
          {isCur && isPlaying ? (
            <button type="button" aria-label="Пауза" onClick={togglePlay} className="text-ink-100">
              <IcPause style={{ fontSize: 16 }} />
            </button>
          ) : (
            <button type="button" aria-label="Слушать" onClick={() => playTrack(track.id, context)} className="text-ink-100">
              <IcPlay style={{ fontSize: 16 }} />
            </button>
          )}
        </span>
      </Cover>

      {/* название */}
      <span className="min-w-0 flex-1">
        <span className={`block truncate text-[15px] font-bold ${isCur ? "text-flare-300" : "text-ink-100"}`}>
          {track.title}
        </span>
        <span className="block truncate text-[13px] font-medium text-ink-300">{track.artist}</span>
      </span>

      {trend && <span className="hidden w-12 shrink-0 justify-center sm:flex">{trend}</span>}
      {showGenre && (
        <span className="hidden shrink-0 rounded-full border border-ink-600/70 px-2.5 py-1 text-[11px] font-semibold text-ink-300 lg:block">
          {track.genre}
        </span>
      )}
      {showPlays && (
        <span className="font-mono hidden w-20 shrink-0 text-right text-xs text-ink-400 xl:block">{track.plays}</span>
      )}

      <LikeBtn
        id={track.id}
        className={`h-8 w-8 ${isCur ? "" : "opacity-0 group-hover:opacity-100"} focus-visible:opacity-100`}
      />

      <span className="font-mono w-10 shrink-0 text-right text-xs text-ink-300">{fmtTime(track.duration)}</span>
    </div>
  );
}

/* ---------- Карточка трека (горизонтальные ленты) ---------- */
export function TrackCard({ track, context }: { track: Track; context: string[] }) {
  const { currentId, isPlaying } = usePlayer();
  const isCur = currentId === track.id;
  return (
    <div className="group w-40 shrink-0 md:w-44">
      <div className="relative">
        <Cover src={track.cover} alt={track.title} className="aspect-square w-full">
          {isCur && (
            <span className="absolute top-2 left-2 flex items-center gap-1.5 rounded-full bg-ink-950/70 px-2 py-1 text-flare-400 backdrop-blur">
              <Eq playing={isPlaying} style={{ height: 10 }} />
              <span className="font-mono text-[10px] font-semibold tracking-wide">СЕЙЧАС</span>
            </span>
          )}
        </Cover>
        <span
          className="pointer-events-none absolute -inset-2 -z-10 rounded-xl opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-40"
          style={{ background: track.accent }}
        />
        <PlayOverlay track={track} context={context} />
      </div>
      <p className={`mt-2.5 truncate text-sm font-bold ${isCur ? "text-flare-300" : "text-ink-100"}`}>{track.title}</p>
      <p className="truncate text-xs font-medium text-ink-400">
        {track.artist} · <span className="font-mono">{track.plays}</span>
      </p>
    </div>
  );
}

/* ---------- Карточка плейлиста ---------- */
export function PlaylistCard({
  pl,
  onOpen,
  width = "w-52 md:w-56",
}: {
  pl: Playlist;
  onOpen?: (pl: Playlist) => void;
  width?: string;
}) {
  const { playTrack } = usePlayer();
  const first = trackById(pl.trackIds[0]);
  return (
    <div
      className={`group shrink-0 cursor-pointer ${width}`}
      onClick={() => (onOpen ? onOpen(pl) : playTrack(pl.trackIds[0], pl.trackIds))}
    >
      <div className="relative">
        <span className="grid block aspect-square w-full grid-cols-2 grid-rows-2 overflow-hidden rounded-lg shadow-xl shadow-black/40 ring-1 ring-white/10">
          {pl.trackIds.slice(0, 4).map((id) => {
            const t = trackById(id);
            return t ? (
              <img
                key={id}
                src={t.cover}
                alt=""
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
            ) : null;
          })}
        </span>
        <span className="absolute inset-0 rounded-lg bg-gradient-to-t from-ink-950/70 via-transparent to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
        <button
          type="button"
          aria-label={`Слушать плейлист ${pl.title}`}
          onClick={(e) => {
            e.stopPropagation();
            if (first) playTrack(first.id, pl.trackIds);
          }}
          className="absolute right-2.5 bottom-2.5 flex h-11 w-11 translate-y-2 items-center justify-center rounded-full bg-flare-500 text-ink-950 opacity-0 shadow-lg shadow-black/50 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100 hover:scale-110 hover:bg-flare-400"
        >
          <IcPlay style={{ fontSize: 18, marginLeft: 2 }} />
        </button>
        <span className="font-mono absolute top-2.5 left-2.5 rounded bg-ink-950/70 px-2 py-0.5 text-[10px] font-semibold tracking-wider text-flare-300 uppercase backdrop-blur">
          {pl.tag}
        </span>
      </div>
      <p className="mt-3 truncate text-sm font-bold text-ink-100 transition-colors group-hover:text-flare-300">
        {pl.title}
      </p>
      <p className="mt-0.5 line-clamp-2 text-xs leading-relaxed font-medium text-ink-400">{pl.desc}</p>
      <p className="font-mono mt-1 text-[11px] text-ink-500">▶ {pl.listeners} слушателей</p>
    </div>
  );
}
