import { useEffect, useRef } from "react";

/** Живой космос: мерцающие звёзды + кометы (canvas) и туманности с планетой (CSS). */
export function SpaceBackground() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const x = c.getContext("2d");
    if (!x) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    let W = 0;
    let H = 0;
    type Star = { x: number; y: number; r: number; a: number; ph: number; sp: number; col: string };
    type Comet = { x: number; y: number; vx: number; vy: number; life: number };
    let stars: Star[] = [];
    let comets: Comet[] = [];
    const palette = ["#efeaff", "#efeaff", "#d9d0ff", "#bfb0ff", "#8f7bff", "#7ee8d8"];

    const resize = () => {
      W = c.width = window.innerWidth;
      H = c.height = window.innerHeight;
      const n = Math.min(420, Math.floor((W * H) / 4200));
      stars = Array.from({ length: n }, () => ({
        x: Math.random() * W,
        y: Math.random() * H,
        r: Math.random() * 1.5 + 0.3,
        a: Math.random() * 0.75 + 0.2,
        ph: Math.random() * 7,
        sp: 0.4 + Math.random() * 1.3,
        col: palette[Math.floor(Math.random() * palette.length)],
      }));
    };
    resize();
    window.addEventListener("resize", resize);

    let t = 0;
    let raf = 0;
    const frame = () => {
      x.clearRect(0, 0, W, H);
      t += 0.016;
      for (const s of stars) {
        const tw = reduce ? s.a : s.a * (0.65 + 0.35 * Math.sin(t * s.sp + s.ph));
        x.globalAlpha = tw;
        x.fillStyle = s.col;
        x.beginPath();
        x.arc(s.x, s.y, s.r, 0, 7);
        x.fill();
      }
      x.globalAlpha = 1;
      if (!reduce && comets.length < 2 && Math.random() < 0.012) {
        comets.push({
          x: Math.random() * W * 0.8 + W * 0.15,
          y: -30,
          vx: -(2 + Math.random() * 2.4),
          vy: 4 + Math.random() * 3,
          life: 1,
        });
      }
      comets = comets.filter((cm) => cm.life > 0 && cm.y < H + 60);
      for (const cm of comets) {
        cm.x += cm.vx;
        cm.y += cm.vy;
        cm.life -= 0.006;
        const g = x.createLinearGradient(cm.x, cm.y, cm.x - cm.vx * 14, cm.y - cm.vy * 14);
        g.addColorStop(0, `rgba(191,176,255,${0.85 * cm.life})`);
        g.addColorStop(1, "rgba(191,176,255,0)");
        x.strokeStyle = g;
        x.lineWidth = 2;
        x.beginPath();
        x.moveTo(cm.x, cm.y);
        x.lineTo(cm.x - cm.vx * 14, cm.y - cm.vy * 14);
        x.stroke();
        x.fillStyle = `rgba(239,234,255,${cm.life})`;
        x.beginPath();
        x.arc(cm.x, cm.y, 2.2, 0, 7);
        x.fill();
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <div className="pointer-events-none fixed inset-0 z-0" aria-hidden>
      <canvas ref={ref} className="absolute inset-0" />
      {/* туманности */}
      <div
        className="absolute -top-44 -left-40 h-[640px] w-[640px] rounded-full opacity-50 blur-[90px]"
        style={{ background: "radial-gradient(circle, rgba(94,68,192,0.65), transparent 65%)" }}
      />
      <div
        className="absolute -right-44 -bottom-32 h-[560px] w-[560px] rounded-full opacity-50 blur-[90px]"
        style={{ background: "radial-gradient(circle, rgba(47,191,168,0.22), transparent 65%)" }}
      />
      <div
        className="absolute top-[-140px] right-[12%] h-[420px] w-[420px] rounded-full opacity-50 blur-[90px]"
        style={{ background: "radial-gradient(circle, rgba(139,92,246,0.2), transparent 65%)" }}
      />
      {/* планета с кольцом */}
      <div className="absolute right-[-140px] bottom-[-160px] hidden h-[430px] w-[430px] opacity-90 lg:block">
        <div
          className="absolute inset-0 rounded-full"
          style={{
            background: "radial-gradient(circle at 32% 28%, #4a3a9f, #1c1647 46%, #0b081c 78%)",
            boxShadow: "inset -26px -30px 70px rgba(4,2,14,0.9), 0 0 90px rgba(139,92,246,0.16)",
          }}
        />
        <div
          className="absolute -left-[22%] top-[36%] h-[34%] w-[144%] rounded-full"
          style={{
            border: "10px solid rgba(191,176,255,0.18)",
            transform: "rotate(-18deg)",
            boxShadow: "0 0 30px rgba(139,92,246,0.14), inset 0 0 24px rgba(139,92,246,0.1)",
          }}
        />
        <div
          className="drift absolute left-[8%] top-[6%] h-[34px] w-[34px] rounded-full"
          style={{
            background: "radial-gradient(circle at 34% 30%, #c9c2ef, #7a6cc9 60%, #352a7c)",
            boxShadow: "0 0 18px rgba(191,176,255,0.35)",
          }}
        />
      </div>
    </div>
  );
}
