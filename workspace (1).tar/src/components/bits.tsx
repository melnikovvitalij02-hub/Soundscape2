import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { trackById } from "../data/music";
import { IcDown, IcUp } from "./icons";

/* ---------- Аватар с инициалами на градиенте ---------- */
export function Avatar({
  name,
  colors,
  size = 40,
  online,
  className = "",
}: {
  name: string;
  colors: [string, string];
  size?: number;
  online?: boolean;
  className?: string;
}) {
  const initials = name
    .split(" ")
    .map((w) => w[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
  return (
    <span className={`relative inline-flex shrink-0 select-none ${className}`} style={{ width: size, height: size }}>
      <span
        className="font-display flex h-full w-full items-center justify-center rounded-full font-bold text-ink-950 ring-1 ring-white/15"
        style={{
          background: `linear-gradient(135deg, ${colors[0]}, ${colors[1]})`,
          fontSize: Math.max(10, size * 0.32),
          letterSpacing: "-0.02em",
        }}
      >
        {initials}
      </span>
      {online && (
        <span
          className="dot-online absolute -right-0.5 -bottom-0.5 block rounded-full border-2 border-ink-900 bg-wave-400"
          style={{ width: Math.max(10, size * 0.28), height: Math.max(10, size * 0.28) }}
        />
      )}
    </span>
  );
}

/* ---------- Живой эквалайзер ---------- */
export function Eq({ playing, className = "", style }: { playing: boolean; className?: string; style?: CSSProperties }) {
  return (
    <span className={`eq ${playing ? "" : "eq-paused"} ${className}`} style={style} aria-hidden>
      <i /><i /><i /><i />
    </span>
  );
}

/* ---------- Обложка с мягкой тенью ---------- */
export function Cover({
  src,
  alt,
  className = "",
  children,
}: {
  src: string;
  alt: string;
  className?: string;
  children?: ReactNode;
}) {
  return (
    <span className={`relative block shrink-0 overflow-hidden rounded-md bg-ink-750 shadow-lg shadow-black/40 ring-1 ring-white/10 ${className}`}>
      <img src={src} alt={alt} loading="lazy" className="h-full w-full object-cover" />
      <span className="pointer-events-none absolute inset-0 rounded-md inset-ring-1 inset-ring-white/5" />
      {children}
    </span>
  );
}

/* ---------- Коллаж из четырёх обложек ---------- */
export function Collage({ trackIds, className = "" }: { trackIds: string[]; className?: string }) {
  const covers = trackIds.slice(0, 4).map((id) => trackById(id)?.cover).filter(Boolean) as string[];
  return (
    <span className={`grid shrink-0 grid-cols-2 grid-rows-2 overflow-hidden rounded-md ring-1 ring-white/10 ${className}`}>
      {covers.map((c, i) => (
        <img key={i} src={c} alt="" loading="lazy" className="h-full w-full object-cover" />
      ))}
    </span>
  );
}

/* ---------- Тренд позиции в чарте ---------- */
export function Trend({ move }: { move: number | "new" }) {
  if (move === "new")
    return (
      <span className="font-mono rounded bg-wave-500/15 px-1.5 py-0.5 text-[10px] font-semibold tracking-wider text-wave-300">
        NEW
      </span>
    );
  if (move > 0)
    return (
      <span className="flex items-center gap-0.5 text-[11px] font-bold text-wave-400">
        <IcUp style={{ fontSize: 13 }} /> {move}
      </span>
    );
  if (move < 0)
    return (
      <span className="flex items-center gap-0.5 text-[11px] font-bold text-beat-400">
        <IcDown style={{ fontSize: 13 }} /> {Math.abs(move)}
      </span>
    );
  return <span className="font-mono text-[11px] font-bold text-ink-400">—</span>;
}

/* ---------- Появление при скролле ---------- */
export function Reveal({
  children,
  delay = 0,
  className = "",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [vis, setVis] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          setVis(true);
          io.disconnect();
        }
      },
      { threshold: 0.06 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} className={`reveal ${vis ? "reveal-in" : ""} ${className}`} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

/* ---------- Кнопка-иконка ---------- */
export function IconBtn({
  label,
  onClick,
  active,
  className = "",
  children,
}: {
  label: string;
  onClick?: () => void;
  active?: boolean;
  className?: string;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      className={`inline-flex h-9 w-9 items-center justify-center rounded-full transition-all duration-200 hover:scale-110 active:scale-95 ${
        active ? "text-flare-400" : "text-ink-300 hover:text-ink-100"
      } ${className}`}
    >
      {children}
    </button>
  );
}

export function SectionTitle({
  kicker,
  title,
  right,
}: {
  kicker?: string;
  title: string;
  right?: ReactNode;
}) {
  return (
    <div className="mb-4 flex items-end justify-between gap-4">
      <div>
        {kicker && (
          <p className="font-mono mb-1.5 text-[11px] font-semibold tracking-[0.18em] text-flare-400 uppercase">
            {kicker}
          </p>
        )}
        <h2 className="font-display text-lg font-bold text-ink-100 md:text-xl">{title}</h2>
      </div>
      {right}
    </div>
  );
}
