import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement>;

function S({ children, ...p }: P) {
  return (
    <svg
      viewBox="0 0 24 24"
      width="1em"
      height="1em"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
      {...p}
    >
      {children}
    </svg>
  );
}

export const IcLogo = (p: P) => (
  <S strokeWidth={2.4} {...p}>
    <path d="M3.5 10.5v3M8 7v10M12.5 4v16M17 7v10M21.5 10.5v3" />
  </S>
);
export const IcHome = (p: P) => (
  <S {...p}>
    <path d="M3.5 10.4 12 3.5l8.5 6.9" />
    <path d="M5.5 9.2V20h13V9.2" />
    <path d="M9.5 20v-5.5h5V20" />
  </S>
);
export const IcChart = (p: P) => (
  <S {...p}>
    <path d="M4.5 19.5v-6M10 19.5V8.5M15.5 19.5v-8.5M21 19.5V4.5" />
    <path d="M3 19.5h18" strokeWidth={1.4} opacity={0.5} />
  </S>
);
export const IcSearch = (p: P) => (
  <S {...p}>
    <circle cx="10.8" cy="10.8" r="6.3" />
    <path d="m20 20-3.8-3.8" />
  </S>
);
export const IcUsers = (p: P) => (
  <S {...p}>
    <circle cx="9" cy="8.2" r="3.4" />
    <path d="M3.2 19.6c.6-3 3-4.8 5.8-4.8s5.2 1.8 5.8 4.8" />
    <path d="M15.4 5.2a3.4 3.4 0 0 1 0 6" />
    <path d="M17.2 14.9c2 .6 3.3 2.2 3.7 4.3" />
  </S>
);
export const IcLibrary = (p: P) => (
  <S {...p}>
    <path d="M4 4.8v14.4M8.6 4.8v14.4" />
    <path d="m12.7 5.6 4.6 13.6" />
    <path d="m17.9 4.2 1.6-.5 3 14-1.6.5z" strokeWidth={1.4} />
  </S>
);
export const IcHeart = (p: P) => (
  <S {...p}>
    <path d="M12 20.2s-7.6-4.7-9.3-9.6C1.6 7.3 3.7 4 7 4c2.2 0 3.9 1.3 5 3 1.1-1.7 2.8-3 5-3 3.3 0 5.4 3.3 4.3 6.6-1.7 4.9-9.3 9.6-9.3 9.6Z" />
  </S>
);
export const IcHeartFill = (p: P) => (
  <S stroke="none" fill="currentColor" {...p}>
    <path d="M12 20.2s-7.6-4.7-9.3-9.6C1.6 7.3 3.7 4 7 4c2.2 0 3.9 1.3 5 3 1.1-1.7 2.8-3 5-3 3.3 0 5.4 3.3 4.3 6.6-1.7 4.9-9.3 9.6-9.3 9.6Z" />
  </S>
);
export const IcPlay = (p: P) => (
  <S stroke="none" fill="currentColor" {...p}>
    <path d="M8.2 4.9c0-.9 1-1.5 1.8-1L19.5 10c.8.5.8 1.6 0 2.1l-9.5 6c-.8.5-1.8-.1-1.8-1V4.9Z" />
  </S>
);
export const IcPause = (p: P) => (
  <S stroke="none" fill="currentColor" {...p}>
    <rect x="6" y="4.5" width="4" height="15" rx="1.3" />
    <rect x="14" y="4.5" width="4" height="15" rx="1.3" />
  </S>
);
export const IcNext = (p: P) => (
  <S stroke="none" fill="currentColor" {...p}>
    <path d="M6 5.6c0-.9 1-1.5 1.8-1L15 9v6l-7.2 4.4c-.8.5-1.8-.1-1.8-1V5.6Z" />
    <rect x="16.6" y="4.8" width="2.6" height="14.4" rx="1" />
  </S>
);
export const IcPrev = (p: P) => (
  <S stroke="none" fill="currentColor" {...p}>
    <path d="M18 5.6c0-.9-1-1.5-1.8-1L9 9v6l7.2 4.4c.8.5 1.8-.1 1.8-1V5.6Z" />
    <rect x="4.8" y="4.8" width="2.6" height="14.4" rx="1" />
  </S>
);
export const IcShuffle = (p: P) => (
  <S {...p}>
    <path d="M3.5 6.5h2.8c5.2 0 6 11 11.2 11h3" />
    <path d="M3.5 17.5h2.8c1.9 0 3.2-1.4 4.2-3M20.5 6.5h-3c-1.9 0-3.2 1.4-4.2 3" />
    <path d="m18 4 2.5 2.5L18 9M18 15l2.5 2.5L18 20" />
  </S>
);
export const IcRepeat = (p: P) => (
  <S {...p}>
    <path d="M4 9.5V8a3 3 0 0 1 3-3h12" />
    <path d="m16.5 2.5 2.5 2.5-2.5 2.5" />
    <path d="M20 14.5V16a3 3 0 0 1-3 3H5" />
    <path d="m7.5 21.5L5 19l2.5-2.5" />
  </S>
);
export const IcVolume = (p: P) => (
  <S {...p}>
    <path d="M11.5 5.5 7 9H3.5v6H7l4.5 3.5v-13Z" />
    <path d="M15.5 9a4.2 4.2 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11" />
  </S>
);
export const IcMute = (p: P) => (
  <S {...p}>
    <path d="M11.5 5.5 7 9H3.5v6H7l4.5 3.5v-13Z" />
    <path d="m16 9.5 5 5M21 9.5l-5 5" />
  </S>
);
export const IcBack = (p: P) => (
  <S {...p}>
    <path d="M19 12H5" />
    <path d="m11 6-6 6 6 6" />
  </S>
);
export const IcPlus = (p: P) => (
  <S {...p}>
    <path d="M12 5v14M5 12h14" />
  </S>
);
export const IcCheck = (p: P) => (
  <S {...p}>
    <path d="m4.5 12.5 5 5L19.5 7" />
  </S>
);
export const IcClose = (p: P) => (
  <S {...p}>
    <path d="m6 6 12 12M18 6 6 18" />
  </S>
);
export const IcBell = (p: P) => (
  <S {...p}>
    <path d="M18 9.5a6 6 0 1 0-12 0c0 5-2 6-2 6h16s-2-1-2-6" />
    <path d="M10 19a2.2 2.2 0 0 0 4 0" />
  </S>
);
export const IcFire = (p: P) => (
  <S {...p}>
    <path d="M12 21.5c4 0 6.5-2.6 6.5-6.2 0-3.3-2.4-5.5-4-7.8-.4 1.6-1 2.5-2.2 3.4C11.6 8.6 11.5 5.5 9 3c.3 3-1 4.6-2.2 6.3C5.6 10.9 5.5 12.7 5.5 15c0 3.9 2.7 6.5 6.5 6.5Z" />
    <path d="M12 21.5c-1.8 0-3-1.4-3-3.2 0-1.7 1.3-2.7 3-4.3 1.7 1.6 3 2.6 3 4.3 0 1.8-1.2 3.2-3 3.2Z" strokeWidth={1.4} />
  </S>
);
export const IcUp = (p: P) => (
  <S stroke="none" fill="currentColor" {...p}>
    <path d="M12 6 5.5 15h13L12 6Z" />
  </S>
);
export const IcDown = (p: P) => (
  <S stroke="none" fill="currentColor" {...p}>
    <path d="M12 18 5.5 9h13L12 18Z" />
  </S>
);
export const IcNote = (p: P) => (
  <S {...p}>
    <path d="M9 18.5V6l11-2.5V16" />
    <circle cx="6.5" cy="18.5" r="2.5" />
    <circle cx="17.5" cy="16" r="2.5" />
  </S>
);
export const IcShare = (p: P) => (
  <S {...p}>
    <circle cx="6" cy="12" r="2.6" />
    <circle cx="17.5" cy="5.5" r="2.6" />
    <circle cx="17.5" cy="18.5" r="2.6" />
    <path d="m8.4 10.7 6.8-4M8.4 13.3l6.8 4" />
  </S>
);
export const IcSend = (p: P) => (
  <S {...p}>
    <path d="M21 3.5 10.2 14.3" />
    <path d="M21 3.5 14 21l-3.8-6.7L3.5 10.5 21 3.5Z" />
  </S>
);
export const IcSpark = (p: P) => (
  <S stroke="none" fill="currentColor" {...p}>
    <path d="M12 2.5c.5 4.6 2 7.4 3.4 8.6 1.2 1 3.3 1.4 6.1 1.4-2.8.5-4.9 1-6.1 2-1.4 1.2-2.9 4-3.4 8-.5-4-2-6.8-3.4-8-1.2-1-3.3-1.5-6.1-2 2.8 0 4.9-.4 6.1-1.4 1.4-1.2 2.9-4 3.4-8.6Z" />
  </S>
);
export const IcClock = (p: P) => (
  <S {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 7.5V12l3 2.2" />
  </S>
);
export const IcWave = (p: P) => (
  <S {...p}>
    <path d="M2.5 12h3l2.5-6 4 12 3-8 1.8 3.5H21.5" />
  </S>
);
export const IcHeadphones = (p: P) => (
  <S {...p}>
    <path d="M4 15v-2.5a8 8 0 0 1 16 0V15" />
    <rect x="3" y="14.5" width="4.4" height="6" rx="2" />
    <rect x="16.6" y="14.5" width="4.4" height="6" rx="2" />
  </S>
);
export const IcLink = (p: P) => (
  <S {...p}>
    <path d="M10 14.5 14 10.5" />
    <path d="m12.8 6.7 1.9-1.9a3.6 3.6 0 0 1 5 5l-1.8 1.9" />
    <path d="m11.2 17.3-1.9 1.9a3.6 3.6 0 0 1-5-5l1.8-1.9" />
  </S>
);
export const IcDots = (p: P) => (
  <S stroke="none" fill="currentColor" {...p}>
    <circle cx="5" cy="12" r="1.7" />
    <circle cx="12" cy="12" r="1.7" />
    <circle cx="19" cy="12" r="1.7" />
  </S>
);
export const IcVinyl = (p: P) => (
  <S {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <circle cx="12" cy="12" r="3.4" />
    <circle cx="12" cy="12" r="0.8" fill="currentColor" stroke="none" />
    <path d="M17.5 8.5a6.4 6.4 0 0 1 1 3" strokeWidth={1.3} opacity={0.6} />
  </S>
);
