import type { CSSProperties } from "react";

type P = { style?: CSSProperties; className?: string };

function Svg({ style, className, children, filled }: P & { children: React.ReactNode; filled?: boolean }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill={filled ? "currentColor" : "none"}
      stroke={filled ? "none" : "currentColor"}
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      width="1em"
      height="1em"
      style={style}
      className={className}
      aria-hidden
    >
      {children}
    </svg>
  );
}

export const IcAi = (p: P) => (
  <Svg {...p}>
    <path d="M12 3l1.8 4.7 4.7 1.8-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8L12 3z" />
    <path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15z" />
    <path d="M5 17v4M3 19h4" />
  </Svg>
);

export const IcDrum = (p: P) => (
  <Svg {...p}>
    <rect x="3.5" y="4" width="17" height="16" rx="2.5" />
    <circle cx="8.3" cy="9" r="1.4" fill="currentColor" stroke="none" />
    <circle cx="15.7" cy="9" r="1.4" />
    <circle cx="8.3" cy="15" r="1.4" />
    <circle cx="15.7" cy="15" r="1.4" fill="currentColor" stroke="none" />
  </Svg>
);

export const IcFolder = (p: P) => (
  <Svg {...p}>
    <path d="M3.5 7.5a2 2 0 0 1 2-2h3.6l2 2.4h7.4a2 2 0 0 1 2 2v6.6a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2v-9z" />
  </Svg>
);

export const IcGame = (p: P) => (
  <Svg {...p}>
    <path d="M7.5 6.5h9a4.8 4.8 0 0 1 4.7 5.6l-.6 3.4a2.6 2.6 0 0 1-4.5 1.3L14.6 15H9.4l-1.5 1.8a2.6 2.6 0 0 1-4.5-1.3l-.6-3.4a4.8 4.8 0 0 1 4.7-5.6z" />
    <path d="M8 10v3M6.5 11.5h3" />
    <circle cx="15.6" cy="10.4" r="0.4" fill="currentColor" />
    <circle cx="17.8" cy="12.6" r="0.4" fill="currentColor" />
  </Svg>
);

export const IcChat = (p: P) => (
  <Svg {...p}>
    <path d="M20.5 11.5a8 8 0 0 1-11.6 7.1L4 20l1.4-4.9a8 8 0 1 1 15.1-3.6z" />
    <path d="M8.5 10.5h7M8.5 13.5h4" />
  </Svg>
);

export const IcCard = (p: P) => (
  <Svg {...p}>
    <rect x="3" y="5.5" width="18" height="13" rx="2.5" />
    <path d="M3 10h18M6.5 14.5h4" />
  </Svg>
);

export const IcLogout = (p: P) => (
  <Svg {...p}>
    <path d="M14 4H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h7" />
    <path d="M17 8l4 4-4 4M21 12H10" />
  </Svg>
);

export const IcSend = (p: P) => (
  <Svg {...p}>
    <path d="M20.5 3.5L10 14M20.5 3.5l-6.8 17-3.7-6.5-6.5-3.7 17-6.8z" />
  </Svg>
);

export const IcLock = (p: P) => (
  <Svg {...p}>
    <rect x="5.5" y="10.5" width="13" height="9.5" rx="2" />
    <path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5" />
  </Svg>
);

export const IcCrown = (p: P) => (
  <Svg {...p}>
    <path d="M4 8l4 3.5L12 5l4 6.5L20 8l-1.4 10H5.4L4 8z" />
    <path d="M5.4 18h13.2" />
  </Svg>
);

export const IcGlobe = (p: P) => (
  <Svg {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M3.5 12h17M12 3.5c2.6 2.3 3.9 5.1 3.9 8.5S14.6 18.2 12 20.5c-2.6-2.3-3.9-5.1-3.9-8.5S9.4 5.8 12 3.5z" />
  </Svg>
);

export const IcTrash = (p: P) => (
  <Svg {...p}>
    <path d="M4.5 7h15M9.5 7V5.5a1.5 1.5 0 0 1 1.5-1.5h2a1.5 1.5 0 0 1 1.5 1.5V7" />
    <path d="M6.5 7l1 11.4a2 2 0 0 0 2 1.6h5a2 2 0 0 0 2-1.6l1-11.4M10 11v5M14 11v5" />
  </Svg>
);

export const IcBolt = (p: P) => (
  <Svg {...p} filled>
    <path d="M13 2L5 13.5h5.5L11 22l8-11.5h-5.5L13 2z" />
  </Svg>
);

export const IcDice = (p: P) => (
  <Svg {...p}>
    <rect x="4" y="4" width="16" height="16" rx="3.5" />
    <circle cx="9" cy="9" r="0.6" fill="currentColor" />
    <circle cx="15" cy="15" r="0.6" fill="currentColor" />
    <circle cx="15" cy="9" r="0.6" fill="currentColor" />
    <circle cx="9" cy="15" r="0.6" fill="currentColor" />
  </Svg>
);

export const IcApple = (p: P) => (
  <Svg {...p} filled>
    <path d="M16.6 12.9c0-2 1.7-3 1.8-3.1-1-1.4-2.5-1.6-3-1.6-1.3-.1-2.5.8-3.2.8-.7 0-1.7-.8-2.8-.7-1.4 0-2.8.8-3.5 2.1-1.5 2.6-.4 6.5 1.1 8.6.7 1 1.5 2.2 2.6 2.1 1.1 0 1.5-.7 2.8-.7s1.6.7 2.8.7c1.2 0 1.9-1 2.6-2.1.8-1.2 1.2-2.4 1.2-2.5 0 0-2.3-.9-2.4-3.6zM14.5 6.6c.6-.7 1-1.7.9-2.7-.9 0-1.9.6-2.5 1.3-.6.6-1 1.6-.9 2.6 1 .1 1.9-.5 2.5-1.2z" />
  </Svg>
);

export const IcExternal = (p: P) => (
  <Svg {...p}>
    <path d="M14 4.5h5.5V10M19.5 4.5L11 13M9 5.5H6a1.5 1.5 0 0 0-1.5 1.5v11A1.5 1.5 0 0 0 6 19.5h11a1.5 1.5 0 0 0 1.5-1.5v-3" />
  </Svg>
);

export const IcCheck = (p: P) => (
  <Svg {...p}>
    <path d="M5 12.5l4.5 4.5L19 7.5" />
  </Svg>
);

export const IcPlus = (p: P) => (
  <Svg {...p}>
    <path d="M12 5v14M5 12h14" />
  </Svg>
);

export const IcMic = (p: P) => (
  <Svg {...p}>
    <rect x="9" y="3.5" width="6" height="10.5" rx="3" />
    <path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v2.5" />
  </Svg>
);
